/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Bush',
            type:'image',
            rect:['0','0','600','400','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Bush.jpg"]
         },
         {
            id:'Leaf',
            type:'image',
            rect:['509px','234px','54','63','37px','103px'],
            fill:["rgba(0,0,0,0)",im+"Leaf.png"],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["style", "height", '400px'],
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '600px']
         ],
         "${_Leaf}": [
            ["style", "-webkit-transform-origin", [50,0], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [50,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [50,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [50,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [50,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "rotateZ", '0deg'],
            ["style", "top", '233.77px'],
            ["style", "right", 'auto'],
            ["style", "left", '509.22px'],
            ["style", "bottom", 'auto']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         timeline: [
            { id: "eid29", tween: [ "style", "${_Leaf}", "left", '510.22px', { fromValue: '509.22px'}], position: 0, duration: 250 },
            { id: "eid30", tween: [ "style", "${_Leaf}", "left", '494px', { fromValue: '510.22px'}], position: 250, duration: 188 },
            { id: "eid31", tween: [ "style", "${_Leaf}", "left", '540px', { fromValue: '494px'}], position: 625, duration: 187 },
            { id: "eid32", tween: [ "style", "${_Leaf}", "left", '540px', { fromValue: '540px'}], position: 1000, duration: 0 },
            { id: "eid19", tween: [ "transform", "${_Leaf}", "rotateZ", '-15deg', { fromValue: '0deg'}], position: 0, duration: 118 },
            { id: "eid20", tween: [ "transform", "${_Leaf}", "rotateZ", '9deg', { fromValue: '-15deg'}], position: 118, duration: 90 },
            { id: "eid21", tween: [ "transform", "${_Leaf}", "rotateZ", '-16deg', { fromValue: '9deg'}], position: 208, duration: 230 },
            { id: "eid22", tween: [ "transform", "${_Leaf}", "rotateZ", '8deg', { fromValue: '-16deg'}], position: 438, duration: 246 },
            { id: "eid23", tween: [ "transform", "${_Leaf}", "rotateZ", '-17deg', { fromValue: '8deg'}], position: 684, duration: 167 },
            { id: "eid33", tween: [ "style", "${_Leaf}", "top", '420.33px', { fromValue: '233.77px'}], position: 250, duration: 750 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-397830565");
