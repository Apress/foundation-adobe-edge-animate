/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Field',
            type:'image',
            rect:['-36','-43px','600','600','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Field.jpg"],
            transform:[]
         },
         {
            id:'Body',
            type:'image',
            rect:['34','418','141','139','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Body.png"],
            transform:[]
         },
         {
            id:'Head_Up',
            type:'image',
            rect:['35','275','138','155','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Head_Up.png"],
            transform:[]
         },
         {
            id:'Anvil',
            type:'image',
            rect:['383px','-23px','227px','171px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Anvil.png",'0px','0px']
         },
         {
            id:'Head_Down',
            type:'image',
            rect:['15px','328px','180px','102px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Head_Down.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Body}": [
            ["style", "left", '34.95px'],
            ["style", "top", '418px']
         ],
         "${_Head_Down}": [
            ["style", "-webkit-transform-origin", [7.54,4.6], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [7.54,4.6],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [7.54,4.6],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [7.54,4.6],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [7.54,4.6],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "opacity", '0'],
            ["style", "left", '15px'],
            ["style", "top", '328px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '550px'],
            ["style", "height", '550px'],
            ["style", "overflow", 'hidden']
         ],
         "${_Head_Up}": [
            ["style", "top", '275px'],
            ["style", "opacity", '1'],
            ["style", "left", '35px']
         ],
         "${_Field}": [
            ["style", "top", '-42.93px'],
            ["style", "left", '-36.44px']
         ],
         "${_Anvil}": [
            ["style", "top", '28.66px'],
            ["transform", "scaleY", '0.06'],
            ["transform", "rotateZ", '-300deg'],
            ["transform", "scaleX", '0.06'],
            ["style", "left", '421.3px'],
            ["style", "-webkit-transform-origin", [50,0], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [50,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [50,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [50,0],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [50,0],{valueTemplate:'@@0@@% @@1@@%'}]
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1500,
         autoPlay: true,
         timeline: [
            { id: "eid40", tween: [ "transform", "${_Anvil}", "scaleY", '0.06', { fromValue: '0.06'}], position: 0, duration: 0 },
            { id: "eid57", tween: [ "transform", "${_Anvil}", "scaleY", '0.75', { fromValue: '0.06'}], position: 249, duration: 751 },
            { id: "eid63", tween: [ "transform", "${_Anvil}", "scaleY", '0.6', { fromValue: '0.75'}], position: 1000, duration: 500 },
            { id: "eid67", tween: [ "style", "${_Head_Down}", "opacity", '0', { fromValue: '0'}], position: 981, duration: 0 },
            { id: "eid68", tween: [ "style", "${_Head_Down}", "opacity", '1', { fromValue: '0'}], position: 1000, duration: 0 },
            { id: "eid69", tween: [ "style", "${_Head_Down}", "opacity", '0', { fromValue: '1'}], position: 1088, duration: 0 },
            { id: "eid49", tween: [ "style", "${_Anvil}", "top", '28.66px', { fromValue: '28.66px'}], position: 0, duration: 0 },
            { id: "eid59", tween: [ "style", "${_Anvil}", "top", '230.46px', { fromValue: '28.66px'}], position: 249, duration: 751 },
            { id: "eid61", tween: [ "style", "${_Anvil}", "top", '30px', { fromValue: '230.46px'}], position: 1000, duration: 500 },
            { id: "eid39", tween: [ "transform", "${_Anvil}", "scaleX", '0.06', { fromValue: '0.06'}], position: 0, duration: 0 },
            { id: "eid56", tween: [ "transform", "${_Anvil}", "scaleX", '0.75', { fromValue: '0.06'}], position: 249, duration: 751 },
            { id: "eid62", tween: [ "transform", "${_Anvil}", "scaleX", '0.6', { fromValue: '0.75'}], position: 1000, duration: 500 },
            { id: "eid65", tween: [ "style", "${_Head_Up}", "opacity", '1', { fromValue: '1'}], position: 981, duration: 0 },
            { id: "eid66", tween: [ "style", "${_Head_Up}", "opacity", '0', { fromValue: '1'}], position: 1000, duration: 0 },
            { id: "eid70", tween: [ "style", "${_Head_Up}", "opacity", '1', { fromValue: '0'}], position: 1088, duration: 0 },
            { id: "eid48", tween: [ "style", "${_Anvil}", "left", '421.3px', { fromValue: '421.3px'}], position: 0, duration: 0 },
            { id: "eid58", tween: [ "style", "${_Anvil}", "left", '6.63px', { fromValue: '421.3px'}], position: 249, duration: 751 },
            { id: "eid60", tween: [ "style", "${_Anvil}", "left", '-250px', { fromValue: '6.63px'}], position: 1000, duration: 500 },
            { id: "eid55", tween: [ "transform", "${_Anvil}", "rotateZ", '0deg', { fromValue: '-300deg'}], position: 249, duration: 751 },
            { id: "eid64", tween: [ "transform", "${_Anvil}", "rotateZ", '-70deg', { fromValue: '0deg'}], position: 1000, duration: 500 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-378200217");
