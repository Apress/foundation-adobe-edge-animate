/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'E',
            type:'text',
            rect:['54px','-59px','0','0','auto','auto'],
            opacity:1,
            text:"E",
            align:"auto",
            font:['Verdana, Geneva, sans-serif',48,"rgba(16,133,3,1)","bold","none","normal"],
            transform:[[],['0deg']]
         },
         {
            id:'d2',
            type:'text',
            rect:['91px','-58px','0','0','auto','auto'],
            opacity:1,
            text:"d",
            align:"auto",
            font:['Verdana, Geneva, sans-serif',48,"rgba(16,133,3,1)","bold","none","normal"],
            transform:[[],['0deg']]
         },
         {
            id:'g',
            type:'text',
            rect:['134px','-59px','0','0','auto','auto'],
            opacity:1,
            text:"g",
            align:"auto",
            font:['Verdana, Geneva, sans-serif',48,"rgba(16,133,3,1)","bold","none","normal"],
            transform:[[],['0deg']]
         },
         {
            id:'e2',
            type:'text',
            rect:['180px','-59px','0','0','auto','auto'],
            opacity:1,
            text:"e",
            align:"auto",
            font:['Verdana, Geneva, sans-serif',48,"rgba(16,133,3,1)","bold","none","normal"],
            transform:[[],['0deg']]
         },
         {
            id:'Text',
            type:'text',
            rect:['270px','-58px','auto','auto','auto','auto'],
            text:"A",
            align:"left",
            font:['Verdana, Geneva, sans-serif',48,"rgba(16,133,3,1)","bold","none","normal"]
         },
         {
            id:'Text2',
            type:'text',
            rect:['316px','-58px','auto','auto','auto','auto'],
            text:"n",
            align:"left",
            font:['Verdana, Geneva, sans-serif',48,"rgba(16,133,3,1)","bold","none","normal"]
         },
         {
            id:'Text3',
            type:'text',
            rect:['357px','-59px','auto','auto','auto','auto'],
            text:"i",
            align:"left",
            font:['Verdana, Geneva, sans-serif',48,"rgba(16,133,3,1)","bold","none","normal"]
         },
         {
            id:'Text4',
            type:'text',
            rect:['381px','-59px','auto','auto','auto','auto'],
            text:"m",
            align:"left",
            font:['Verdana, Geneva, sans-serif',48,"rgba(16,133,3,1)","bold","none","normal"]
         },
         {
            id:'Text5',
            type:'text',
            rect:['439px','-59px','auto','auto','auto','auto'],
            text:"a",
            align:"left",
            font:['Verdana, Geneva, sans-serif',48,"rgba(16,133,3,1)","bold","none","normal"]
         },
         {
            id:'Text6',
            type:'text',
            rect:['479px','-58px','auto','auto','auto','auto'],
            text:"t",
            align:"left",
            font:['Verdana, Geneva, sans-serif',48,"rgba(16,133,3,1)","bold","none","normal"]
         },
         {
            id:'Text7',
            type:'text',
            rect:['512px','-58px','auto','auto','auto','auto'],
            text:"e",
            align:"left",
            font:['Verdana, Geneva, sans-serif',48,"rgba(16,133,3,1)","bold","none","normal"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Text7}": [
            ["style", "top", '-58px'],
            ["style", "opacity", '0.4'],
            ["style", "left", '511.86px'],
            ["transform", "rotateZ", '-15deg']
         ],
         "${_d2}": [
            ["style", "top", '-58px'],
            ["transform", "rotateZ", '-15deg'],
            ["style", "font-family", 'Verdana, Geneva, sans-serif'],
            ["style", "opacity", '0.4'],
            ["style", "left", '90.82px'],
            ["style", "font-weight", 'bold']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(1,1,1,1.00)'],
            ["style", "width", '600px'],
            ["style", "height", '400px'],
            ["style", "overflow", 'visible']
         ],
         "${_Text5}": [
            ["style", "top", '-59px'],
            ["style", "opacity", '0.4'],
            ["style", "left", '439.04px'],
            ["transform", "rotateZ", '-15deg']
         ],
         "${_Text6}": [
            ["style", "top", '-58px'],
            ["style", "opacity", '0.4'],
            ["style", "left", '479px'],
            ["transform", "rotateZ", '-15deg']
         ],
         "${_g}": [
            ["style", "top", '-59px'],
            ["transform", "rotateZ", '-15deg'],
            ["style", "font-family", 'Verdana, Geneva, sans-serif'],
            ["style", "opacity", '0.4'],
            ["style", "left", '134.12px'],
            ["style", "font-weight", 'bold']
         ],
         "${_Text}": [
            ["style", "top", '-58px'],
            ["style", "opacity", '0.4'],
            ["style", "left", '269.93px'],
            ["transform", "rotateZ", '-15deg']
         ],
         "${_e2}": [
            ["style", "top", '-59px'],
            ["transform", "rotateZ", '-15deg'],
            ["style", "font-family", 'Verdana, Geneva, sans-serif'],
            ["style", "opacity", '0.4'],
            ["style", "left", '180.17px'],
            ["style", "font-weight", 'bold']
         ],
         "${_Text2}": [
            ["style", "top", '-58px'],
            ["style", "opacity", '0.4'],
            ["style", "left", '316.04px'],
            ["transform", "rotateZ", '-15deg']
         ],
         "${_E}": [
            ["style", "top", '-59px'],
            ["transform", "rotateZ", '-15deg'],
            ["style", "font-family", 'Verdana, Geneva, sans-serif'],
            ["style", "opacity", '0.4'],
            ["style", "left", '54.06px'],
            ["style", "font-weight", 'bold']
         ],
         "${_Text3}": [
            ["style", "top", '-59px'],
            ["style", "opacity", '0.4'],
            ["style", "left", '356.59px'],
            ["transform", "rotateZ", '-15deg']
         ],
         "${_Text4}": [
            ["style", "top", '-59px'],
            ["style", "opacity", '0.4'],
            ["style", "left", '381.22px'],
            ["transform", "rotateZ", '-15deg']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         timeline: [
            { id: "eid224", tween: [ "style", "${_e2}", "opacity", '1', { fromValue: '0.4'}], position: 940, duration: 810 },
            { id: "eid240", tween: [ "transform", "${_Text5}", "rotateZ", '360deg', { fromValue: '-15deg'}], position: 601, duration: 339 },
            { id: "eid223", tween: [ "style", "${_g}", "opacity", '1', { fromValue: '0.4'}], position: 440, duration: 310 },
            { id: "eid225", tween: [ "style", "${_Text}", "opacity", '1', { fromValue: '0.4'}], position: 750, duration: 250 },
            { id: "eid235", tween: [ "transform", "${_e2}", "rotateZ", '360deg', { fromValue: '-15deg'}], position: 940, duration: 810 },
            { id: "eid216", tween: [ "style", "${_Text3}", "top", '348px', { fromValue: '-59px'}], position: 695, duration: 500 },
            { id: "eid226", tween: [ "style", "${_Text2}", "opacity", '1', { fromValue: '0.4'}], position: 1500, duration: 500 },
            { id: "eid232", tween: [ "transform", "${_E}", "rotateZ", '360deg', { fromValue: '-15deg'}], position: 101, duration: 500 },
            { id: "eid210", tween: [ "style", "${_E}", "top", '348px', { fromValue: '-59px'}], position: 101, duration: 500 },
            { id: "eid215", tween: [ "style", "${_Text2}", "top", '349px', { fromValue: '-58px'}], position: 1500, duration: 500 },
            { id: "eid219", tween: [ "style", "${_Text6}", "top", '349px', { fromValue: '-58px'}], position: 847, duration: 500 },
            { id: "eid236", tween: [ "transform", "${_Text}", "rotateZ", '360deg', { fromValue: '-15deg'}], position: 750, duration: 250 },
            { id: "eid220", tween: [ "style", "${_Text7}", "top", '349px', { fromValue: '-58px'}], position: 1250, duration: 500 },
            { id: "eid241", tween: [ "transform", "${_Text6}", "rotateZ", '360deg', { fromValue: '-15deg'}], position: 847, duration: 500 },
            { id: "eid217", tween: [ "style", "${_Text4}", "top", '348px', { fromValue: '-59px'}], position: 1149, duration: 500 },
            { id: "eid234", tween: [ "transform", "${_g}", "rotateZ", '360deg', { fromValue: '-15deg'}], position: 440, duration: 310 },
            { id: "eid214", tween: [ "style", "${_Text}", "top", '349px', { fromValue: '-58px'}], position: 750, duration: 250 },
            { id: "eid213", tween: [ "style", "${_e2}", "top", '348px', { fromValue: '-59px'}], position: 940, duration: 810 },
            { id: "eid239", tween: [ "transform", "${_Text4}", "rotateZ", '360deg', { fromValue: '-15deg'}], position: 1149, duration: 500 },
            { id: "eid222", tween: [ "style", "${_d2}", "opacity", '1', { fromValue: '0.4'}], position: 560, duration: 500 },
            { id: "eid242", tween: [ "transform", "${_Text7}", "rotateZ", '360deg', { fromValue: '-15deg'}], position: 1250, duration: 500 },
            { id: "eid237", tween: [ "transform", "${_Text2}", "rotateZ", '360deg', { fromValue: '-15deg'}], position: 1500, duration: 500 },
            { id: "eid231", tween: [ "style", "${_Text7}", "opacity", '1', { fromValue: '0.4'}], position: 1250, duration: 500 },
            { id: "eid212", tween: [ "style", "${_g}", "top", '348px', { fromValue: '-59px'}], position: 440, duration: 310 },
            { id: "eid230", tween: [ "style", "${_Text6}", "opacity", '1', { fromValue: '0.4'}], position: 847, duration: 500 },
            { id: "eid221", tween: [ "style", "${_E}", "opacity", '1', { fromValue: '0.4'}], position: 101, duration: 500 },
            { id: "eid227", tween: [ "style", "${_Text3}", "opacity", '1', { fromValue: '0.4'}], position: 695, duration: 500 },
            { id: "eid228", tween: [ "style", "${_Text4}", "opacity", '1', { fromValue: '0.4'}], position: 1149, duration: 500 },
            { id: "eid218", tween: [ "style", "${_Text5}", "top", '348px', { fromValue: '-59px'}], position: 601, duration: 339 },
            { id: "eid233", tween: [ "transform", "${_d2}", "rotateZ", '360deg', { fromValue: '-15deg'}], position: 560, duration: 500 },
            { id: "eid229", tween: [ "style", "${_Text5}", "opacity", '1', { fromValue: '0.4'}], position: 601, duration: 339 },
            { id: "eid211", tween: [ "style", "${_d2}", "top", '349px', { fromValue: '-58px'}], position: 560, duration: 500 },
            { id: "eid238", tween: [ "transform", "${_Text3}", "rotateZ", '360deg', { fromValue: '-15deg'}], position: 695, duration: 500 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-383575814");
