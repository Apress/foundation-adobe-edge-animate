/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Image2',
            type:'image',
            rect:['0','99','1040','301','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Image.png"],
            transform:[]
         },
         {
            id:'Head_txt',
            type:'image',
            rect:['33','20','333','67','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Head_txt.png"],
            transform:[]
         },
         {
            id:'Culture_txt',
            type:'image',
            rect:['579','20','173','30','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Culture_txt.png"],
            transform:[]
         },
         {
            id:'China_txt',
            type:'image',
            rect:['844','20','165','30','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"China_txt.png"],
            transform:[]
         },
         {
            id:'Dancer',
            type:'image',
            rect:['0px','400px','234px','200px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Dancer.jpg",'0px','0px']
         },
         {
            id:'Gargoyle',
            type:'image',
            rect:['233','400','102','200','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Gargoyle.jpg"],
            transform:[]
         },
         {
            id:'Paris',
            type:'image',
            rect:['334','400','489','200','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Paris.jpg"],
            transform:[]
         },
         {
            id:'ForbiddenCity',
            type:'image',
            rect:['823','400','213','200','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Forbidden.jpg"],
            transform:[[],[],[],['1.038']]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_ForbiddenCity}": [
            ["style", "top", '400px'],
            ["style", "left", '-237px'],
            ["transform", "scaleX", '1.03755']
         ],
         "${_Image2}": [
            ["style", "top", '99px']
         ],
         "${_Head_txt}": [
            ["style", "left", '32.96px'],
            ["style", "top", '19.89px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "width", '1040px'],
            ["style", "height", '600px'],
            ["style", "overflow", 'hidden']
         ],
         "${_China_txt}": [
            ["style", "left", '844.06px'],
            ["style", "top", '-46.37px']
         ],
         "${_Paris}": [
            ["style", "left", '-516px'],
            ["style", "top", '400px']
         ],
         "${_Culture_txt}": [
            ["style", "left", '579px'],
            ["style", "top", '-46.78px']
         ],
         "${_Gargoyle}": [
            ["style", "left", '-117px'],
            ["style", "top", '400px']
         ],
         "${_Dancer}": [
            ["style", "left", '-240px'],
            ["style", "top", '400px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 5000,
         autoPlay: true,
         timeline: [
            { id: "eid14", tween: [ "style", "${_ForbiddenCity}", "left", '823px', { fromValue: '-237px'}], position: 4500, duration: 500, easing: "easeOutElastic" },
            { id: "eid4", tween: [ "style", "${_Culture_txt}", "top", '20px', { fromValue: '-46.78px'}], position: 0, duration: 500 },
            { id: "eid6", tween: [ "style", "${_China_txt}", "left", '843.73px', { fromValue: '844.06px'}], position: 500, duration: 500 },
            { id: "eid2", tween: [ "style", "${_Culture_txt}", "left", '578.67px', { fromValue: '579px'}], position: 0, duration: 500 },
            { id: "eid8", tween: [ "style", "${_Dancer}", "left", '0px', { fromValue: '-240px'}], position: 1500, duration: 500, easing: "easeOutElastic" },
            { id: "eid12", tween: [ "style", "${_Paris}", "left", '334px', { fromValue: '-516px'}], position: 3500, duration: 500, easing: "easeOutElastic" },
            { id: "eid10", tween: [ "style", "${_Gargoyle}", "left", '233px', { fromValue: '-117px'}], position: 2500, duration: 500, easing: "easeOutElastic" },
            { id: "eid5", tween: [ "style", "${_China_txt}", "top", '20.41px', { fromValue: '-46.37px'}], position: 500, duration: 500 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-469607962");
