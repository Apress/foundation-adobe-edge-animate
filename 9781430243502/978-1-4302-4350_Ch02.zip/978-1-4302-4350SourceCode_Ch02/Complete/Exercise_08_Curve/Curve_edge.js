/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Mail',
            type:'image',
            rect:['40','0','60','60','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Mail.png"],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "height", '350px'],
            ["style", "width", '100px']
         ],
         "${_Mail}": [
            ["style", "left", '40px'],
            ["style", "top", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         timeline: [
            { id: "eid7", tween: [ "style", "${_Mail}", "left", '40px', { fromValue: '40px'}], position: 0, duration: 0 },
            { id: "eid11", tween: [ "style", "${_Mail}", "left", '20px', { fromValue: '40px'}], position: 250, duration: 750 },
            { id: "eid12", tween: [ "style", "${_Mail}", "left", '40px', { fromValue: '20px'}], position: 1000, duration: 750 },
            { id: "eid9", tween: [ "style", "${_Mail}", "top", '288px', { fromValue: '0px'}], position: 0, duration: 2000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-501276221");
