/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Valley',
            type:'image',
            rect:['-50','-31','800','411','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Valley.jpg"],
            transform:[[],[],[],['0.899','0.899']]
         },
         {
            id:'Rabbit',
            type:'image',
            rect:['253px','35px','146px','279px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Rabbit.png",'0px','0px']
         },
         {
            id:'Anvil',
            type:'image',
            rect:['-191px','301px','227px','171px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Anvil.png",'0px','0px']
         },
         {
            id:'puff',
            display:'none',
            type:'image',
            rect:['216px','25px','210px','296px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"puff.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Rabbit}": [
            ["style", "top", '35px'],
            ["transform", "scaleY", '1px'],
            ["transform", "rotateZ", '0deg'],
            ["transform", "scaleX", '1px'],
            ["style", "left", '252.52px']
         ],
         "${_Valley}": [
            ["transform", "scaleX", '0.89938'],
            ["style", "top", '-30.68px'],
            ["style", "left", '-50.25px'],
            ["transform", "scaleY", '0.89938']
         ],
         "${_puff}": [
            ["style", "top", '25px'],
            ["transform", "scaleY", '0.03'],
            ["style", "display", 'none'],
            ["style", "opacity", '1'],
            ["style", "left", '216px'],
            ["transform", "scaleX", '0.03']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(0,0,0,1)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '350px'],
            ["style", "width", '700px']
         ],
         "${_Anvil}": [
            ["style", "top", '300.98px'],
            ["transform", "scaleY", '1px'],
            ["transform", "rotateZ", '0deg'],
            ["transform", "scaleX", '1px'],
            ["style", "left", '-190.72px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 5000,
         autoPlay: true,
         timeline: [
            { id: "eid35", tween: [ "transform", "${_Rabbit}", "rotateZ", '250deg', { fromValue: '0deg'}], position: 0, duration: 4000 },
            { id: "eid34", tween: [ "transform", "${_Rabbit}", "scaleY", '0.03', { fromValue: '1'}], position: 0, duration: 4000 },
            { id: "eid61", tween: [ "style", "${_puff}", "opacity", '0', { fromValue: '1'}], position: 4500, duration: 500 },
            { id: "eid39", tween: [ "style", "${_Anvil}", "top", '300.98px', { fromValue: '300.98px'}], position: 0, duration: 0 },
            { id: "eid46", tween: [ "style", "${_Anvil}", "top", '92px', { fromValue: '300.98px'}], position: 500, duration: 3500 },
            { id: "eid48", tween: [ "transform", "${_Anvil}", "scaleY", '0.03', { fromValue: '1'}], position: 1000, duration: 3000 },
            { id: "eid38", tween: [ "style", "${_Anvil}", "left", '-190.72px', { fromValue: '-190.72px'}], position: 0, duration: 0 },
            { id: "eid45", tween: [ "style", "${_Anvil}", "left", '207px', { fromValue: '-190.72px'}], position: 500, duration: 3500 },
            { id: "eid58", tween: [ "transform", "${_puff}", "scaleY", '0.7', { fromValue: '0.03'}], position: 4000, duration: 500 },
            { id: "eid60", tween: [ "transform", "${_puff}", "scaleY", '0.03', { fromValue: '0.7'}], position: 4500, duration: 500 },
            { id: "eid47", tween: [ "transform", "${_Anvil}", "scaleX", '0.03', { fromValue: '1'}], position: 1000, duration: 3000 },
            { id: "eid33", tween: [ "transform", "${_Rabbit}", "scaleX", '0.03', { fromValue: '1'}], position: 0, duration: 4000 },
            { id: "eid49", tween: [ "transform", "${_Anvil}", "rotateZ", '140deg', { fromValue: '0deg'}], position: 1000, duration: 3000 },
            { id: "eid57", tween: [ "transform", "${_puff}", "scaleX", '0.7', { fromValue: '0.03'}], position: 4000, duration: 500 },
            { id: "eid59", tween: [ "transform", "${_puff}", "scaleX", '0.03', { fromValue: '0.7'}], position: 4500, duration: 500 },
            { id: "eid50", tween: [ "style", "${_puff}", "display", 'block', { fromValue: 'none'}], position: 4000, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-196500075");
