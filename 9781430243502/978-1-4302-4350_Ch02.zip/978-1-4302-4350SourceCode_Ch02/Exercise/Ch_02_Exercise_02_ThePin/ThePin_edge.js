/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Swiss',
            type:'image',
            rect:['0','0','1200','362','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Swiss.jpg"]
         },
         {
            id:'Text',
            type:'text',
            rect:['97px','73','0','0','undefined','undefined'],
            text:"Explore Switzerland",
            font:['Arial Black, Gadget, sans-serif',92,"rgba(255,255,255,1.00)","normal","none",""],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["style", "height", '362px'],
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '1200px']
         ],
         "${_Text}": [
            ["style", "top", '73px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-family", 'Arial Black, Gadget, sans-serif'],
            ["style", "left", '97px'],
            ["style", "font-size", '92px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-418648843");
