/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Field',
            type:'image',
            rect:['-36','-42','600','600','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Field.jpg"],
            transform:[]
         },
         {
            id:'Body',
            type:'image',
            rect:['34','418','141','139','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Body.png"],
            transform:[]
         },
         {
            id:'Head_Up',
            type:'image',
            rect:['35','275','138','155','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Head_Up.png"],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Body}": [
            ["style", "left", '34.95px'],
            ["style", "top", '418px']
         ],
         "${_Head_Up}": [
            ["style", "left", '35px'],
            ["style", "top", '275px']
         ],
         "${_Field}": [
            ["style", "top", '-42.93px'],
            ["style", "left", '-36.44px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '550px'],
            ["style", "height", '550px'],
            ["style", "overflow", 'hidden']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-378200217");
