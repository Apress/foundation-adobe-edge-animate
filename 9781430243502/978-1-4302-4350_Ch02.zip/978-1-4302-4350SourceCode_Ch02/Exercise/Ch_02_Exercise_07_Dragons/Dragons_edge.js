/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Image2',
            type:'image',
            rect:['0','99','1040','301','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Image.png"],
            transform:[]
         },
         {
            id:'Head_txt',
            type:'image',
            rect:['33','20','333','67','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Head_txt.png"],
            transform:[]
         },
         {
            id:'Culture_txt',
            type:'image',
            rect:['579','20','173','30','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Culture_txt.png"],
            transform:[]
         },
         {
            id:'China_txt',
            type:'image',
            rect:['844','20','165','30','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"China_txt.png"],
            transform:[]
         },
         {
            id:'Dancer',
            type:'image',
            rect:['0px','400px','234px','200px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Dancer.jpg",'0px','0px']
         },
         {
            id:'ForbiddenCity',
            type:'image',
            rect:['823','400','213','200','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Forbidden.jpg"],
            transform:[[],[],[],['1.038']]
         },
         {
            id:'Paris',
            type:'image',
            rect:['334','400','489','200','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Paris.jpg"],
            transform:[]
         },
         {
            id:'Gargoyle',
            type:'image',
            rect:['233','400','102','200','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Gargoyle.jpg"],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_ForbiddenCity}": [
            ["style", "top", '400px'],
            ["style", "left", '823px'],
            ["transform", "scaleX", '1.03755']
         ],
         "${_Image2}": [
            ["style", "top", '99px']
         ],
         "${_Head_txt}": [
            ["style", "left", '32.96px'],
            ["style", "top", '19.89px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "width", '1040px'],
            ["style", "height", '600px'],
            ["style", "overflow", 'hidden']
         ],
         "${_China_txt}": [
            ["style", "left", '843.73px'],
            ["style", "top", '20.41px']
         ],
         "${_Paris}": [
            ["style", "left", '334px'],
            ["style", "top", '400px']
         ],
         "${_Dancer}": [
            ["style", "left", '0px'],
            ["style", "top", '400px']
         ],
         "${_Gargoyle}": [
            ["style", "left", '233px'],
            ["style", "top", '400px']
         ],
         "${_Culture_txt}": [
            ["style", "left", '578.67px'],
            ["style", "top", '20px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-469607962");
