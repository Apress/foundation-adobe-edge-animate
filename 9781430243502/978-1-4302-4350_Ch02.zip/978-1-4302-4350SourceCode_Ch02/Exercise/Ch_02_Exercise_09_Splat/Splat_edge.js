/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Valley',
            type:'image',
            rect:['-50','-31','800','411','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Valley.jpg"],
            transform:[[],[],[],['0.899','0.899']]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_stage}": [
            ["color", "background-color", 'rgba(0,0,0,1)'],
            ["style", "width", '700px'],
            ["style", "height", '350px'],
            ["style", "overflow", 'hidden']
         ],
         "${_Valley}": [
            ["transform", "scaleX", '0.89938'],
            ["style", "left", '-50.25px'],
            ["transform", "scaleY", '0.89938'],
            ["style", "top", '-30.68px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-196500075");
