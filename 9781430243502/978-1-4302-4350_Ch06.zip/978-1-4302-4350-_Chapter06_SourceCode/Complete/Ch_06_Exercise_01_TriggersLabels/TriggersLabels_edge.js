/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'PantheonButton',
            type:'image',
            rect:['9','96','200px','200px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"PantheonButton.png"],
            transform:[]
         },
         {
            id:'WineButton',
            type:'image',
            rect:['234','98','200px','200px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"WineButton.png"],
            transform:[]
         },
         {
            id:'Wine',
            display:'none',
            type:'image',
            rect:['0','0','460px','395px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Wine.jpg"]
         },
         {
            id:'Pantheon',
            display:'none',
            type:'image',
            rect:['0','0','460px','395px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Pantheon.jpg"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Pantheon}": [
            ["style", "display", 'none']
         ],
         "${_Stage}": [
            ["style", "height", '395px'],
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "width", '460px']
         ],
         "${_WineButton}": [
            ["style", "top", '98px'],
            ["style", "left", '234px'],
            ["style", "display", 'block']
         ],
         "${_Wine}": [
            ["style", "display", 'none']
         ],
         "${_PantheonButton}": [
            ["style", "top", '96px'],
            ["style", "left", '9px'],
            ["style", "display", 'block']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1500,
         autoPlay: true,
         labels: {
            "Buttons": 250,
            "Pantheon": 750,
            "Wine": 1000
         },
         timeline: [
            { id: "eid9", tween: [ "style", "${_WineButton}", "display", 'block', { fromValue: 'block'}], position: 250, duration: 0 },
            { id: "eid7", tween: [ "style", "${_WineButton}", "display", 'none', { fromValue: 'block'}], position: 500, duration: 0 },
            { id: "eid2", tween: [ "style", "${_Wine}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid5", tween: [ "style", "${_Wine}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0 },
            { id: "eid6", tween: [ "style", "${_Wine}", "display", 'block', { fromValue: 'block'}], position: 1500, duration: 0 },
            { id: "eid10", tween: [ "style", "${_PantheonButton}", "display", 'block', { fromValue: 'block'}], position: 250, duration: 0 },
            { id: "eid8", tween: [ "style", "${_PantheonButton}", "display", 'none', { fromValue: 'block'}], position: 500, duration: 0 },
            { id: "eid1", tween: [ "style", "${_Pantheon}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid3", tween: [ "style", "${_Pantheon}", "display", 'block', { fromValue: 'none'}], position: 500, duration: 0 },
            { id: "eid4", tween: [ "style", "${_Pantheon}", "display", 'none', { fromValue: 'block'}], position: 1000, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-388226550");
