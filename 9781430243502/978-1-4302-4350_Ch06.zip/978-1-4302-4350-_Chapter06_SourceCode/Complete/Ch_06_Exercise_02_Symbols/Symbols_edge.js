/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Racer',
            type:'rect',
            rect:['-59','1','auto','auto','auto','auto'],
            transform:[[],[],[],['0.7','0.7']]
         }],
         symbolInstances: [
         {
            id:'Racer',
            symbolName:'Car'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["style", "height", '90px'],
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '750px']
         ],
         "${_Racer}": [
            ["transform", "scaleX", '0.7'],
            ["transform", "scaleY", '0.7'],
            ["style", "left", '-59px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         timeline: [
            { id: "eid15", tween: [ "style", "${_Racer}", "left", '414px', { fromValue: '-59px'}], position: 0, duration: 2000, easing: "easeOutSine" }         ]
      }
   }
},
"Wheel": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Tire',
      type: 'image',
      rect: ['0','0','67px','67px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Tire.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Tire}": [
            ["transform", "rotateZ", '0deg']
         ],
         "${symbolSelector}": [
            ["style", "height", '67px'],
            ["style", "width", '67px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         timeline: [
            { id: "eid2", tween: [ "transform", "${_Tire}", "rotateZ", '720deg', { fromValue: '0deg'}], position: 0, duration: 1000 }         ]
      }
   }
},
"Car": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['1','0','395px','87px','auto','auto'],
      id: 'CarBody',
      transform: {},
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/CarBody.png']
   },
   {
      id: 'Rear',
      type: 'rect',
      transform: {},
      rect: ['28','35','auto','auto','auto','auto']
   },
   {
      id: 'Front',
      type: 'rect',
      transform: {},
      rect: ['307','35','auto','auto','auto','auto']
   }],
   symbolInstances: [
   {
      id: 'Front',
      symbolName: 'Wheel'
   },
   {
      id: 'Rear',
      symbolName: 'Wheel'
   }   ]
   },
   states: {
      "Base State": {
         "${_CarBody}": [
            ["style", "left", '1px'],
            ["style", "top", '0px']
         ],
         "${symbolSelector}": [
            ["style", "height", '87px'],
            ["style", "width", '395px']
         ],
         "${_Rear}": [
            ["style", "left", '28px'],
            ["style", "top", '35px']
         ],
         "${_Front}": [
            ["style", "left", '307px'],
            ["style", "top", '35px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-448610072");
