/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'GoogleBtn',
            type:'rect',
            rect:['5','3','auto','auto','auto','auto']
         }],
         symbolInstances: [
         {
            id:'GoogleBtn',
            symbolName:'Google_btn'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "height", '80px'],
            ["style", "width", '80px']
         ],
         "${_GoogleBtn}": [
            ["style", "left", '9px'],
            ["style", "top", '11px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
            { id: "eid17", tween: [ "style", "${_GoogleBtn}", "top", '11px', { fromValue: '11px'}], position: 0, duration: 0 },
            { id: "eid16", tween: [ "style", "${_GoogleBtn}", "left", '9px', { fromValue: '9px'}], position: 0, duration: 0 }         ]
      }
   }
},
"Google_btn": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      type: 'image',
      id: 'Up',
      rect: [0,0,'53','57','auto','auto'],
      transform: [[0,0]],
      fill: ['rgba(0,0,0,0)','images/Up.png']
   },
   {
      rect: ['0','0','64px','64px','auto','auto'],
      id: 'Over',
      type: 'image',
      display: 'none',
      fill: ['rgba(0,0,0,0)','images/Over.png']
   },
   {
      rect: ['0','0','53px','57px','auto','auto'],
      id: 'Down',
      type: 'image',
      display: 'none',
      fill: ['rgba(0,0,0,0)','images/Down.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Down}": [
            ["style", "display", 'none']
         ],
         "${_Over}": [
            ["style", "display", 'none']
         ],
         "${_Up}": [
            ["style", "display", 'block'],
            ["style", "left", '-5px'],
            ["style", "top", '-3px']
         ],
         "${symbolSelector}": [
            ["style", "height", '57px'],
            ["style", "width", '53px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 500,
         autoPlay: true,
         labels: {
            "Up": 0,
            "Over": 250,
            "Down": 500
         },
         timeline: [
            { id: "eid15", tween: [ "style", "${_Over}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid14", tween: [ "style", "${_Over}", "display", 'block', { fromValue: 'none'}], position: 250, duration: 0 },
            { id: "eid18", tween: [ "style", "${_Over}", "display", 'none', { fromValue: 'block'}], position: 500, duration: 0 },
            { id: "eid21", tween: [ "style", "${_Up}", "left", '-5px', { fromValue: '-5px'}], position: 0, duration: 0 },
            { id: "eid19", tween: [ "style", "${_Down}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid20", tween: [ "style", "${_Down}", "display", 'block', { fromValue: 'none'}], position: 500, duration: 0 },
            { id: "eid22", tween: [ "style", "${_Up}", "top", '-3px', { fromValue: '-3px'}], position: 0, duration: 0 },
            { id: "eid12", tween: [ "style", "${_Up}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
            { id: "eid13", tween: [ "style", "${_Up}", "display", 'none', { fromValue: 'block'}], position: 250, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-10848747");
