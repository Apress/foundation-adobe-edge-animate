/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

//Edge symbol: 'stage'
(function(symbolName) {





























      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_GoogleBtn}", "mouseover", function(sym, e) {
         sym.getSymbol("GoogleBtn").play("Over");

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_GoogleBtn}", "click", function(sym, e) {
         sym.getSymbol("GoogleBtn").play("Down");
         window.open("http://www.google.com", "_self");

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_GoogleBtn}", "mouseout", function(sym, e) {
         sym.getSymbol("GoogleBtn").play("Up");

      });
      //Edge binding end

})("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'Google_btn'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 250, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 500, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

   })("Google_btn");
   //Edge symbol end:'Google_btn'

})(jQuery, AdobeEdge, "EDGE-10848747");