/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Background',
            type:'image',
            rect:['0','0','700','450','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Background.jpg"],
            transform:[]
         },
         {
            id:'Falls',
            type:'image',
            rect:['175','161','600','300','auto','auto'],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"Falls.jpg"],
            transform:[]
         },
         {
            id:'Paddle',
            type:'image',
            rect:['69','86','600','300','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Paddle.jpg"],
            transform:[]
         },
         {
            id:'Stop',
            type:'image',
            rect:['70','85','600','300','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Stop.jpg"],
            transform:[]
         },
         {
            id:'FallsTxt',
            type:'text',
            rect:['98','412','0','0','auto','auto'],
            cursor:['pointer'],
            text:"High Falls",
            font:['Arial, Helvetica, sans-serif',16,"rgba(225,191,157,1.00)","600","none",""],
            transform:[]
         },
         {
            id:'PaddleTxt',
            type:'text',
            rect:['341','412','0','0','auto','auto'],
            cursor:['pointer'],
            text:"Paddle",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',16,"rgba(225,191,157,1.00)","600","none","normal"],
            transform:[]
         },
         {
            id:'StopTxt',
            type:'text',
            rect:['541','412','0','0','auto','auto'],
            cursor:['pointer'],
            text:"Canadian Stop",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',16,"rgba(225,191,157,1.00)","600","none","normal"],
            transform:[]
         },
         {
            id:'PlayBtn',
            type:'image',
            rect:['286px','171px','128px','128px','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"play.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stop}": [
            ["style", "display", 'block'],
            ["style", "opacity", '0.000000'],
            ["style", "left", '70px'],
            ["style", "top", '85px']
         ],
         "${_PlayBtn}": [
            ["style", "top", '171px'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '286px'],
            ["style", "display", 'block']
         ],
         "${_Paddle}": [
            ["style", "display", 'block'],
            ["style", "opacity", '0.000000'],
            ["style", "left", '69px'],
            ["style", "top", '86px']
         ],
         "${_FallsTxt}": [
            ["style", "top", '412px'],
            ["style", "cursor", 'pointer'],
            ["style", "font-weight", '600'],
            ["style", "font-family", 'Arial, Helvetica, sans-serif'],
            ["color", "color", 'rgba(225,191,157,1.00)'],
            ["style", "opacity", '1'],
            ["style", "left", '98px'],
            ["style", "font-size", '16px']
         ],
         "${_Background}": [
            ["style", "top", '0px'],
            ["style", "left", '0px']
         ],
         "${_Stage}": [
            ["style", "height", '450px'],
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "width", '700px']
         ],
         "${_Falls}": [
            ["style", "display", 'block'],
            ["style", "opacity", '0'],
            ["style", "left", '68.52px'],
            ["style", "top", '85.86px']
         ],
         "${_PaddleTxt}": [
            ["style", "top", '412px'],
            ["style", "cursor", 'pointer'],
            ["style", "font-family", 'Arial, Helvetica, sans-serif'],
            ["style", "font-weight", '600'],
            ["color", "color", 'rgba(225,191,157,1.00)'],
            ["style", "opacity", '1'],
            ["style", "left", '341px'],
            ["style", "font-size", '16px']
         ],
         "${_StopTxt}": [
            ["style", "top", '412px'],
            ["style", "cursor", 'pointer'],
            ["style", "font-family", 'Arial, Helvetica, sans-serif'],
            ["style", "font-weight", '600'],
            ["color", "color", 'rgba(225,191,157,1.00)'],
            ["style", "opacity", '1'],
            ["style", "left", '541px'],
            ["style", "font-size", '16px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 8999,
         autoPlay: true,
         labels: {
            "Falls": 1000,
            "Paddle": 4000,
            "Sign": 7000
         },
         timeline: [
            { id: "eid73", tween: [ "style", "${_Falls}", "opacity", '1', { fromValue: '0.000000'}], position: 1000, duration: 1142 },
            { id: "eid74", tween: [ "style", "${_Falls}", "opacity", '0', { fromValue: '1'}], position: 2142, duration: 857 },
            { id: "eid75", tween: [ "style", "${_Falls}", "display", 'block', { fromValue: 'block'}], position: 1000, duration: 0 },
            { id: "eid76", tween: [ "style", "${_Falls}", "display", 'none', { fromValue: 'block'}], position: 3000, duration: 0 },
            { id: "eid104", tween: [ "style", "${_StopTxt}", "opacity", '0.5', { fromValue: '1'}], position: 0, duration: 2142 },
            { id: "eid109", tween: [ "style", "${_StopTxt}", "opacity", '1', { fromValue: '0.500000'}], position: 7000, duration: 1142 },
            { id: "eid110", tween: [ "style", "${_StopTxt}", "opacity", '0.5', { fromValue: '1'}], position: 8142, duration: 857 },
            { id: "eid77", tween: [ "style", "${_Paddle}", "opacity", '1', { fromValue: '0.000000'}], position: 4000, duration: 1142 },
            { id: "eid79", tween: [ "style", "${_Paddle}", "opacity", '0', { fromValue: '1'}], position: 5142, duration: 857 },
            { id: "eid105", tween: [ "style", "${_PaddleTxt}", "opacity", '0.5', { fromValue: '1'}], position: 0, duration: 2142 },
            { id: "eid112", tween: [ "style", "${_PaddleTxt}", "opacity", '1', { fromValue: '0.500000'}], position: 4000, duration: 1142 },
            { id: "eid113", tween: [ "style", "${_PaddleTxt}", "opacity", '0.5', { fromValue: '1'}], position: 5142, duration: 857 },
            { id: "eid82", tween: [ "style", "${_Stop}", "display", 'block', { fromValue: 'block'}], position: 7000, duration: 0 },
            { id: "eid85", tween: [ "style", "${_Stop}", "display", 'none', { fromValue: 'block'}], position: 8999, duration: 0 },
            { id: "eid96", tween: [ "style", "${_FallsTxt}", "opacity", '0.5', { fromValue: '1'}], position: 2142, duration: 857 },
            { id: "eid86", tween: [ "style", "${_PlayBtn}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
            { id: "eid87", tween: [ "style", "${_PlayBtn}", "display", 'none', { fromValue: 'block'}], position: 250, duration: 0 },
            { id: "eid81", tween: [ "style", "${_Stop}", "opacity", '1', { fromValue: '0.000000'}], position: 7000, duration: 1142 },
            { id: "eid83", tween: [ "style", "${_Stop}", "opacity", '0', { fromValue: '1'}], position: 8142, duration: 857 },
            { id: "eid78", tween: [ "style", "${_Paddle}", "display", 'block', { fromValue: 'block'}], position: 4000, duration: 0 },
            { id: "eid80", tween: [ "style", "${_Paddle}", "display", 'none', { fromValue: 'block'}], position: 5999, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-50589414");
