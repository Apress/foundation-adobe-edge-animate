/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};
   fonts['\'Open Sans\', sans-serif']='<link href=\'http://fonts.googleapis.com/css?family=Open+Sans:700\' rel=\'stylesheet\' type=\'text/css\'>';
   fonts['"futura-pt", sans-serif']='<script type=\"text/javascript\" src=\"http://use.typekit.com/rki7fdn.js\"></script><script type=\"text/javascript\">try{Typekit.load();}catch(e){}</script>';


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Background',
            type:'image',
            rect:['0','-1','1200px','803px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Bkgrnd.jpg"],
            transform:[]
         },
         {
            id:'Cathedral',
            type:'rect',
            rect:['144','140','auto','auto','auto','auto']
         },
         {
            id:'Valley',
            type:'image',
            rect:['628','403','460px','345px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Valley.jpg"],
            transform:[]
         },
         {
            id:'CableCar',
            type:'image',
            rect:['784','154','300px','225px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"CableCar.jpg"],
            transform:[]
         },
         {
            id:'Mountains',
            type:'image',
            rect:['147','153','300px','225px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Mountains.jpg"],
            transform:[]
         },
         {
            id:'Storm',
            type:'image',
            rect:['147','403','460px','345px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Storm.jpg"],
            transform:[]
         },
         {
            id:'Text',
            type:'text',
            rect:['145','15','660px','auto','auto','auto'],
            text:"Visit Switzerland",
            align:"auto",
            font:['Open Sans, sans-serif',72,"rgba(255,255,255,1)","700","none","normal"],
            transform:[]
         }],
         symbolInstances: [
         {
            id:'Cathedral',
            symbolName:'Cathedral'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Text5}": [
            ["transform", "translateY", '0px']
         ],
         "${_Cathedral}": [
            ["style", "left", '466px'],
            ["style", "top", '153px']
         ],
         "${_CableCar}": [
            ["style", "left", '784px'],
            ["style", "top", '154px']
         ],
         "${_Text}": [
            ["style", "top", '15px'],
            ["style", "font-family", 'Open Sans, sans-serif'],
            ["style", "width", '660.88671875px'],
            ["style", "font-weight", '700'],
            ["style", "left", '145px'],
            ["style", "font-size", '72px']
         ],
         "${_Storm}": [
            ["style", "left", '147px'],
            ["style", "top", '403px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'auto'],
            ["style", "height", '800px'],
            ["style", "width", '1200px']
         ],
         "${_Valley}": [
            ["style", "left", '628px'],
            ["style", "top", '403px']
         ],
         "${_Mountains}": [
            ["style", "left", '147px'],
            ["style", "top", '153px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 15,
         autoPlay: true,
         timeline: [
            { id: "eid42", tween: [ "style", "${_Cathedral}", "left", '466px', { fromValue: '466px'}], position: 15, duration: 0 },
            { id: "eid45", tween: [ "style", "${_Cathedral}", "top", '153px', { fromValue: '153px'}], position: 15, duration: 0 }         ]
      }
   }
},
"Cathedral": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['0px','0px','300px','225px','auto','auto'],
      id: 'Church',
      transform: {},
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/Church.jpg']
   },
   {
      rect: ['1','1','300px','225px','auto','auto'],
      transform: {},
      type: 'rect',
      id: 'Box',
      stroke: [0,'rgba(0,0,0,0.00)','none'],
      display: 'none',
      fill: ['rgba(0,0,0,1.00)']
   },
   {
      transform: {},
      rect: ['25','63','249px','99px','auto','auto'],
      font: ['Arial, Helvetica, sans-serif',13,'rgba(255,255,255,1.00)','500','none','normal'],
      align: 'auto',
      id: 'CathedralText',
      text: 'Construction of this gothic style cathedral started in 1421 and was completed in 1893. It is the tallest cathedral in Switzerland.',
      display: 'none',
      type: 'text'
   },
   {
      transform: {},
      rect: ['25','35','auto','auto','auto','auto'],
      font: ['Arial, Helvetica, sans-serif',24,'rgba(255,255,255,1)','bold','none','normal'],
      align: 'auto',
      id: 'CathedralHead',
      text: 'Bern Cathedral',
      display: 'none',
      type: 'text'
   },
   {
      rect: ['167','172','127px','38px','auto','auto'],
      transform: [{},{},{},['0.74','0.74']],
      id: 'Learn',
      type: 'image',
      display: 'none',
      fill: ['rgba(0,0,0,0)','images/Learn.jpg']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Church}": [
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "display", 'block']
         ],
         "${_CathedralHead}": [
            ["style", "top", '18px'],
            ["style", "display", 'none'],
            ["style", "font-family", 'Arial, Helvetica, sans-serif'],
            ["style", "left", '28px'],
            ["style", "font-size", '30px']
         ],
         "${symbolSelector}": [
            ["style", "height", '225px'],
            ["style", "width", '300px']
         ],
         "${_CathedralText}": [
            ["style", "line-height", '23px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-weight", '500'],
            ["style", "left", '27px'],
            ["style", "font-size", '16px'],
            ["style", "top", '63px'],
            ["style", "height", '99.33203125px'],
            ["style", "font-family", 'Arial, Helvetica, sans-serif'],
            ["style", "display", 'none'],
            ["style", "width", '249px']
         ],
         "${_Box}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "top", '0px'],
            ["style", "height", '225px'],
            ["style", "display", 'none'],
            ["color", "border-color", 'rgba(0,0,0,0.00)'],
            ["style", "left", '1px'],
            ["style", "width", '300px']
         ],
         "${_Learn}": [
            ["style", "top", '172px'],
            ["transform", "scaleY", '0.74'],
            ["transform", "scaleX", '0.74'],
            ["style", "left", '167px'],
            ["style", "display", 'none']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 500,
         autoPlay: true,
         labels: {
            "Start": 0,
            "Flip": 500
         },
         timeline: [
            { id: "eid51", tween: [ "style", "${_CathedralText}", "left", '27px', { fromValue: '27px'}], position: 500, duration: 0 },
            { id: "eid1", tween: [ "style", "${_Church}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
            { id: "eid2", tween: [ "style", "${_Church}", "display", 'none', { fromValue: 'block'}], position: 500, duration: 0 },
            { id: "eid11", tween: [ "style", "${_Box}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid12", tween: [ "style", "${_Box}", "display", 'block', { fromValue: 'none'}], position: 500, duration: 0 },
            { id: "eid52", tween: [ "style", "${_CathedralText}", "top", '63px', { fromValue: '63px'}], position: 500, duration: 0 },
            { id: "eid32", tween: [ "style", "${_CathedralHead}", "font-size", '30px', { fromValue: '30px'}], position: 500, duration: 0 },
            { id: "eid39", tween: [ "style", "${_CathedralHead}", "left", '28px', { fromValue: '28px'}], position: 500, duration: 0 },
            { id: "eid40", tween: [ "style", "${_CathedralHead}", "top", '18px', { fromValue: '18px'}], position: 500, duration: 0 },
            { id: "eid37", tween: [ "style", "${_CathedralText}", "line-height", '23px', { fromValue: '23px'}], position: 500, duration: 0 },
            { id: "eid7", tween: [ "style", "${_CathedralText}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid9", tween: [ "style", "${_CathedralText}", "display", 'block', { fromValue: 'none'}], position: 500, duration: 0 },
            { id: "eid6", tween: [ "style", "${_CathedralHead}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid8", tween: [ "style", "${_CathedralHead}", "display", 'block', { fromValue: 'none'}], position: 500, duration: 0 },
            { id: "eid36", tween: [ "style", "${_CathedralText}", "font-size", '16px', { fromValue: '16px'}], position: 500, duration: 0 },
            { id: "eid46", tween: [ "style", "${_Learn}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid47", tween: [ "style", "${_Learn}", "display", 'block', { fromValue: 'none'}], position: 500, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-487545828");
