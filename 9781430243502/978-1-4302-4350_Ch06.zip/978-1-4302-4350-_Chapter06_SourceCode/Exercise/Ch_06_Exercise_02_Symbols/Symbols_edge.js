/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.6",
   build: "0.11.0.809",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   content: {
         dom: [
         {
            id:'Racer',
            type:'rect',
            rect:['162','1','auto','auto','auto','auto'],
            transform:[['-221px'],[],[],['0.7','0.7']]
         }],
         symbolInstances: [
         {
            id:'Racer',
            symbolName:'Car'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "height", '90px'],
            ["style", "width", '750px']
         ],
         "${_Racer}": [
            ["transform", "scaleX", '0.7'],
            ["transform", "scaleY", '0.7'],
            ["transform", "translateX", '-221px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         timeline: [
            { id: "eid15", tween: [ "transform", "${_Racer}", "translateX", '252px', { fromValue: '-221px'}], position: 0, duration: 2000, easing: "easeOutQuad" }         ]
      }
   }
},
"Wheel": {
   version: "0.1.6",
   build: "0.11.0.809",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   content: {
   dom: [
   {
      id: 'Tire',
      type: 'image',
      rect: ['0','0','67px','67px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Tire.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Tire}": [
            ["transform", "rotateZ", '0deg']
         ],
         "${symbolSelector}": [
            ["style", "height", '67px'],
            ["style", "width", '67px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         timeline: [
            { id: "eid2", tween: [ "transform", "${_Tire}", "rotateZ", '720deg', { fromValue: '0deg'}], position: 0, duration: 1000 }         ]
      }
   }
},
"Car": {
   version: "0.1.6",
   build: "0.11.0.809",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   content: {
   dom: [
   {
      rect: ['-0','13','395px','87px','auto','auto'],
      id: 'CarBody',
      transform: [['1px','-13px']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/CarBody.png']
   },
   {
      id: 'Rear',
      type: 'rect',
      transform: [['-19px','-9px']],
      rect: ['47','44','auto','auto','auto','auto']
   },
   {
      id: 'Front',
      type: 'rect',
      transform: [['260px','-9px']],
      rect: ['47','44','auto','auto','auto','auto']
   }],
   symbolInstances: [
   {
      id: 'Front',
      symbolName: 'Wheel'
   },
   {
      id: 'Rear',
      symbolName: 'Wheel'
   }   ]
   },
   states: {
      "Base State": {
         "${_CarBody}": [
            ["transform", "translateX", '1px'],
            ["transform", "translateY", '-13px']
         ],
         "${symbolSelector}": [
            ["style", "height", '87px'],
            ["style", "width", '395px']
         ],
         "${_Rear}": [
            ["transform", "translateX", '-19px'],
            ["transform", "translateY", '-9px']
         ],
         "${_Front}": [
            ["transform", "translateX", '260px'],
            ["transform", "translateY", '-9px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-448610072");
