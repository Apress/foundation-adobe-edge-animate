/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.6",
   build: "0.11.0.809",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   content: {
         dom: [
         {
            id:'GoogleBtn',
            type:'rect',
            rect:['13','11','auto','auto','auto','auto']
         }],
         symbolInstances: [
         {
            id:'GoogleBtn',
            symbolName:'Google_btn'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "height", '80px'],
            ["style", "width", '80px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"Google_btn": {
   version: "0.1.6",
   build: "0.11.0.809",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   content: {
   dom: [
   {
      rect: ['-13','-11','53px','57px','auto','auto'],
      id: 'Up',
      transform: [['0px','0px']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/Up.png']
   },
   {
      rect: ['0','0','53px','57px','auto','auto'],
      id: 'Down',
      type: 'image',
      display: 'none',
      fill: ['rgba(0,0,0,0)','images/Down.png']
   },
   {
      rect: ['0','0','64px','64px','auto','auto'],
      id: 'Over',
      type: 'image',
      display: 'none',
      fill: ['rgba(0,0,0,0)','images/Over.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Down}": [
            ["style", "display", 'none']
         ],
         "${symbolSelector}": [
            ["style", "height", '57px'],
            ["style", "width", '53px']
         ],
         "${_Up}": [
            ["style", "display", 'block'],
            ["transform", "translateY", '0px'],
            ["transform", "translateX", '0px']
         ],
         "${_Over}": [
            ["style", "display", 'none']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 500,
         autoPlay: true,
         labels: {
            "Uo": 0,
            "Over": 250,
            "Down": 500
         },
         timeline: [
            { id: "eid25", tween: [ "style", "${_Over}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid26", tween: [ "style", "${_Over}", "display", 'block', { fromValue: 'none'}], position: 250, duration: 0 },
            { id: "eid27", tween: [ "style", "${_Over}", "display", 'none', { fromValue: 'block'}], position: 500, duration: 0 },
            { id: "eid28", tween: [ "style", "${_Down}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid29", tween: [ "style", "${_Down}", "display", 'block', { fromValue: 'none'}], position: 500, duration: 0 },
            { id: "eid23", tween: [ "style", "${_Up}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
            { id: "eid24", tween: [ "style", "${_Up}", "display", 'none', { fromValue: 'block'}], position: 250, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-10848747");
