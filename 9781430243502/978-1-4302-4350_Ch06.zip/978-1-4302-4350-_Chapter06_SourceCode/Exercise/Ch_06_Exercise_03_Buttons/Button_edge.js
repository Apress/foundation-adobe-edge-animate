/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'GoogleBtn',
            type:'rect',
            rect:['0','0','auto','auto','auto','auto']
         }],
         symbolInstances: [
         {
            id:'GoogleBtn',
            symbolName:'Google_btn'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "height", '80px'],
            ["style", "width", '80px']
         ],
         "${_GoogleBtn}": [
            ["style", "left", '13px'],
            ["style", "top", '11px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
            { id: "eid24", tween: [ "style", "${_GoogleBtn}", "top", '11px', { fromValue: '11px'}], position: 0, duration: 0 },
            { id: "eid23", tween: [ "style", "${_GoogleBtn}", "left", '13px', { fromValue: '13px'}], position: 0, duration: 0 }         ]
      }
   }
},
"Google_btn": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [[0,0]],
      id: 'Up',
      type: 'image',
      rect: [0,0,'53','57','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Up.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Up}": [
            ["style", "left", '-5px'],
            ["style", "top", '-3px']
         ],
         "${symbolSelector}": [
            ["style", "height", '57px'],
            ["style", "width", '53px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-10848747");
