/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Background',
            type:'image',
            rect:['0','-1','1200px','803px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Bkgrnd.jpg"],
            transform:[]
         },
         {
            id:'Valley',
            type:'image',
            rect:['628','403','460px','345px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Valley.jpg"],
            transform:[]
         },
         {
            id:'CableCar',
            type:'image',
            rect:['784','154','300px','225px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"CableCar.jpg"],
            transform:[]
         },
         {
            id:'Mountains',
            type:'image',
            rect:['147','153','300px','225px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Mountains.jpg"],
            transform:[]
         },
         {
            id:'Storm',
            type:'image',
            rect:['147','403','460px','345px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Storm.jpg"],
            transform:[]
         },
         {
            id:'Text',
            type:'text',
            rect:['145','15','660px','auto','auto','auto'],
            text:"Visit Switzerland",
            align:"auto",
            font:['Arial, Helvetica, sans-serif',72,"rgba(255,255,255,1)","700","none","normal"],
            transform:[]
         },
         {
            id:'Church',
            type:'image',
            rect:['467','154','300px','225px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Church2.jpg"],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Church}": [
            ["style", "left", '467px'],
            ["style", "top", '154px']
         ],
         "${_CableCar}": [
            ["style", "left", '784px'],
            ["style", "top", '154px']
         ],
         "${_Text}": [
            ["style", "top", '15px'],
            ["style", "width", '660.88671875px'],
            ["style", "font-weight", '700'],
            ["style", "left", '145px'],
            ["style", "font-size", '72px']
         ],
         "${_Storm}": [
            ["style", "left", '147px'],
            ["style", "top", '403px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'auto'],
            ["style", "height", '800px'],
            ["style", "width", '1200px']
         ],
         "${_Valley}": [
            ["style", "left", '628px'],
            ["style", "top", '403px']
         ],
         "${_Text5}": [
            ["transform", "translateY", '0px']
         ],
         "${_Mountains}": [
            ["style", "left", '147px'],
            ["style", "top", '153px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-487545828");
