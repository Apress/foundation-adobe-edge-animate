/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Content_bkgrnd',
            type:'image',
            rect:['272px','78px','683px','468px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Contain.png",'0px','0px']
         },
         {
            id:'NavBkgrnd',
            type:'image',
            rect:['17px','147px','245px','278px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"NavBkgrnd.png",'0px','0px']
         },
         {
            id:'Google_btn',
            type:'image',
            rect:['61px','238px','158px','35px','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"Google.png",'0px','0px']
         },
         {
            id:'YouTube_btn',
            type:'image',
            rect:['61px','305px','158px','35px','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"YouTube.png",'0px','0px']
         },
         {
            id:'YouTube',
            display:'none',
            type:'rect',
            rect:['303','147','auto','auto','auto','auto']
         },
         {
            id:'Google2',
            display:'none',
            type:'rect',
            rect:['309','107','auto','auto','auto','auto']
         }],
         symbolInstances: [
         {
            id:'YouTube',
            symbolName:'YouTube'
         },
         {
            id:'Google2',
            symbolName:'Google'
         }
         ]
      },
   states: {
      "Base State": {
         "${_YouTube_btn}": [
            ["style", "top", '305.25px'],
            ["style", "left", '61px'],
            ["style", "cursor", 'pointer']
         ],
         "${_YouTube}": [
            ["style", "display", 'none']
         ],
         "${_NavBkgrnd}": [
            ["style", "left", '17px'],
            ["style", "top", '147.25px']
         ],
         "${_Google_btn}": [
            ["style", "top", '237.72px'],
            ["style", "left", '61px'],
            ["style", "cursor", 'pointer']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "width", '1000px'],
            ["style", "height", '600px'],
            ["style", "overflow", 'hidden']
         ],
         "${_Google2}": [
            ["style", "top", '86px'],
            ["style", "left", '343.52px'],
            ["style", "display", 'none']
         ],
         "${_Content_bkgrnd}": [
            ["style", "top", '77.87px'],
            ["style", "display", 'block'],
            ["style", "left", '272.1px'],
            ["style", "width", '683.21820068359px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         labels: {
            "Google": 1000,
            "YouTube": 2000
         },
         timeline: [
            { id: "eid35", tween: [ "style", "${_YouTube}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid36", tween: [ "style", "${_YouTube}", "display", 'block', { fromValue: 'none'}], position: 2000, duration: 0 },
            { id: "eid40", tween: [ "style", "${_Google2}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0 },
            { id: "eid41", tween: [ "style", "${_Google2}", "display", 'none', { fromValue: 'block'}], position: 1962, duration: 0 },
            { id: "eid28", tween: [ "style", "${_Content_bkgrnd}", "display", 'none', { fromValue: 'block'}], position: 1962, duration: 0 }         ]
      }
   }
},
"Google": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      type: 'rect',
      id: 'container',
      stroke: [3,'rgb(0, 0, 0)','dashed'],
      rect: ['0px','0px','484px','447px','auto','auto'],
      fill: ['rgba(192,192,192,0)']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '452.91665649414px'],
            ["style", "width", '490.25px']
         ],
         "${_container}": [
            ["style", "left", '0px'],
            ["style", "top", '0.02px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"YouTube": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      type: 'rect',
      id: 'vidcontainer',
      stroke: [0,'rgb(0, 0, 0)','none'],
      rect: ['-7px','0px','640px','360px','auto','auto'],
      fill: ['rgba(192,192,192,0)']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_vidcontainer}": [
            ["style", "height", '360px'],
            ["style", "top", '0px'],
            ["style", "left", '-7.31px'],
            ["style", "width", '640px']
         ],
         "${symbolSelector}": [
            ["style", "height", '360px'],
            ["style", "width", '480.03332519531px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-49654456");
