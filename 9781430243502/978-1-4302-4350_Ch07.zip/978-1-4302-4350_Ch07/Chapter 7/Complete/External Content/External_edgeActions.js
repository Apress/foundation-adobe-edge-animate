/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

      Symbol.bindElementAction(compId, symbolName, "${_Google_btn}", "click", function(sym, e) {
         sym.play("Google");
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1000, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_YouTube_btn}", "click", function(sym, e) {
         sym.play("YouTube");
         

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'Google'
   (function(symbolName) {   
   
      Symbol.bindSymbolAction(compId, symbolName, "creationComplete", function(sym, e) {
         var container = sym.$("container");
         var map = ' <iframe width="'+container.width()+'" height="'+container.height()+'" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.ca/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Lakeside+Park,+Oakville,+ON&amp;aq=0&amp;oq=lakeside+Oakville&amp;sll=43.4415,-79.667358&amp;sspn=0.006598,0.016512&amp;t=h&amp;ie=UTF8&amp;hq=Lakeside+Park,+Oakville,+ON&amp;ll=43.4415,-79.667358&amp;spn=0.006295,0.006295&amp;output=embed"></iframe><br /><small><a href="https://maps.google.ca/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Lakeside+Park,+Oakville,+ON&amp;aq=0&amp;oq=lakeside+Oakville&amp;sll=43.4415,-79.667358&amp;sspn=0.006598,0.016512&amp;t=h&amp;ie=UTF8&amp;hq=Lakeside+Park,+Oakville,+ON&amp;ll=43.4415,-79.667358&amp;spn=0.006295,0.006295" style="color:#0000FF;text-align:left">View Larger Map</a></small>';
         container.html(map);

      });
      //Edge binding end

   })("Google");
   //Edge symbol end:'Google'

   //=========================================================
   
   //Edge symbol: 'YouTube'
   (function(symbolName) {   
   
      Symbol.bindSymbolAction(compId, symbolName, "creationComplete", function(sym, e) {
         var container =sym.$("vidcontainer");
         var vid ='<iframe width="640" height="360" src="http://www.youtube.com/embed/tjXcL2mhs0M?list=UU4Ns36PLecNVFa0oeLDLdwg&amp;hl=en_US" frameborder="0" allowfullscreen></iframe>';
         container.html(vid);

      });
      //Edge binding end

   })("YouTube");
   //Edge symbol end:'YouTube'

})(jQuery, AdobeEdge, "EDGE-49654456");