/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.180",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'BG',
            type:'image',
            rect:['0','0','1000px','300px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"BG.jpg",'0px','0px']
         },
         {
            id:'Mishipeshu',
            type:'image',
            rect:['698px','12px','281px','69px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Mishipeshu.png",'0px','0px']
         },
         {
            id:'ForwardButton',
            type:'rect',
            rect:['915','167','auto','auto','auto','auto']
         },
         {
            id:'BackButton',
            type:'rect',
            rect:['839','167','auto','auto','auto','auto']
         },
         {
            id:'shoreline',
            type:'image',
            rect:['0','0','452px','300px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"shoreline.png",'0px','0px']
         },
         {
            id:'TxtScr1',
            type:'text',
            rect:['328px','25px','344px','215px','auto','auto'],
            text:"An Underwater panther, called Mishipeshu or Mishibijiw in Ojibwe, is one of the several and most important water beings among many Great Lakes and Northeastern Woodlands Native American tribes.<br>",
            font:['Lucida Sans Unicode, Lucida Grande, sans-serif',18,"rgba(255,255,255,1.00)","normal","none",""],
            textShadow:["rgba(0,0,0,0.648438)",3,3,3]
         },
         {
            id:'pictographs',
            type:'image',
            rect:['0','0','528px','300px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"pictographs.png",'0px','0px']
         },
         {
            id:'TxtScr2',
            type:'text',
            rect:['328px','25px','344px','215px','auto','auto'],
            text:"Mishipeshu translates into \"The Great Lynx.\" It has the head and paws of a giant cat but is covered in scales and has dagger-like spikes running along its back and tail.<br>",
            font:['Lucida Sans Unicode, Lucida Grande, sans-serif',18,"rgba(255,255,255,1.00)","normal","none",""],
            textShadow:["rgba(0,0,0,0.648438)",3,3,3]
         },
         {
            id:'forest',
            type:'image',
            rect:['0','0','487px','300px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"forest.png",'0px','0px']
         },
         {
            id:'TxtScr3',
            type:'text',
            rect:['328px','25px','344px','215px','auto','auto'],
            text:"To the Algonquins, the underwater panther was the most powerful underworld being. The Ojibwe traditionally held them to be masters of all water creatures, including snakes.<br>",
            font:['Lucida Sans Unicode, Lucida Grande, sans-serif',18,"rgba(255,255,255,1.00)","normal","none",""],
            textShadow:["rgba(0,0,0,0.648438)",3,3,3]
         },
         {
            id:'rocks',
            type:'image',
            rect:['0','0','549px','300px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"rocks.png",'0px','0px']
         },
         {
            id:'TxtScr4',
            display:'none',
            type:'text',
            rect:['328px','25px','344px','215px','auto','auto'],
            text:"The history of Mishipeshu is legend for some but for relatives of, and the Algonquin Indians, it is as real as the water and precious metal it guarded: the vast amounts of copper in Lake Superior, and the Great Lakes Region.",
            font:['Lucida Sans Unicode, Lucida Grande, sans-serif',18,"rgba(255,255,255,1.00)","normal","none",""],
            textShadow:["rgba(0,0,0,0.648438)",3,3,3]
         },
         {
            id:'wave_anim',
            type:'rect',
            rect:['-75','212','auto','auto','auto','auto']
         }],
         symbolInstances: [
         {
            id:'BackButton',
            symbolName:'BackButton'
         },
         {
            id:'ForwardButton',
            symbolName:'ForwardButton'
         },
         {
            id:'wave_anim',
            symbolName:'wave_anim'
         }
         ]
      },
   states: {
      "Base State": {
         "${_rocks}": [
            ["style", "opacity", '0']
         ],
         "${_TxtScr4}": [
            ["subproperty", "textShadow.blur", '3px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '3px'],
            ["style", "left", '328px'],
            ["style", "width", '344.0666809082px'],
            ["style", "top", '25px'],
            ["style", "font-size", '18px'],
            ["style", "height", '215px'],
            ["style", "overflow", 'visible'],
            ["style", "display", 'none'],
            ["style", "font-family", 'Lucida Sans Unicode, Lucida Grande, sans-serif'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.648438)'],
            ["style", "opacity", '0.000000']
         ],
         "${_Mishipeshu}": [
            ["style", "left", '698.46px'],
            ["style", "top", '12.25px']
         ],
         "${_shoreline}": [
            ["style", "display", 'block'],
            ["style", "opacity", '0']
         ],
         "${_MishipeshuIcon}": [
            ["style", "width", '']
         ],
         "${_TxtScr3}": [
            ["subproperty", "textShadow.blur", '3px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '3px'],
            ["style", "left", '328px'],
            ["style", "width", '344.0666809082px'],
            ["style", "top", '25px'],
            ["style", "opacity", '0.000000'],
            ["style", "height", '215px'],
            ["style", "overflow", 'visible'],
            ["style", "display", 'block'],
            ["style", "font-family", 'Lucida Sans Unicode, Lucida Grande, sans-serif'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.648438)'],
            ["style", "font-size", '18px']
         ],
         "${_pictographs}": [
            ["style", "display", 'block'],
            ["style", "opacity", '0']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '1000px'],
            ["style", "height", '300px'],
            ["style", "overflow", 'hidden']
         ],
         "${_TxtScr1}": [
            ["subproperty", "textShadow.blur", '3px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '3px'],
            ["style", "left", '328px'],
            ["style", "width", '344.0666809082px'],
            ["style", "top", '25px'],
            ["style", "opacity", '0'],
            ["style", "height", '215px'],
            ["style", "overflow", 'visible'],
            ["style", "display", 'block'],
            ["style", "font-family", 'Lucida Sans Unicode, Lucida Grande, sans-serif'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.648438)'],
            ["style", "font-size", '18px']
         ],
         "${_forest}": [
            ["style", "display", 'block'],
            ["style", "opacity", '0']
         ],
         "${_TxtScr2}": [
            ["subproperty", "textShadow.blur", '3px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '3px'],
            ["style", "left", '328px'],
            ["style", "width", '344.0666809082px'],
            ["style", "top", '25px'],
            ["style", "font-size", '18px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.648438)'],
            ["style", "overflow", 'visible'],
            ["style", "height", '215px'],
            ["style", "font-family", 'Lucida Sans Unicode, Lucida Grande, sans-serif'],
            ["style", "display", 'block'],
            ["style", "opacity", '0.000000']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 5500,
         autoPlay: true,
         labels: {
            "Scr1": 1000,
            "Scr2": 2500,
            "Scr3": 4000,
            "Scr4": 5500
         },
         timeline: [
            { id: "eid23", tween: [ "style", "${_TxtScr1}", "opacity", '1', { fromValue: '0.000000'}], position: 500, duration: 500 },
            { id: "eid30", tween: [ "style", "${_pictographs}", "opacity", '1', { fromValue: '0.000000'}], position: 1500, duration: 500 },
            { id: "eid49", tween: [ "style", "${_TxtScr4}", "opacity", '1', { fromValue: '0.000000'}], position: 5000, duration: 500 },
            { id: "eid20", tween: [ "style", "${_shoreline}", "opacity", '1', { fromValue: '0.000000'}], position: 0, duration: 500 },
            { id: "eid47", tween: [ "style", "${_forest}", "display", 'none', { fromValue: 'block'}], position: 4500, duration: 0 },
            { id: "eid40", tween: [ "style", "${_TxtScr3}", "display", 'none', { fromValue: 'block'}], position: 4500, duration: 0 },
            { id: "eid36", tween: [ "style", "${_TxtScr2}", "opacity", '1', { fromValue: '0.000000'}], position: 2000, duration: 500 },
            { id: "eid41", tween: [ "style", "${_TxtScr3}", "opacity", '1', { fromValue: '0.000000'}], position: 3500, duration: 500 },
            { id: "eid31", tween: [ "style", "${_TxtScr1}", "display", 'none', { fromValue: 'block'}], position: 1500, duration: 0 },
            { id: "eid42", tween: [ "style", "${_pictographs}", "display", 'none', { fromValue: 'block'}], position: 3000, duration: 0 },
            { id: "eid48", tween: [ "style", "${_TxtScr4}", "display", 'block', { fromValue: 'none'}], position: 5000, duration: 0 },
            { id: "eid50", tween: [ "style", "${_TxtScr4}", "display", 'block', { fromValue: 'block'}], position: 5500, duration: 0 },
            { id: "eid39", tween: [ "style", "${_forest}", "opacity", '1', { fromValue: '0.000000'}], position: 3000, duration: 500 },
            { id: "eid32", tween: [ "style", "${_shoreline}", "display", 'none', { fromValue: 'block'}], position: 1500, duration: 0 },
            { id: "eid35", tween: [ "style", "${_TxtScr2}", "display", 'none', { fromValue: 'block'}], position: 3000, duration: 0 },
            { id: "eid46", tween: [ "style", "${_rocks}", "opacity", '1', { fromValue: '0.000000'}], position: 4500, duration: 500 }         ]
      }
   }
},
"wave_anim": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.180",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'wave',
      type: 'image',
      rect: ['0px','0px','1150px','118px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/wave.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_wave}": [
            ["style", "left", '0px'],
            ["style", "top", '0.01px']
         ],
         "${symbolSelector}": [
            ["style", "height", '118px'],
            ["style", "width", '1150px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 5000,
         autoPlay: true,
         timeline: [
            { id: "eid7", tween: [ "style", "${_wave}", "left", '9.35px', { fromValue: '0px'}], position: 0, duration: 1000 },
            { id: "eid9", tween: [ "style", "${_wave}", "left", '-12.01px', { fromValue: '9.35px'}], position: 1000, duration: 1000 },
            { id: "eid11", tween: [ "style", "${_wave}", "left", '7.23px', { fromValue: '-12.01px'}], position: 2000, duration: 1049 },
            { id: "eid13", tween: [ "style", "${_wave}", "left", '-24.56px', { fromValue: '7.23px'}], position: 3049, duration: 951 },
            { id: "eid15", tween: [ "style", "${_wave}", "left", '0px', { fromValue: '-24.56px'}], position: 4000, duration: 1000 },
            { id: "eid8", tween: [ "style", "${_wave}", "top", '-13.42px', { fromValue: '0.01px'}], position: 0, duration: 1000 },
            { id: "eid10", tween: [ "style", "${_wave}", "top", '-22.38px', { fromValue: '-13.42px'}], position: 1000, duration: 1000 },
            { id: "eid12", tween: [ "style", "${_wave}", "top", '0px', { fromValue: '-22.38px'}], position: 2000, duration: 1049 },
            { id: "eid14", tween: [ "style", "${_wave}", "top", '-12.09px', { fromValue: '0px'}], position: 3049, duration: 951 },
            { id: "eid16", tween: [ "style", "${_wave}", "top", '0px', { fromValue: '-12.09px'}], position: 4000, duration: 1000 }         ]
      }
   }
},
"BackButton": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.180",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['0px','0px','71px','73px','auto','auto'],
      id: 'bkBtn',
      type: 'image',
      cursor: ['pointer'],
      fill: ['rgba(0,0,0,0)','images/bkBtn.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bkBtn}": [
            ["style", "top", '0px'],
            ["style", "opacity", '1'],
            ["style", "left", '0px'],
            ["style", "cursor", 'pointer']
         ],
         "${symbolSelector}": [
            ["style", "height", '73px'],
            ["style", "width", '71px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         labels: {
            "Normal": 0,
            "Over": 1000
         },
         timeline: [
            { id: "eid54", tween: [ "style", "${_bkBtn}", "opacity", '0.69577090234375', { fromValue: '1'}], position: 0, duration: 1000 }         ]
      }
   }
},
"ForwardButton": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.180",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['0px','0px','71px','73px','auto','auto'],
      id: 'fwdBtn',
      type: 'image',
      cursor: ['pointer'],
      fill: ['rgba(0,0,0,0)','images/fwdBtn.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_fwdBtn}": [
            ["style", "top", '0.01px'],
            ["style", "opacity", '1'],
            ["style", "left", '0.01px'],
            ["style", "cursor", 'pointer']
         ],
         "${symbolSelector}": [
            ["style", "height", '73px'],
            ["style", "width", '71px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         labels: {
            "Normal": 0,
            "Over": 1000
         },
         timeline: [
            { id: "eid57", tween: [ "style", "${_fwdBtn}", "opacity", '0.69534301757812', { fromValue: '1'}], position: 0, duration: 1000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-163934610");
