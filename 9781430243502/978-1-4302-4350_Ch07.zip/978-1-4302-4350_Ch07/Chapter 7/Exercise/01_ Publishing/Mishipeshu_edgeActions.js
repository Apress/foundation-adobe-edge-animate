/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1000, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1000, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2500, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 4000, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 5500, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'wave_anim'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 5000, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play(0);

      });
      //Edge binding end

   })("wave_anim");
   //Edge symbol end:'wave_anim'

   //=========================================================
   
   //Edge symbol: 'BackButton'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1000, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bkBtn}", "mouseover", function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play('Over');
         
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bkBtn}", "mouseout", function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play('Normal');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bkBtn}", "click", function(sym, e) {
         sym.getComposition().getStage().playReverse();

      });
      //Edge binding end

   })("BackButton");
   //Edge symbol end:'BackButton'

   //=========================================================
   
   //Edge symbol: 'ForwardButton'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1000, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_fwdBtn}", "mouseover", function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play('Over');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_fwdBtn}", "mouseout", function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play('Normal');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_fwdBtn}", "click", function(sym, e) {
         sym.getComposition().getStage().play();
         

      });
      //Edge binding end

   })("ForwardButton");
   //Edge symbol end:'ForwardButton'

   //=========================================================
   
   //Edge symbol: 'Down-level'
   (function(symbolName) {   
   
   })("Down-level");
   //Edge symbol end:'Down-level'

})(jQuery, AdobeEdge, "EDGE-163934610");