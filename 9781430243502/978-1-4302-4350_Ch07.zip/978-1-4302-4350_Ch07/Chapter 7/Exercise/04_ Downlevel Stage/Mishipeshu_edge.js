/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.171",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'BG',
            type:'image',
            rect:['0','0','1000px','300px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"BG.jpg",'0px','0px']
         },
         {
            id:'shoreline',
            type:'image',
            rect:['0','0','538px','300px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"shoreline.png",'0px','0px']
         },
         {
            id:'TextScr1',
            type:'text',
            rect:['366px','23px','313px','215px','auto','auto'],
            text:"An Underwater panther, called Mishipeshu or Mishibijiw in Ojibwe, is one of the several and most important water beings among many Great Lakes and Northeastern Woodlands Native American tribes.",
            font:['Lucida Sans Unicode, Lucida Grande, sans-serif',18,"rgba(255,255,255,1.00)","normal","none",""],
            textShadow:["rgba(0,0,0,0.648438)",3,3,5]
         },
         {
            id:'pictographs',
            type:'image',
            rect:['0','0','539px','300px','auto','auto'],
            opacity:0,
            fill:["rgba(0,0,0,0)",im+"pictographs.png",'0px','0px']
         },
         {
            id:'TextScr2',
            type:'text',
            rect:['366px','23px','313px','215px','auto','auto'],
            text:"Mishipeshu translates into \"The Great Lynx.\" It has the head and paws of a giant cat but is covered in scales and has dagger-like spikes running along its back and tail.",
            font:['Lucida Sans Unicode, Lucida Grande, sans-serif',18,"rgba(255,255,255,1.00)","normal","none",""],
            textShadow:["rgba(0,0,0,0.648438)",3,3,5]
         },
         {
            id:'forest',
            type:'image',
            rect:['0','0','505px','300px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"forest.png",'0px','0px']
         },
         {
            id:'rocks',
            type:'image',
            rect:['0','0','556px','300px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"rocks.png",'0px','0px']
         },
         {
            id:'TextScr3',
            type:'text',
            rect:['366px','23px','313px','215px','auto','auto'],
            text:"To the Algonquins, the underwater panther was the most powerful underworld being. The Ojibwe traditionally held them to be masters of all water creatures, including snakes.",
            font:['Lucida Sans Unicode, Lucida Grande, sans-serif',18,"rgba(255,255,255,1.00)","normal","none",""],
            textShadow:["rgba(0,0,0,0.648438)",3,3,5]
         },
         {
            id:'TextScr4',
            type:'text',
            rect:['366px','23px','313px','215px','auto','auto'],
            text:"The history of Mishipeshu is legend for some but for relatives of, and the Algonquin Indians, it is as real as the water and precious metal it guarded: the vast amounts of copper in Lake Superior, and the Great Lakes Region.",
            font:['Lucida Sans Unicode, Lucida Grande, sans-serif',18,"rgba(255,255,255,1.00)","normal","none",""],
            textShadow:["rgba(0,0,0,0.648438)",3,3,5]
         },
         {
            id:'Mishipeshu',
            type:'image',
            rect:['689px','12px','295px','90px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Mishipeshu.png",'0px','0px']
         },
         {
            id:'WaveAnim',
            type:'rect',
            rect:['-87','203','auto','auto','auto','auto']
         },
         {
            id:'bkBtn',
            type:'image',
            rect:['863px','161px','59px','60px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"bkBtn.png",'0px','0px']
         },
         {
            id:'fwdBtn',
            type:'image',
            rect:['931px','161px','60px','60px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"fwdBtn.png",'0px','0px']
         }],
         symbolInstances: [
         {
            id:'WaveAnim',
            symbolName:'WaveAnim'
         }
         ]
      },
   states: {
      "Base State": {
         "${_TextScr2}": [
            ["subproperty", "textShadow.blur", '5px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '3px'],
            ["style", "left", '365.87px'],
            ["style", "width", '312.60000610352px'],
            ["style", "top", '23.28px'],
            ["style", "font-size", '18px'],
            ["style", "height", '215.36953735352px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.648438)'],
            ["style", "font-family", 'Lucida Sans Unicode, Lucida Grande, sans-serif'],
            ["style", "opacity", '0.000000']
         ],
         "${_TextScr3}": [
            ["subproperty", "textShadow.blur", '5px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '3px'],
            ["style", "left", '365.87px'],
            ["style", "width", '312.60000610352px'],
            ["style", "top", '23.28px'],
            ["style", "opacity", '0.000000'],
            ["style", "height", '215.36953735352px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.648438)'],
            ["style", "font-family", 'Lucida Sans Unicode, Lucida Grande, sans-serif'],
            ["style", "font-size", '18px']
         ],
         "${_Mishipeshu}": [
            ["style", "left", '689.34px'],
            ["style", "top", '11.55px']
         ],
         "${_shoreline}": [
            ["style", "opacity", '0']
         ],
         "${_TextScr4}": [
            ["subproperty", "textShadow.blur", '5px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '3px'],
            ["style", "left", '365.87px'],
            ["style", "width", '312.60000610352px'],
            ["style", "top", '23.28px'],
            ["style", "font-size", '18px'],
            ["style", "height", '215.36953735352px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.648438)'],
            ["style", "font-family", 'Lucida Sans Unicode, Lucida Grande, sans-serif'],
            ["style", "opacity", '0.000000']
         ],
         "${_pictographs}": [
            ["style", "opacity", '0']
         ],
         "${_rocks}": [
            ["style", "opacity", '0']
         ],
         "${_forest}": [
            ["style", "opacity", '0']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '300px'],
            ["style", "width", '1000px']
         ],
         "${_fwdBtn}": [
            ["style", "top", '161px'],
            ["style", "opacity", '1'],
            ["style", "left", '931.41px']
         ],
         "${_TextScr1}": [
            ["subproperty", "textShadow.blur", '5px'],
            ["subproperty", "textShadow.offsetH", '3px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.offsetV", '3px'],
            ["style", "left", '365.87px'],
            ["style", "width", '312.60000610352px'],
            ["style", "top", '23.28px'],
            ["style", "opacity", '0'],
            ["style", "height", '215.36953735352px'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.648438)'],
            ["style", "font-family", 'Lucida Sans Unicode, Lucida Grande, sans-serif'],
            ["style", "font-size", '18px']
         ],
         "${_bkBtn}": [
            ["style", "top", '161px'],
            ["style", "opacity", '0'],
            ["style", "left", '863.41px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 4000,
         autoPlay: true,
         labels: {
            "Start": 0,
            "Scr1": 1000,
            "Scr2": 2000,
            "Scr3": 3000,
            "Scr4": 4000
         },
         timeline: [
            { id: "eid48", tween: [ "style", "${_TextScr2}", "opacity", '1', { fromValue: '0.000000'}], position: 1500, duration: 500 },
            { id: "eid58", tween: [ "style", "${_TextScr2}", "opacity", '0', { fromValue: '1'}], position: 2000, duration: 500 },
            { id: "eid45", tween: [ "style", "${_pictographs}", "opacity", '1', { fromValue: '0.000000'}], position: 1000, duration: 500 },
            { id: "eid37", tween: [ "style", "${_shoreline}", "opacity", '1', { fromValue: '0.000000'}], position: 0, duration: 1000 },
            { id: "eid46", tween: [ "style", "${_shoreline}", "opacity", '0', { fromValue: '1'}], position: 1000, duration: 500 },
            { id: "eid54", tween: [ "style", "${_TextScr3}", "opacity", '1', { fromValue: '0.000000'}], position: 2500, duration: 500 },
            { id: "eid67", tween: [ "style", "${_TextScr3}", "opacity", '0', { fromValue: '1'}], position: 3000, duration: 500 },
            { id: "eid70", tween: [ "style", "${_bkBtn}", "opacity", '1', { fromValue: '0.000000'}], position: 1544, duration: 456 },
            { id: "eid72", tween: [ "style", "${_fwdBtn}", "opacity", '0.014373779296875', { fromValue: '1'}], position: 3500, duration: 500 },
            { id: "eid63", tween: [ "style", "${_TextScr4}", "opacity", '1', { fromValue: '0.000000'}], position: 3500, duration: 500 },
            { id: "eid42", tween: [ "style", "${_TextScr1}", "opacity", '1', { fromValue: '0.000000'}], position: 500, duration: 500 },
            { id: "eid47", tween: [ "style", "${_TextScr1}", "opacity", '0', { fromValue: '1'}], position: 1000, duration: 500 },
            { id: "eid53", tween: [ "style", "${_forest}", "opacity", '1', { fromValue: '0.000000'}], position: 2000, duration: 500 },
            { id: "eid62", tween: [ "style", "${_rocks}", "opacity", '1', { fromValue: '0.000000'}], position: 3000, duration: 500 }         ]
      }
   }
},
"WaveAnim": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.171",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'wave',
      type: 'image',
      rect: ['0px','0px','1150px','114px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/wave.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '114px'],
            ["style", "width", '1150px']
         ],
         "${_wave}": [
            ["style", "left", '-0.01px'],
            ["style", "top", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 5750,
         autoPlay: true,
         timeline: [
            { id: "eid3", tween: [ "style", "${_wave}", "left", '50.98px', { fromValue: '-0.01px'}], position: 0, duration: 500 },
            { id: "eid10", tween: [ "style", "${_wave}", "left", '45.4px', { fromValue: '50.98px'}], position: 1000, duration: 500 },
            { id: "eid12", tween: [ "style", "${_wave}", "left", '7.48px', { fromValue: '45.4px'}], position: 1500, duration: 500 },
            { id: "eid14", tween: [ "style", "${_wave}", "left", '0px', { fromValue: '7.48px'}], position: 2000, duration: 435 },
            { id: "eid16", tween: [ "style", "${_wave}", "left", '17.3px', { fromValue: '0px'}], position: 2435, duration: 565 },
            { id: "eid18", tween: [ "style", "${_wave}", "left", '13.03px', { fromValue: '17.3px'}], position: 3000, duration: 500 },
            { id: "eid20", tween: [ "style", "${_wave}", "left", '-14.78px', { fromValue: '13.03px'}], position: 3500, duration: 500 },
            { id: "eid27", tween: [ "style", "${_wave}", "left", '8.09px', { fromValue: '-14.78px'}], position: 4000, duration: 500 },
            { id: "eid29", tween: [ "style", "${_wave}", "left", '-8.48px', { fromValue: '8.09px'}], position: 4500, duration: 456 },
            { id: "eid31", tween: [ "style", "${_wave}", "left", '-12.06px', { fromValue: '-8.48px'}], position: 4956, duration: 294 },
            { id: "eid33", tween: [ "style", "${_wave}", "left", '0px', { fromValue: '-12.06px'}], position: 5250, duration: 500 },
            { id: "eid8", tween: [ "style", "${_wave}", "top", '12.11px', { fromValue: '0px'}], position: 0, duration: 500 },
            { id: "eid6", tween: [ "style", "${_wave}", "top", '10.59px', { fromValue: '12.11px'}], position: 500, duration: 500 },
            { id: "eid11", tween: [ "style", "${_wave}", "top", '-13.47px', { fromValue: '10.59px'}], position: 1000, duration: 500 },
            { id: "eid13", tween: [ "style", "${_wave}", "top", '-8.17px', { fromValue: '-13.47px'}], position: 1500, duration: 500 },
            { id: "eid15", tween: [ "style", "${_wave}", "top", '0px', { fromValue: '-8.17px'}], position: 2000, duration: 435 },
            { id: "eid17", tween: [ "style", "${_wave}", "top", '-13.14px', { fromValue: '0px'}], position: 2435, duration: 565 },
            { id: "eid19", tween: [ "style", "${_wave}", "top", '-16.23px', { fromValue: '-13.14px'}], position: 3000, duration: 500 },
            { id: "eid21", tween: [ "style", "${_wave}", "top", '4.53px', { fromValue: '-16.23px'}], position: 3500, duration: 500 },
            { id: "eid28", tween: [ "style", "${_wave}", "top", '20.47px', { fromValue: '4.53px'}], position: 4000, duration: 500 },
            { id: "eid30", tween: [ "style", "${_wave}", "top", '33.05px', { fromValue: '20.47px'}], position: 4500, duration: 456 },
            { id: "eid32", tween: [ "style", "${_wave}", "top", '21.81px', { fromValue: '33.05px'}], position: 4956, duration: 294 },
            { id: "eid34", tween: [ "style", "${_wave}", "top", '0px', { fromValue: '21.81px'}], position: 5250, duration: 500 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-910426815");
