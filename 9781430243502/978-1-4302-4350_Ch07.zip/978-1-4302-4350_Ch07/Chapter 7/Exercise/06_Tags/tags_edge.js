/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.180",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Content',
            type:'rect',
            rect:['8px','12px','770px','367px','auto','auto'],
            borderRadius:["20px 20px","20px 20px","20px 20px","20px 20px"],
            fill:["rgba(235,238,220,1.00)"],
            stroke:[6,"rgba(0,0,0,1)","solid"],
            c:[
            {
               id:'soup',
               type:'image',
               rect:['41px','82px','300px','248px','auto','auto'],
               fill:["rgba(0,0,0,0)",im+"soup.jpg",'0px','0px']
            },
            {
               id:'SoupTitle',
               type:'text',
               rect:['35px','22px','auto','auto','auto','auto'],
               text:"Chicken Soup",
               font:['Arial, Helvetica, sans-serif',50,"rgba(0,0,0,1)","normal","none",""]
            },
            {
               id:'Description',
               type:'text',
               rect:['411px','188px','325px','auto','auto','auto'],
               text:"Chicken noodle soup is a delicious soup that warms the soul with flavor. It is relatively easy to make and can serve many hungry souls. ",
               align:"left",
               font:['Arial, Helvetica, sans-serif',16,"rgba(0,0,0,1)","normal","none","normal"]
            },
            {
               id:'IngredientsTxt',
               type:'text',
               rect:['401px','102px','345px','85px','auto','auto'],
               text:"chicken, noodles, carrots, cellery, onions, garlic, parsley, chicken stock, croutons, salt and pepper",
               align:"left",
               font:['Arial, Helvetica, sans-serif',20,"rgba(0,0,0,1)","normal","none","normal"]
            },
            {
               id:'logo',
               type:'image',
               rect:['680px','278px','80px','80px','auto','auto'],
               fill:["rgba(0,0,0,0)",im+"logo.png",'0px','0px']
            },
            {
               id:'IngredientBox',
               type:'rect',
               rect:['498px','31px','261px','27px','auto','auto'],
               borderRadius:["5px 5px","0px","0px","5px 5px"],
               fill:["rgba(0,0,0,1.00)"],
               stroke:[6,"rgba(0,0,0,0.00)","solid"],
               c:[
               {
                  id:'Ingredients',
                  type:'text',
                  rect:['10px','0px','auto','auto','auto','auto'],
                  text:"Ingredients",
                  font:['Arial, Helvetica, sans-serif',24,"rgba(255,255,255,1.00)","normal","none",""]
               }]
            }]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_soup}": [
            ["style", "left", '41px'],
            ["style", "top", '82.47px']
         ],
         "${_logo}": [
            ["style", "left", '679.75px'],
            ["style", "top", '277.78px']
         ],
         "${_IngredientsTxt}": [
            ["style", "top", '102.47px'],
            ["style", "height", '85.188804626465px'],
            ["style", "width", '344.76666259766px'],
            ["style", "left", '401px'],
            ["style", "font-size", '20px']
         ],
         "${_IngredientBox}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "border-top-left-radius", [5,5], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-left-radius", [5,5], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "top", '31.48px'],
            ["style", "height", '27.349998474121px'],
            ["color", "border-color", 'rgba(0,0,0,0.00)'],
            ["style", "left", '497.75px'],
            ["style", "width", '260.70782470703px']
         ],
         "${_SoupTitle}": [
            ["style", "top", '22.48px'],
            ["style", "left", '35px'],
            ["style", "font-size", '50px']
         ],
         "${_Content}": [
            ["color", "background-color", 'rgba(235,238,220,1.00)'],
            ["style", "border-top-left-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '6px'],
            ["style", "width", '770.40002441406px'],
            ["style", "top", '11.52px'],
            ["style", "border-bottom-left-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "height", '366.50390625px'],
            ["style", "left", '8px'],
            ["style", "border-top-right-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ]
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,0.00)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '400px'],
            ["style", "width", '800px']
         ],
         "${_Description}": [
            ["style", "top", '187.62px'],
            ["style", "font-size", '16px'],
            ["style", "left", '411px'],
            ["style", "width", '324.73229980469px']
         ],
         "${_Ingredients}": [
            ["style", "top", '-0.03px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "left", '10.4px'],
            ["style", "font-size", '24px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-47938010");
