/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Content_bkgrnd',
            type:'image',
            rect:['272px','78px','511px','468px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Contain.png",'0px','0px']
         },
         {
            id:'NavBkgrnd',
            type:'image',
            rect:['17px','147px','245px','278px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"NavBkgrnd.png",'0px','0px']
         },
         {
            id:'Google_btn',
            type:'image',
            rect:['61px','238px','158px','35px','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"Google.png",'0px','0px']
         },
         {
            id:'YouTube_btn',
            type:'image',
            rect:['61px','305px','158px','35px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"YouTube.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_YouTube_btn}": [
            ["style", "top", '305.25px'],
            ["style", "left", '61px']
         ],
         "${_NavBkgrnd}": [
            ["style", "left", '17px'],
            ["style", "top", '147.25px']
         ],
         "${_Google_btn}": [
            ["style", "top", '237.72px'],
            ["style", "left", '61px'],
            ["style", "cursor", 'pointer']
         ],
         "${_Content_bkgrnd}": [
            ["style", "left", '272.1px'],
            ["style", "top", '77.87px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "width", '800px'],
            ["style", "height", '600px'],
            ["style", "overflow", 'hidden']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-49654456");
