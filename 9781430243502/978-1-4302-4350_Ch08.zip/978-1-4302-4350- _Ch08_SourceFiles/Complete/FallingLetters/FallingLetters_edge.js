/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Background',
            type:'image',
            rect:['0','0','900','602','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Background.jpg"],
            transform:[]
         },
         {
            id:'E2',
            type:'image',
            rect:['589','197','119','207','auto','auto'],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"E2.png"],
            transform:[]
         },
         {
            id:'G',
            type:'image',
            rect:['450','195','139','212','auto','auto'],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"G.png"],
            transform:[]
         },
         {
            id:'D',
            type:'image',
            rect:['322','198','136','206','auto','auto'],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"D.png"],
            transform:[]
         },
         {
            id:'E',
            type:'image',
            rect:['170','196','152','207','auto','auto'],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"E.png"],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_G}": [
            ["style", "top", '-214.66px'],
            ["style", "opacity", '0'],
            ["style", "left", '449.67px']
         ],
         "${_E2}": [
            ["style", "top", '-212.66px'],
            ["style", "opacity", '0'],
            ["style", "left", '588.54px']
         ],
         "${_D}": [
            ["style", "top", '-211.66px'],
            ["style", "opacity", '0'],
            ["style", "left", '321.54px']
         ],
         "${_Stage}": [
            ["style", "height", '600px'],
            ["color", "background-color", 'rgba(204,204,204,1)'],
            ["style", "width", '900px']
         ],
         "${_E}": [
            ["style", "top", '-213.41px'],
            ["style", "opacity", '0'],
            ["style", "left", '169.59px']
         ],
         "${_Background}": [
            ["style", "left", '0.25px'],
            ["style", "top", '-0.37px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1750,
         autoPlay: true,
         timeline: [
            { id: "eid28", tween: [ "style", "${_G}", "top", '194.63px', { fromValue: '-214.66px'}], position: 500, duration: 1000, easing: "easeOutBounce" },
            { id: "eid27", tween: [ "style", "${_E2}", "top", '196.63px', { fromValue: '-212.66px'}], position: 750, duration: 1000, easing: "easeOutBounce" },
            { id: "eid14", tween: [ "style", "${_E}", "opacity", '1', { fromValue: '0'}], position: 0, duration: 1000, easing: "easeOutBounce" },
            { id: "eid32", tween: [ "style", "${_D}", "opacity", '1', { fromValue: '0'}], position: 250, duration: 1000, easing: "easeOutBounce" },
            { id: "eid30", tween: [ "style", "${_E2}", "opacity", '1', { fromValue: '0'}], position: 750, duration: 1000, easing: "easeOutBounce" },
            { id: "eid12", tween: [ "style", "${_E}", "top", '195.89px', { fromValue: '-213.41px'}], position: 0, duration: 1000, easing: "easeOutBounce" },
            { id: "eid31", tween: [ "style", "${_G}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 1000, easing: "easeOutBounce" },
            { id: "eid29", tween: [ "style", "${_D}", "top", '197.63px', { fromValue: '-211.66px'}], position: 250, duration: 1000, easing: "easeOutBounce" }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-394688103");
