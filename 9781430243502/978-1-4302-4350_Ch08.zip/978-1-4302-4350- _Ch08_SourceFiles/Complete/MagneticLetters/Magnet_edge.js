/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Background',
            type:'image',
            rect:['0','0','720px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Background.jpg"]
         },
         {
            id:'Magnet',
            type:'image',
            rect:['-190','71','190px','235px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Magnet.svg"],
            transform:[]
         },
         {
            id:'ShadowE2',
            type:'image',
            rect:['488','406','125px','14px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Shadow.png"]
         },
         {
            id:'E2',
            type:'image',
            rect:['488','351','126px','55px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"E.svg"],
            transform:[]
         },
         {
            id:'ShadowG',
            type:'image',
            rect:['346','406','125px','14px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Shadow.png"],
            transform:[]
         },
         {
            id:'G',
            type:'image',
            rect:['343','350','131px','56px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"G.svg"],
            transform:[]
         },
         {
            id:'ShadowD',
            type:'image',
            rect:['203','406','125px','14px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Shadow.png"],
            transform:[]
         },
         {
            id:'D',
            type:'image',
            rect:['200','350','131px','56px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"D.svg"],
            transform:[]
         },
         {
            id:'ShadowE',
            type:'image',
            rect:['51','406','125px','14px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Shadow.png"],
            transform:[]
         },
         {
            id:'E',
            type:'image',
            rect:['51','350','126px','55px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"E.svg"],
            transform:[[],['0deg'],[],['1','1.111']]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Magnet}": [
            ["style", "left", '-190px'],
            ["style", "top", '2px']
         ],
         "${_E2}": [
            ["style", "left", '488px'],
            ["style", "top", '351px']
         ],
         "${_ShadowG}": [
            ["style", "left", '346px']
         ],
         "${_ShadowD}": [
            ["style", "left", '203px'],
            ["style", "top", '406px']
         ],
         "${_ShadowE}": [
            ["style", "top", '406px'],
            ["transform", "scaleY", '1'],
            ["style", "display", 'block'],
            ["style", "opacity", '1'],
            ["style", "left", '51px'],
            ["transform", "scaleX", '1px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "height", '480px'],
            ["style", "width", '720px']
         ],
         "${_E}": [
            ["transform", "rotateZ", '0deg'],
            ["transform", "scaleX", '1'],
            ["style", "left", '51px'],
            ["style", "width", '126px'],
            ["style", "top", '350px'],
            ["transform", "skewY", '0deg'],
            ["transform", "skewX", '0deg'],
            ["style", "height", '55px'],
            ["transform", "scaleY", '1.11111']
         ],
         "${_G}": [
            ["style", "left", '343px'],
            ["style", "top", '350px']
         ],
         "${_D}": [
            ["style", "left", '200px'],
            ["style", "top", '350px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         timeline: [
            { id: "eid37", tween: [ "transform", "${_E}", "scaleX", '0.72', { fromValue: '1'}], position: 1250, duration: 450, easing: "easeOutSine" },
            { id: "eid64", tween: [ "transform", "${_E}", "scaleX", '0.81', { fromValue: '0.72'}], position: 1700, duration: 50, easing: "easeOutSine" },
            { id: "eid106", tween: [ "style", "${_E}", "left", '217px', { fromValue: '51px'}], position: 1750, duration: 250, easing: "easeOutSine" },
            { id: "eid53", tween: [ "transform", "${_ShadowE}", "scaleY", '1.3', { fromValue: '1'}], position: 1000, duration: 250, easing: "easeOutSine" },
            { id: "eid55", tween: [ "transform", "${_ShadowE}", "scaleY", '2.12', { fromValue: '1.3'}], position: 1250, duration: 250, easing: "easeOutSine" },
            { id: "eid57", tween: [ "transform", "${_ShadowE}", "scaleY", '0.7', { fromValue: '2.12'}], position: 1500, duration: 200, easing: "easeOutSine" },
            { id: "eid44", tween: [ "transform", "${_E}", "skewY", '-6deg', { fromValue: '0deg'}], position: 1250, duration: 450, easing: "easeOutSine" },
            { id: "eid63", tween: [ "transform", "${_E}", "skewY", '-11deg', { fromValue: '-6deg'}], position: 1700, duration: 50, easing: "easeOutSine" },
            { id: "eid46", tween: [ "style", "${_E}", "top", '204px', { fromValue: '350px'}], position: 1700, duration: 50, easing: "easeOutSine" },
            { id: "eid47", tween: [ "style", "${_ShadowE}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0, easing: "easeOutSine" },
            { id: "eid61", tween: [ "style", "${_ShadowE}", "display", 'none', { fromValue: 'block'}], position: 1750, duration: 0, easing: "easeOutSine" },
            { id: "eid2", tween: [ "style", "${_Magnet}", "left", '20px', { fromValue: '-190px'}], position: 0, duration: 750 },
            { id: "eid105", tween: [ "style", "${_Magnet}", "left", '180px', { fromValue: '20px'}], position: 1750, duration: 250, easing: "easeOutSine" },
            { id: "eid38", tween: [ "transform", "${_E}", "scaleY", '0.98', { fromValue: '1.11111'}], position: 1250, duration: 450, easing: "easeOutSine" },
            { id: "eid65", tween: [ "transform", "${_E}", "scaleY", '1.47', { fromValue: '0.98'}], position: 1700, duration: 50, easing: "easeOutSine" },
            { id: "eid50", tween: [ "transform", "${_ShadowE}", "scaleX", '1.1', { fromValue: '1'}], position: 750, duration: 250, easing: "easeOutSine" },
            { id: "eid52", tween: [ "transform", "${_ShadowE}", "scaleX", '1.32', { fromValue: '1.1'}], position: 1000, duration: 250, easing: "easeOutSine" },
            { id: "eid56", tween: [ "transform", "${_ShadowE}", "scaleX", '1.08', { fromValue: '1.32'}], position: 1250, duration: 250, easing: "easeOutSine" },
            { id: "eid58", tween: [ "transform", "${_ShadowE}", "scaleX", '0.25', { fromValue: '1.08'}], position: 1500, duration: 200, easing: "easeOutSine" },
            { id: "eid40", tween: [ "transform", "${_E}", "skewX", '-52deg', { fromValue: '0deg'}], position: 1250, duration: 450, easing: "easeOutSine" },
            { id: "eid62", tween: [ "transform", "${_E}", "skewX", '-27deg', { fromValue: '-52deg'}], position: 1700, duration: 50, easing: "easeOutSine" },
            { id: "eid110", tween: [ "style", "${_ShadowE}", "opacity", '0', { fromValue: '1'}], position: 1700, duration: 50, easing: "easeOutSine" },
            { id: "eid31", tween: [ "transform", "${_E}", "rotateZ", '-8deg', { fromValue: '0deg'}], position: 750, duration: 250, easing: "easeOutSine" },
            { id: "eid36", tween: [ "transform", "${_E}", "rotateZ", '8deg', { fromValue: '-8deg'}], position: 1000, duration: 250, easing: "easeOutSine" },
            { id: "eid39", tween: [ "transform", "${_E}", "rotateZ", '3deg', { fromValue: '8deg'}], position: 1250, duration: 450, easing: "easeOutSine" }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-113786299");
