/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Lake',
            type:'image',
            rect:['0','0','900px','284px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Lake.jpg"]
         },
         {
            id:'Starfield',
            type:'rect',
            rect:['78','14','auto','auto','auto','auto']
         },
         {
            id:'Shooting_Star',
            type:'image',
            rect:['-32','64','40px','29px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Star.png"],
            transform:[[],[],[],['0.61','0.61']]
         }],
         symbolInstances: [
         {
            id:'Starfield',
            symbolName:'Starfield'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Shooting_Star}": [
            ["style", "top", '-4px'],
            ["transform", "scaleY", '0.6'],
            ["transform", "scaleX", '0.6'],
            ["style", "opacity", '1'],
            ["style", "left", '-32px']
         ],
         "${_Stage}": [
            ["style", "height", '284px'],
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "width", '900px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         labels: {
            "Home": 0
         },
         timeline: [
            { id: "eid74", tween: [ "style", "${_Shooting_Star}", "top", '67px', { fromValue: '-4px'}], position: 0, duration: 286, easing: "easeOutSine" },
            { id: "eid95", tween: [ "style", "${_Shooting_Star}", "top", '167px', { fromValue: '67px'}], position: 286, duration: 337, easing: "easeOutSine" },
            { id: "eid94", tween: [ "style", "${_Shooting_Star}", "top", '183px', { fromValue: '167px'}], position: 624, duration: 125, easing: "easeOutSine" },
            { id: "eid89", tween: [ "style", "${_Shooting_Star}", "opacity", '0.59', { fromValue: '1'}], position: 0, duration: 750, easing: "easeOutSine" },
            { id: "eid73", tween: [ "style", "${_Shooting_Star}", "left", '582px', { fromValue: '-32px'}], position: 0, duration: 750, easing: "easeOutSine" },
            { id: "eid85", tween: [ "transform", "${_Shooting_Star}", "scaleY", '0.15', { fromValue: '0.6'}], position: 0, duration: 750, easing: "easeOutSine" },
            { id: "eid84", tween: [ "transform", "${_Shooting_Star}", "scaleX", '0.15', { fromValue: '0.6'}], position: 0, duration: 750, easing: "easeOutSine" }         ]
      }
   }
},
"Star": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      transform: [{1:0,0:0},{},{},['0.51','0.51']],
      id: 'Star2',
      type: 'image',
      rect: ['0','0','40px','29px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Star.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '29px'],
            ["style", "width", '40px']
         ],
         "${_Star2}": [
            ["transform", "scaleX", '0.51'],
            ["style", "opacity", '0.1'],
            ["transform", "scaleY", '0.51'],
            ["transform", "rotateZ", '0deg']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1500,
         autoPlay: true,
         labels: {
            "Start": 0,
            "Label 2": 500
         },
         timeline: [
            { id: "eid34", tween: [ "style", "${_Star2}", "opacity", '1', { fromValue: '0.1'}], position: 0, duration: 750 },
            { id: "eid35", tween: [ "style", "${_Star2}", "opacity", '0.1', { fromValue: '1'}], position: 750, duration: 750 },
            { id: "eid36", tween: [ "transform", "${_Star2}", "rotateZ", '360deg', { fromValue: '0deg'}], position: 0, duration: 1500 }         ]
      }
   }
},
"Star_1": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Star',
      type: 'image',
      rect: ['0','0','40px','29px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Star2.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Star}": [
            ["transform", "scaleX", '0.23'],
            ["style", "opacity", '1'],
            ["transform", "scaleY", '0.23'],
            ["transform", "rotateZ", '0deg']
         ],
         "${symbolSelector}": [
            ["style", "height", '29px'],
            ["style", "width", '40px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         labels: {
            "Start": 0
         },
         timeline: [
            { id: "eid12", tween: [ "transform", "${_Star}", "scaleX", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 },
            { id: "eid11", tween: [ "transform", "${_Star}", "rotateZ", '360deg', { fromValue: '0deg'}], position: 0, duration: 2000 },
            { id: "eid8", tween: [ "style", "${_Star}", "opacity", '0.5', { fromValue: '1'}], position: 0, duration: 912 },
            { id: "eid9", tween: [ "style", "${_Star}", "opacity", '1', { fromValue: '0.500000'}], position: 912, duration: 1087 },
            { id: "eid13", tween: [ "transform", "${_Star}", "scaleY", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 }         ]
      }
   }
},
"Star_2": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Star',
      type: 'image',
      rect: ['0','0','40px','29px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Star3.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Star}": [
            ["transform", "scaleX", '0.23'],
            ["style", "opacity", '1'],
            ["transform", "scaleY", '0.23'],
            ["transform", "rotateZ", '0deg']
         ],
         "${symbolSelector}": [
            ["style", "height", '29px'],
            ["style", "width", '40px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         labels: {
            "Start": 0
         },
         timeline: [
            { id: "eid12", tween: [ "transform", "${_Star}", "scaleX", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 },
            { id: "eid11", tween: [ "transform", "${_Star}", "rotateZ", '360deg', { fromValue: '0deg'}], position: 0, duration: 2000 },
            { id: "eid8", tween: [ "style", "${_Star}", "opacity", '0.5', { fromValue: '1'}], position: 0, duration: 912 },
            { id: "eid9", tween: [ "style", "${_Star}", "opacity", '1', { fromValue: '0.500000'}], position: 912, duration: 1087 },
            { id: "eid13", tween: [ "transform", "${_Star}", "scaleY", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 }         ]
      }
   }
},
"Star_3": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Star',
      type: 'image',
      rect: ['0','0','40px','29px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Star4.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Star}": [
            ["transform", "scaleX", '0.23'],
            ["style", "opacity", '1'],
            ["transform", "scaleY", '0.23'],
            ["transform", "rotateZ", '0deg']
         ],
         "${symbolSelector}": [
            ["style", "height", '29px'],
            ["style", "width", '40px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         labels: {
            "Start": 0
         },
         timeline: [
            { id: "eid12", tween: [ "transform", "${_Star}", "scaleX", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 },
            { id: "eid11", tween: [ "transform", "${_Star}", "rotateZ", '360deg', { fromValue: '0deg'}], position: 0, duration: 2000 },
            { id: "eid8", tween: [ "style", "${_Star}", "opacity", '0.5', { fromValue: '1'}], position: 0, duration: 912 },
            { id: "eid9", tween: [ "style", "${_Star}", "opacity", '1', { fromValue: '0.500000'}], position: 912, duration: 1087 },
            { id: "eid13", tween: [ "transform", "${_Star}", "scaleY", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 }         ]
      }
   }
},
"Star_4": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Star',
      type: 'image',
      rect: ['0','0','40px','29px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Star5.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Star}": [
            ["transform", "scaleX", '0.23'],
            ["style", "opacity", '1'],
            ["transform", "scaleY", '0.23'],
            ["transform", "rotateZ", '0deg']
         ],
         "${symbolSelector}": [
            ["style", "height", '29px'],
            ["style", "width", '40px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         labels: {
            "Start": 0
         },
         timeline: [
            { id: "eid12", tween: [ "transform", "${_Star}", "scaleX", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 },
            { id: "eid11", tween: [ "transform", "${_Star}", "rotateZ", '360deg', { fromValue: '0deg'}], position: 0, duration: 2000 },
            { id: "eid8", tween: [ "style", "${_Star}", "opacity", '0.5', { fromValue: '1'}], position: 0, duration: 912 },
            { id: "eid9", tween: [ "style", "${_Star}", "opacity", '1', { fromValue: '0.500000'}], position: 912, duration: 1087 },
            { id: "eid13", tween: [ "transform", "${_Star}", "scaleY", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 }         ]
      }
   }
},
"Star_5": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Star',
      type: 'image',
      rect: ['0','0','40px','29px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Star6.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Star}": [
            ["transform", "scaleX", '0.23'],
            ["style", "opacity", '1'],
            ["transform", "scaleY", '0.23'],
            ["transform", "rotateZ", '0deg']
         ],
         "${symbolSelector}": [
            ["style", "height", '29px'],
            ["style", "width", '40px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         labels: {
            "Start": 0
         },
         timeline: [
            { id: "eid12", tween: [ "transform", "${_Star}", "scaleX", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 },
            { id: "eid11", tween: [ "transform", "${_Star}", "rotateZ", '360deg', { fromValue: '0deg'}], position: 0, duration: 2000 },
            { id: "eid8", tween: [ "style", "${_Star}", "opacity", '0.5', { fromValue: '1'}], position: 0, duration: 912 },
            { id: "eid9", tween: [ "style", "${_Star}", "opacity", '1', { fromValue: '0.500000'}], position: 912, duration: 1087 },
            { id: "eid13", tween: [ "transform", "${_Star}", "scaleY", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 }         ]
      }
   }
},
"Star_6": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Star',
      type: 'image',
      rect: ['0','0','40px','29px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Star7.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Star}": [
            ["transform", "scaleX", '0.23'],
            ["style", "opacity", '1'],
            ["transform", "scaleY", '0.23'],
            ["transform", "rotateZ", '0deg']
         ],
         "${symbolSelector}": [
            ["style", "height", '29px'],
            ["style", "width", '40px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         labels: {
            "Start": 0
         },
         timeline: [
            { id: "eid12", tween: [ "transform", "${_Star}", "scaleX", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 },
            { id: "eid11", tween: [ "transform", "${_Star}", "rotateZ", '360deg', { fromValue: '0deg'}], position: 0, duration: 2000 },
            { id: "eid8", tween: [ "style", "${_Star}", "opacity", '0.5', { fromValue: '1'}], position: 0, duration: 912 },
            { id: "eid9", tween: [ "style", "${_Star}", "opacity", '1', { fromValue: '0.500000'}], position: 912, duration: 1087 },
            { id: "eid13", tween: [ "transform", "${_Star}", "scaleY", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 }         ]
      }
   }
},
"Star_7": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Star',
      type: 'image',
      rect: ['0','0','40px','29px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Star8.png']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Star}": [
            ["transform", "scaleX", '0.23'],
            ["style", "opacity", '1'],
            ["transform", "scaleY", '0.23'],
            ["transform", "rotateZ", '0deg']
         ],
         "${symbolSelector}": [
            ["style", "height", '29px'],
            ["style", "width", '40px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         labels: {
            "Start": 0
         },
         timeline: [
            { id: "eid12", tween: [ "transform", "${_Star}", "scaleX", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 },
            { id: "eid11", tween: [ "transform", "${_Star}", "rotateZ", '360deg', { fromValue: '0deg'}], position: 0, duration: 2000 },
            { id: "eid8", tween: [ "style", "${_Star}", "opacity", '0.5', { fromValue: '1'}], position: 0, duration: 912 },
            { id: "eid9", tween: [ "style", "${_Star}", "opacity", '1', { fromValue: '0.500000'}], position: 912, duration: 1087 },
            { id: "eid13", tween: [ "transform", "${_Star}", "scaleY", '0.23', { fromValue: '0.23'}], position: 0, duration: 0 }         ]
      }
   }
},
"Starfield": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Star',
      type: 'rect',
      rect: ['-10','28','auto','auto','auto','auto']
   },
   {
      id: 'StarCopy',
      type: 'rect',
      rect: ['21','16','auto','auto','auto','auto']
   },
   {
      id: 'StarCopy2',
      type: 'rect',
      rect: ['21','16','auto','auto','auto','auto']
   },
   {
      id: 'StarCopy3',
      type: 'rect',
      rect: ['21','16','auto','auto','auto','auto']
   },
   {
      id: 'StarCopy4',
      type: 'rect',
      rect: ['21','16','auto','auto','auto','auto']
   },
   {
      id: 'StarCopy5',
      type: 'rect',
      rect: ['21','16','auto','auto','auto','auto']
   },
   {
      id: 'StarCopy6',
      type: 'rect',
      rect: ['21','16','auto','auto','auto','auto']
   },
   {
      id: 'StarCopy7',
      type: 'rect',
      rect: ['21','16','auto','auto','auto','auto']
   }],
   symbolInstances: [
   {
      id: 'StarCopy7',
      symbolName: 'Star_7'
   },
   {
      id: 'StarCopy2',
      symbolName: 'Star_2'
   },
   {
      id: 'StarCopy4',
      symbolName: 'Star_4'
   },
   {
      id: 'StarCopy',
      symbolName: 'Star_1'
   },
   {
      id: 'StarCopy6',
      symbolName: 'Star_6'
   },
   {
      id: 'Star',
      symbolName: 'Star'
   },
   {
      id: 'StarCopy5',
      symbolName: 'Star_5'
   },
   {
      id: 'StarCopy3',
      symbolName: 'Star_3'
   }   ]
   },
   states: {
      "Base State": {
         "${_StarCopy5}": [
            ["style", "left", '758px'],
            ["style", "top", '65px']
         ],
         "${_StarCopy2}": [
            ["style", "left", '10px'],
            ["style", "top", '56px']
         ],
         "${_Star}": [
            ["transform", "scaleX", '0.5'],
            ["transform", "scaleY", '0.5']
         ],
         "${_StarCopy7}": [
            ["style", "left", '310px'],
            ["style", "top", '0px']
         ],
         "${symbolSelector}": [
            ["style", "height", '157px'],
            ["style", "width", '798px']
         ],
         "${_StarCopy4}": [
            ["style", "left", '319px'],
            ["style", "top", '128px']
         ],
         "${_StarCopy3}": [
            ["style", "left", '197px'],
            ["style", "top", '50px']
         ],
         "${_StarCopy6}": [
            ["style", "left", '509px'],
            ["style", "top", '14px']
         ],
         "${_StarCopy}": [
            ["style", "left", '68px'],
            ["style", "top", '99px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         timeline: [
            { id: "eid55", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${_StarCopy4}', [79] ], ""], position: 78.671875 },
            { id: "eid56", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${_StarCopy2}', [97] ], ""], position: 78.671875 },
            { id: "eid57", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${_StarCopy}', [257] ], ""], position: 205.56640625 },
            { id: "eid53", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${_StarCopy5}', [482] ], ""], position: 250 },
            { id: "eid54", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${_StarCopy6}', [382] ], ""], position: 375.91796875 },
            { id: "eid59", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${_StarCopy3}', [599] ], ""], position: 590.91796875 },
            { id: "eid58", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${_StarCopy7}', [895] ], ""], position: 1000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-161357509");
