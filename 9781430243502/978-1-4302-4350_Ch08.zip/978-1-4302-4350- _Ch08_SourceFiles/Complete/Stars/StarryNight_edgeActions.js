/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         sym.play("Home");

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'Star'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1500, function(sym, e) {
         sym.play("Start");

      });
      //Edge binding end

   })("Star");
   //Edge symbol end:'Star'

   //=========================================================
   
   //Edge symbol: 'Star_1'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         sym.play("Start");

      });
      //Edge binding end

   })("Star_1");
   //Edge symbol end:'Star_1'

   //=========================================================
   
   //Edge symbol: 'Star_2'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         sym.play("Start");

      });
      //Edge binding end

   })("Star_2");
   //Edge symbol end:'Star_2'

   //=========================================================
   
   //Edge symbol: 'Star_3'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         sym.play("Start");

      });
      //Edge binding end

   })("Star_3");
   //Edge symbol end:'Star_3'

   //=========================================================
   
   //Edge symbol: 'Star_4'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         sym.play("Start");

      });
      //Edge binding end

   })("Star_4");
   //Edge symbol end:'Star_4'

   //=========================================================
   
   //Edge symbol: 'Star_5'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         sym.play("Start");

      });
      //Edge binding end

   })("Star_5");
   //Edge symbol end:'Star_5'

   //=========================================================
   
   //Edge symbol: 'Star_6'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         sym.play("Start");

      });
      //Edge binding end

   })("Star_6");
   //Edge symbol end:'Star_6'

   //=========================================================
   
   //Edge symbol: 'Star_7'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         sym.play("Start");

      });
      //Edge binding end

   })("Star_7");
   //Edge symbol end:'Star_7'

   //=========================================================
   
   //Edge symbol: 'Starfield'
   (function(symbolName) {   
   
   })("Starfield");
   //Edge symbol end:'Starfield'

})(jQuery, AdobeEdge, "EDGE-161357509");