/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Bottom',
            type:'image',
            rect:['450','380','450px','190px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Bottom.png"],
            transform:[]
         },
         {
            id:'Donate',
            type:'image',
            rect:['450','190','225px','190px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Donate.png"],
            transform:[]
         },
         {
            id:'Left_Panel',
            type:'image',
            rect:['0','0','450px','570px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Left_Panel.png"],
            transform:[]
         },
         {
            id:'RightTop',
            type:'image',
            rect:['675','0','225px','380px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"RightTop.png"],
            transform:[]
         },
         {
            id:'Who',
            type:'image',
            rect:['450','0','225px','190px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"UpperCenter.png"],
            transform:[]
         },
         {
            id:'WallArtBadge',
            type:'rect',
            rect:['15px','314px','220px','220px','auto','auto'],
            borderRadius:["100% 100%","100% 100%","100% 100%","100% 100%"],
            fill:["rgba(154,52,55,1.00)"],
            stroke:[2,"rgba(255,255,255,1.00)","solid"],
            boxShadow:["",14,17,78,7,"rgba(0,0,0,1.00)"],
            transform:[]
         },
         {
            id:'BadgeText',
            type:'image',
            rect:['31px','394px','194px','63px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"BadgeText.png"],
            transform:[]
         },
         {
            id:'Container',
            type:'rect',
            rect:['615px','143px','214px','112px','auto','auto'],
            fill:["rgba(255,255,255,0)"],
            stroke:[0,"rgba(0, 0, 0, 0)","none"],
            c:[
            {
               id:'Buttons',
               type:'rect',
               rect:['27px','7px','auto','auto','auto','auto']
            }]
         }],
         symbolInstances: [
         {
            id:'Buttons',
            symbolName:'Menu'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Donate}": [
            ["style", "left", '450px'],
            ["style", "top", '190px']
         ],
         "${_Bottom}": [
            ["style", "left", '450px'],
            ["style", "top", '380px']
         ],
         "${_BadgeText}": [
            ["style", "left", '31px'],
            ["style", "top", '394px']
         ],
         "${_Left_Panel}": [
            ["style", "left", '0px'],
            ["style", "top", '0px']
         ],
         "${_WallArtBadge}": [
            ["style", "left", '15px'],
            ["style", "border-bottom-left-radius", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["subproperty", "boxShadow.spread", '7px'],
            ["subproperty", "boxShadow.offsetH", '14px'],
            ["color", "background-color", 'rgba(154,52,55,1.00)'],
            ["style", "border-top-left-radius", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["subproperty", "boxShadow.color", 'rgba(0,0,0,1.00)'],
            ["style", "border-bottom-right-radius", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '2px'],
            ["style", "width", '220px'],
            ["style", "top", '314px'],
            ["color", "border-color", 'rgba(255,255,255,1.00)'],
            ["style", "height", '220px'],
            ["subproperty", "boxShadow.blur", '78px'],
            ["subproperty", "boxShadow.offsetV", '17px'],
            ["style", "border-top-right-radius", [100,100], {valueTemplate:'@@0@@% @@1@@%'} ]
         ],
         "${_Container}": [
            ["style", "height", '111.51667022705px'],
            ["style", "left", '614.7px'],
            ["style", "width", '213.90258789062px']
         ],
         "${_RightTop}": [
            ["style", "left", '675px'],
            ["style", "top", '0px']
         ],
         "${_Who}": [
            ["style", "left", '450px'],
            ["style", "top", '0px']
         ],
         "${_Buttons}": [
            ["style", "left", '27.08px'],
            ["style", "top", '6.98px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '900px'],
            ["style", "height", '570px'],
            ["style", "overflow", 'hidden']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"MenuStrip": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['0px','0px','163px','20px','auto','auto'],
      id: 'Rectangle',
      stroke: [1,'rgba(0,0,0,1)','solid'],
      type: 'rect',
      fill: ['rgba(255,255,255,1.00)']
   },
   {
      type: 'text',
      id: 'txt',
      text: 'xx',
      rect: ['14px','3px','auto','auto','auto','auto'],
      font: ['Verdana, Geneva, sans-serif',14,'rgba(0,0,0,1)','normal','none','']
   },
   {
      rect: ['0px','0px','167px','24px','auto','auto'],
      id: 'HotSpot',
      stroke: [0,'rgba(0,0,0,0.00)','none'],
      type: 'rect',
      fill: ['rgba(255,255,255,0.00)']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_txt}": [
            ["style", "top", '3px'],
            ["color", "color", 'rgba(0,0,0,1.00)'],
            ["style", "font-family", 'Verdana, Geneva, sans-serif'],
            ["style", "left", '13.57px'],
            ["style", "font-size", '14px']
         ],
         "${_Rectangle}": [
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "top", '0.01px'],
            ["style", "left", '0px'],
            ["style", "height", '20px'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '1px'],
            ["style", "width", '163px']
         ],
         "${_HotSpot}": [
            ["color", "background-color", 'rgba(255,255,255,0.00)'],
            ["style", "top", '0px'],
            ["style", "height", '24px'],
            ["color", "border-color", 'rgba(0,0,0,0.00)'],
            ["style", "left", '0px'],
            ["style", "width", '167px']
         ],
         "${symbolSelector}": [
            ["style", "height", '24px'],
            ["style", "width", '145.35000610352px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 500,
         autoPlay: true,
         labels: {
            "Over": 0,
            "Off": 500
         },
         timeline: [
            { id: "eid43", tween: [ "color", "${_txt}", "color", 'rgba(23,32,231,1)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(0,0,0,1.00)'}], position: 0, duration: 500 }         ]
      }
   }
},
"Menu": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Team_btn',
      type: 'rect',
      rect: ['0px','0px','auto','auto','auto','auto']
   },
   {
      id: 'Scope_btn',
      type: 'rect',
      rect: ['0','20px','auto','auto','auto','auto']
   },
   {
      id: 'Send_btn',
      type: 'rect',
      rect: ['0px','41px','auto','auto','auto','auto']
   },
   {
      id: 'Contact_btn',
      type: 'rect',
      rect: ['0px','62px','auto','auto','auto','auto']
   }],
   symbolInstances: [
   {
      id: 'Scope_btn',
      symbolName: 'MenuStrip'
   },
   {
      id: 'Send_btn',
      symbolName: 'MenuStrip'
   },
   {
      id: 'Team_btn',
      symbolName: 'MenuStrip'
   },
   {
      id: 'Contact_btn',
      symbolName: 'MenuStrip'
   }   ]
   },
   states: {
      "Base State": {
         "${_Scope_btn}": [
            ["style", "top", '20px']
         ],
         "${_Contact_btn}": [
            ["style", "left", '0px'],
            ["style", "top", '62px']
         ],
         "${symbolSelector}": [
            ["style", "height", '24px'],
            ["style", "width", '167px']
         ],
         "${_Team_btn}": [
            ["style", "left", '0.01px'],
            ["style", "top", '0px']
         ],
         "${_Send_btn}": [
            ["style", "top", '41px'],
            ["style", "left", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-31399373");
