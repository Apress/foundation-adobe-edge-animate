/***********************
* Adobe Edge Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

      

      

      

      

      

      

      

      Symbol.bindElementAction(compId, symbolName, "document", "compositionReady", function(sym, e) {
         sym.$("Buttons").hide();
         
         sym.getSymbol("Buttons").getSymbol("Team_btn").$("txt").html("The Project Team");
         sym.getSymbol("Buttons").getSymbol("Scope_btn").$("txt").html("The Project Scope");
         sym.getSymbol("Buttons").getSymbol("Send_btn").$("txt").html("Send us art");
         sym.getSymbol("Buttons").getSymbol("Contact_btn").$("txt").html("Contact Us");
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_Container}", "mouseenter", function(sym, e) {
         // Show an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("Buttons").show();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_Container}", "mouseleave", function(sym, e) {
         // Hide an Element.
         //  (sym.$("name") resolves an Edge element name to a DOM
         //  element that can be used with jQuery)
         sym.$("Buttons").hide();
         

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'MenuStrip'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_HotSpot}", "mouseenter", function(sym, e) {
         sym.play("Over");
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_HotSpot}", "mouseleave", function(sym, e) {
         sym.play("Off");
         

      });
      //Edge binding end

   })("MenuStrip");
   //Edge symbol end:'MenuStrip'

   //=========================================================
   
   //Edge symbol: 'Menu'
   (function(symbolName) {   
   
   })("Menu");
   //Edge symbol end:'Menu'

})(jQuery, AdobeEdge, "EDGE-31399373");