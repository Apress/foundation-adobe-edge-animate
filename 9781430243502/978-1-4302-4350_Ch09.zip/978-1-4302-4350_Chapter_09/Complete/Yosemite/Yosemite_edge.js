/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Clouds',
            type:'rect',
            rect:['0','0','auto','auto','auto','auto']
         },
         {
            id:'Yosemite',
            type:'image',
            rect:['0px','93px','800px','507px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Yosemite.png",'0px','0px']
         },
         {
            id:'YosemiteHD',
            type:'image',
            rect:['391px','452px','383px','75px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"YosemiteHD.png",'0px','0px']
         },
         {
            id:'ClickTxt',
            type:'text',
            rect:['404px','527px','auto','auto','auto','auto'],
            opacity:0.8040771484375,
            text:"Click on the mountains to learn more.",
            align:"left",
            font:['Arial Black, Gadget, sans-serif',18,"rgba(255,255,255,1.00)","normal","none","normal"]
         },
         {
            id:'El_Capitan',
            type:'rect',
            rect:['0','110','auto','auto','auto','auto']
         },
         {
            id:'Cathedral',
            type:'rect',
            rect:['519','89','auto','auto','auto','auto']
         },
         {
            id:'Sentinel',
            type:'rect',
            rect:['471','274','auto','auto','auto','auto']
         },
         {
            id:'Bridalvail',
            type:'rect',
            rect:['627','215','auto','auto','auto','auto']
         }],
         symbolInstances: [
         {
            id:'Sentinel',
            symbolName:'Sentinel'
         },
         {
            id:'Bridalvail',
            symbolName:'Bridalvail'
         },
         {
            id:'Cathedral',
            symbolName:'Cathedral'
         },
         {
            id:'El_Capitan',
            symbolName:'El_Capitan'
         },
         {
            id:'Clouds',
            symbolName:'Clouds'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Cathedral_TxtCopy}": [
            ["style", "top", '74.27px'],
            ["style", "font-size", '22px'],
            ["style", "height", '325.93023681641px'],
            ["color", "color", 'rgba(57,48,9,1)'],
            ["style", "display", 'block'],
            ["style", "left", '-412px'],
            ["style", "width", '348.75px']
         ],
         "${_ClickTxt}": [
            ["style", "top", '527px'],
            ["style", "font-family", 'Arial Black, Gadget, sans-serif'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '424.85px'],
            ["style", "font-size", '16px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '600px'],
            ["style", "width", '800px']
         ],
         "${_Yosemite}": [
            ["style", "left", '0px'],
            ["style", "top", '93px']
         ],
         "${_Cathedral_HDCopy}": [
            ["color", "color", 'rgba(0,0,0,1)'],
            ["style", "font-weight", '900'],
            ["style", "left", '-414px'],
            ["style", "font-size", '41px'],
            ["style", "top", '14.82px'],
            ["style", "display", 'block'],
            ["style", "font-family", '\'Lucida Sans Unicode\', \'Lucida Grande\', sans-serif'],
            ["style", "width", '337.734375px'],
            ["style", "height", '38.016666412354px']
         ],
         "${_YosemiteHD}": [
            ["style", "left", '391px'],
            ["style", "top", '451.74px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         labels: {
            "Start": 0,
            "End": 1000
         },
         timeline: [
            { id: "eid160", tween: [ "style", "${_ClickTxt}", "font-size", '16px', { fromValue: '16px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid135", tween: [ "style", "${_ClickTxt}", "opacity", '0.8', { fromValue: '0.000000'}], position: 0, duration: 1000, easing: "easeInOutCubic" },
            { id: "eid162", tween: [ "style", "${_ClickTxt}", "left", '424.85px', { fromValue: '424.85px'}], position: 1000, duration: 0, easing: "easeInOutCubic" }         ]
      }
   }
},
"El_Capitan": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      type: 'rect',
      rect: ['396px','-27px','379px','390px','auto','auto'],
      borderRadius: ['0px 0px','0px 0px','0px 0px','0px 0px'],
      id: 'El_Capt_Rec',
      display: 'none',
      opacity: 0.5,
      stroke: [0,'rgba(0,0,0,1)','none'],
      fill: ['rgba(192,192,192,1)']
   },
   {
      rect: ['415px','57px','349px','275px','auto','auto'],
      font: ['Arial, Helvetica, sans-serif',24,'rgba(0,0,0,1)','normal','none','normal'],
      display: 'none',
      id: 'El_Cap_Txt',
      text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla interdum, mi ac interdum aliquam, tellus mauris eleifend magna, nec iaculis ante velit lobortis eros. Morbi pulvinar justo ut metus pulvinar varius. Nullam vitae tortor massa. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. ',
      align: 'left',
      type: 'text'
   },
   {
      id: 'El_Capitan4',
      type: 'image',
      rect: ['0px','0px','368px','225px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/El_Capitan.png','0px','0px']
   },
   {
      rect: ['407px','0px','368px','390px','auto','auto'],
      font: ['Lucida Sans Unicode, Lucida Grande, sans-serif',24,'rgba(0,0,0,1.00)','900','none',''],
      id: 'El_Cap_HD',
      text: 'El Capitan',
      display: 'none',
      type: 'text'
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_El_Capt_Rec}": [
            ["color", "background-color", 'rgba(240,238,199,1.00)'],
            ["style", "border-top-left-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "opacity", '0.5'],
            ["style", "left", '396.1px'],
            ["style", "width", '378.89999389648px'],
            ["style", "top", '-56.7px'],
            ["style", "border-bottom-left-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "height", '364.89788818359px'],
            ["style", "display", 'none'],
            ["style", "border-top-right-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ]
         ],
         "${symbolSelector}": [
            ["style", "height", '225px'],
            ["style", "width", '368px']
         ],
         "${_El_Cap_HD}": [
            ["color", "color", 'rgba(0,0,0,1.00)'],
            ["style", "font-weight", '900'],
            ["style", "left", '414px'],
            ["style", "font-size", '41px'],
            ["style", "top", '-40.15px'],
            ["style", "display", 'none'],
            ["style", "font-family", 'Lucida Sans Unicode, Lucida Grande, sans-serif'],
            ["style", "height", '38.016666412354px'],
            ["style", "width", '337.734375px']
         ],
         "${_El_Capitan4}": [
            ["style", "top", '0.01px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px']
         ],
         "${_El_Cap_Txt}": [
            ["style", "top", '26.87px'],
            ["style", "width", '348.75px'],
            ["color", "color", 'rgba(57,48,9,1.00)'],
            ["style", "height", '274.81253051758px'],
            ["style", "display", 'none'],
            ["style", "left", '415.14px'],
            ["style", "font-size", '22px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         labels: {
            "Off": 0,
            "On": 500,
            "Text": 1000
         },
         timeline: [
            { id: "eid78", tween: [ "style", "${_El_Cap_HD}", "left", '414px', { fromValue: '414px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid169", tween: [ "style", "${_El_Capt_Rec}", "height", '364.89788818359px', { fromValue: '364.89788818359px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid8", tween: [ "style", "${_El_Capitan4}", "opacity", '1', { fromValue: '0.000000'}], position: 0, duration: 500 },
            { id: "eid95", tween: [ "style", "${_El_Capt_Rec}", "border-top-right-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid98", tween: [ "style", "${_El_Cap_Txt}", "font-size", '22px', { fromValue: '22px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid71", tween: [ "style", "${_El_Cap_HD}", "height", '38.016666412354px', { fromValue: '38.016666412354px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid72", tween: [ "style", "${_El_Cap_HD}", "width", '337.734375px', { fromValue: '337.734375px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid93", tween: [ "style", "${_El_Capt_Rec}", "border-bottom-left-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid15", tween: [ "style", "${_El_Capt_Rec}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid16", tween: [ "style", "${_El_Capt_Rec}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0 },
            { id: "eid141", tween: [ "style", "${_El_Cap_HD}", "top", '-40.15px', { fromValue: '-40.15px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid13", tween: [ "style", "${_El_Capt_Rec}", "opacity", '0.5', { fromValue: '0.5'}], position: 1000, duration: 0 },
            { id: "eid14", tween: [ "style", "${_El_Cap_HD}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid17", tween: [ "style", "${_El_Cap_HD}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0 },
            { id: "eid79", tween: [ "color", "${_El_Capt_Rec}", "background-color", 'rgba(240,238,199,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(240,238,199,1.00)'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid80", tween: [ "style", "${_El_Cap_Txt}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "easeInOutCubic" },
            { id: "eid84", tween: [ "style", "${_El_Cap_Txt}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid96", tween: [ "style", "${_El_Capt_Rec}", "border-bottom-right-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid139", tween: [ "style", "${_El_Capt_Rec}", "top", '-56.7px', { fromValue: '-56.7px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid94", tween: [ "style", "${_El_Capt_Rec}", "border-top-left-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid140", tween: [ "style", "${_El_Cap_Txt}", "top", '26.87px', { fromValue: '26.87px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid68", tween: [ "style", "${_El_Cap_HD}", "font-size", '41px', { fromValue: '41px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid99", tween: [ "color", "${_El_Cap_Txt}", "color", 'rgba(57,48,9,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(57,48,9,1.00)'}], position: 1000, duration: 0, easing: "easeInOutCubic" }         ]
      }
   }
},
"Sentinel": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Sentinel_Rock',
      type: 'image',
      rect: ['0px','0px','73px','61px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Sentinel_Rock.png','0px','0px']
   },
   {
      type: 'rect',
      rect: ['-405px','-107px','367px','315px','auto','auto'],
      display: 'none',
      id: 'Sentinel_Rec',
      opacity: 0.37999998688698,
      stroke: [0,'rgb(0, 0, 0)','none'],
      fill: ['rgba(192,192,192,1)']
   },
   {
      rect: ['-383px','-33px','349px','275px','auto','auto'],
      font: ['Arial, Helvetica, sans-serif',24,'rgba(0,0,0,1)','normal','none','normal'],
      display: 'none',
      id: 'Sentinel_Txt',
      text: 'Integer molestie aliquet ante, at laoreet neque facilisis et. Maecenas malesuada turpis in libero hendrerit nec volutpat velit aliquam. Sed id magna ac erat consectetur posuere id sit amet elit. Nam ipsum metus, facilisis at luctus at, placerat at nunc. Urna tortor, feugiat sit amet rutrum nec, vestibulum quis diam. ',
      align: 'left',
      type: 'text'
   },
   {
      rect: ['-393px','-89px','368px','390px','auto','auto'],
      font: ['Lucida Sans Unicode, Lucida Grande, sans-serif',24,'rgba(0,0,0,1.00)','900','none',''],
      id: 'Sentinel_HD',
      text: 'Sentinel Rock',
      display: 'none',
      type: 'text'
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Sentinel_HD}": [
            ["color", "color", 'rgba(0,0,0,1)'],
            ["style", "font-weight", '900'],
            ["style", "left", '-386.32px'],
            ["style", "font-size", '41px'],
            ["style", "top", '-159.2px'],
            ["style", "display", 'none'],
            ["style", "font-family", '\'Lucida Sans Unicode\', \'Lucida Grande\', sans-serif'],
            ["style", "width", '337.734375px'],
            ["style", "height", '38.016666412354px']
         ],
         "${_Text}": [
            ["color", "color", 'rgba(0,0,0,1.00)'],
            ["style", "display", 'none']
         ],
         "${symbolSelector}": [
            ["style", "height", '61px'],
            ["style", "width", '73px']
         ],
         "${_Sentinel_Rock}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0'],
            ["style", "left", '0.01px']
         ],
         "${_Sentinel_Rec}": [
            ["color", "background-color", 'rgba(240,238,199,1.00)'],
            ["style", "border-top-left-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "opacity", '0.37999998688698'],
            ["style", "border-top-right-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '379.01666259766px'],
            ["style", "top", '-177px'],
            ["style", "border-bottom-left-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "height", '330.19271850586px'],
            ["style", "display", 'none']
         ],
         "${_Sentinel_Txt}": [
            ["style", "top", '-103.17px'],
            ["style", "font-size", '22px'],
            ["style", "height", '274.81253051758px'],
            ["color", "color", 'rgba(57,48,9,1)'],
            ["style", "display", 'none'],
            ["style", "left", '-383.32px'],
            ["style", "width", '348.75px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         labels: {
            "Off": 0,
            "On": 500,
            "Text": 1000
         },
         timeline: [
            { id: "eid146", tween: [ "style", "${_Sentinel_Txt}", "top", '-103.17px', { fromValue: '-103.17px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid27", tween: [ "style", "${_Sentinel_Rec}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid30", tween: [ "style", "${_Sentinel_Rec}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0 },
            { id: "eid105", tween: [ "style", "${_Sentinel_Rec}", "border-top-right-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid145", tween: [ "style", "${_Sentinel_Rec}", "top", '-177px', { fromValue: '-177px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid171", tween: [ "style", "${_Sentinel_Rec}", "height", '330.19271850586px', { fromValue: '330.19271850586px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid21", tween: [ "style", "${_Sentinel_Rock}", "opacity", '1', { fromValue: '0.000000'}], position: 0, duration: 500 },
            { id: "eid104", tween: [ "style", "${_Sentinel_Rec}", "border-top-left-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid103", tween: [ "style", "${_Sentinel_Rec}", "border-bottom-left-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid106", tween: [ "style", "${_Sentinel_Rec}", "border-bottom-right-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid109", tween: [ "style", "${_Sentinel_Txt}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "easeInOutCubic" },
            { id: "eid110", tween: [ "style", "${_Sentinel_Txt}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid81", tween: [ "color", "${_Sentinel_Rec}", "background-color", 'rgba(240,238,199,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(240,238,199,1.00)'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid111", tween: [ "style", "${_Sentinel_HD}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "easeInOutCubic" },
            { id: "eid112", tween: [ "style", "${_Sentinel_HD}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid113", tween: [ "style", "${_Sentinel_HD}", "left", '-386.32px', { fromValue: '-386.32px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid147", tween: [ "style", "${_Sentinel_HD}", "top", '-159.2px', { fromValue: '-159.2px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid108", tween: [ "style", "${_Sentinel_Rec}", "width", '379.01666259766px', { fromValue: '379.01666259766px'}], position: 1000, duration: 0, easing: "easeInOutCubic" }         ]
      }
   }
},
"Cathedral": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Cathedral_Rocks',
      type: 'image',
      rect: ['0px','0px','281px','241px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Cathedral_Rocks.png','0px','0px']
   },
   {
      type: 'rect',
      rect: ['-440px','-6px','404px','415px','auto','auto'],
      display: 'none',
      id: 'Rectangle3',
      opacity: 0.5,
      stroke: [0,'rgb(0, 0, 0)','none'],
      fill: ['rgba(192,192,192,1)']
   },
   {
      rect: ['-412px','74px','349px','326px','auto','auto'],
      font: ['Arial, Helvetica, sans-serif',24,'rgba(0,0,0,1)','normal','none','normal'],
      display: 'none',
      id: 'Cathedral_Txt',
      text: 'Nunc eget tellus eget est posuere iaculis. Vestibulum at lorem ipsum, a ultrices purus. Integer fringilla gravida libero consequat dictum. Praesent purus nulla, adipiscing quis gravida in, sodales eget dolor. In ut ipsum felis. Nullam quis augue vel eros sollicitudin vehicula. Etiam sagittis condimentum dapibus. Vivamus varius lobortis luctus. Aliquam quis massa sit amet mauris dignissim ornare. ',
      align: 'left',
      type: 'text'
   },
   {
      rect: ['-414px','15px','368px','390px','auto','auto'],
      font: ['Lucida Sans Unicode, Lucida Grande, sans-serif',24,'rgba(0,0,0,1.00)','900','none',''],
      id: 'Cathedral_HD',
      text: 'Cathedral Rocks',
      display: 'none',
      type: 'text'
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Cathedral_HD}": [
            ["color", "color", 'rgba(0,0,0,1)'],
            ["style", "font-weight", '900'],
            ["style", "left", '-414px'],
            ["style", "font-size", '41px'],
            ["style", "top", '-45.17px'],
            ["style", "display", 'none'],
            ["style", "font-family", '\'Lucida Sans Unicode\', \'Lucida Grande\', sans-serif'],
            ["style", "height", '38.016666412354px'],
            ["style", "width", '337.734375px']
         ],
         "${_Cathedral_Txt}": [
            ["style", "top", '14.27px'],
            ["style", "width", '348.75px'],
            ["color", "color", 'rgba(57,48,9,1)'],
            ["style", "height", '325.93023681641px'],
            ["style", "display", 'none'],
            ["style", "left", '-412px'],
            ["style", "font-size", '22px']
         ],
         "${symbolSelector}": [
            ["style", "height", '241px'],
            ["style", "width", '281px']
         ],
         "${_Cathedral_Rocks}": [
            ["style", "top", '0.01px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px']
         ],
         "${_Rectangle3}": [
            ["color", "background-color", 'rgba(240,238,199,1.00)'],
            ["style", "border-top-left-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "opacity", '0.5'],
            ["style", "border-top-right-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "top", '-66px'],
            ["style", "border-bottom-left-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "display", 'none'],
            ["style", "height", '406px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         labels: {
            "Off": 0,
            "On": 500,
            "Text": 1000
         },
         timeline: [
            { id: "eid120", tween: [ "style", "${_Cathedral_HD}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid172", tween: [ "style", "${_Rectangle3}", "height", '406px', { fromValue: '406px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid116", tween: [ "style", "${_Rectangle3}", "border-bottom-left-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid36", tween: [ "style", "${_Rectangle3}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid38", tween: [ "style", "${_Rectangle3}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0 },
            { id: "eid118", tween: [ "style", "${_Rectangle3}", "border-top-right-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid121", tween: [ "style", "${_Cathedral_Txt}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid150", tween: [ "style", "${_Rectangle3}", "top", '-66px', { fromValue: '-66px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid149", tween: [ "style", "${_Cathedral_Txt}", "top", '14.27px', { fromValue: '14.27px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid82", tween: [ "color", "${_Rectangle3}", "background-color", 'rgba(240,238,199,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(240,238,199,1.00)'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid148", tween: [ "style", "${_Cathedral_HD}", "top", '-45.17px', { fromValue: '-45.17px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid34", tween: [ "style", "${_Cathedral_Rocks}", "opacity", '0.984375', { fromValue: '0.000000'}], position: 0, duration: 500 },
            { id: "eid119", tween: [ "style", "${_Rectangle3}", "border-bottom-right-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid117", tween: [ "style", "${_Rectangle3}", "border-top-left-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" }         ]
      }
   }
},
"Bridalvail": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'Bridalvail_Fall',
      type: 'image',
      rect: ['0px','0px','173px','87px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/Bridalvail_Fall.png','0px','0px']
   },
   {
      type: 'rect',
      rect: ['-380px','-116px','353px','347px','auto','auto'],
      display: 'none',
      id: 'Rectangle4',
      opacity: 0.5,
      stroke: [0,'rgb(0, 0, 0)','none'],
      fill: ['rgba(192,192,192,1)']
   },
   {
      rect: ['-404px','-44px','349px','326px','auto','auto'],
      font: ['Arial, Helvetica, sans-serif',24,'rgba(0,0,0,1)','normal','none','normal'],
      display: 'none',
      id: 'Bridalvail_Txt',
      text: 'Nunc eget tellus eget est posuere iaculis. Vestibulum at lorem ipsum, a ultrices purus. Integer fringilla gravida libero consequat dictum. Praesent purus nulla, adipiscing quis gravida in, sodales eget dolor. In ut ipsum felis. Nullam quis augue vel eros sollicitudin vehicula. Etiam sagittis condimentum dapibus. Vivamus varius lobortis luctus. Aliquam quis massa sit amet mauris dignissim ornare. ',
      align: 'left',
      type: 'text'
   },
   {
      rect: ['-406px','-103px','368px','390px','auto','auto'],
      font: ['Lucida Sans Unicode, Lucida Grande, sans-serif',24,'rgba(0,0,0,1.00)','900','none',''],
      id: 'Bridalvail_HD',
      text: 'Bridalvail Fall',
      display: 'none',
      type: 'text'
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_Bridalvail_Fall}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px']
         ],
         "${symbolSelector}": [
            ["style", "height", '87px'],
            ["style", "width", '173px']
         ],
         "${_Bridalvail_HD}": [
            ["color", "color", 'rgba(0,0,0,1)'],
            ["style", "font-weight", '900'],
            ["style", "left", '-436px'],
            ["style", "font-size", '41px'],
            ["style", "top", '-173px'],
            ["style", "display", 'none'],
            ["style", "font-family", '\'Lucida Sans Unicode\', \'Lucida Grande\', sans-serif'],
            ["style", "width", '337.734375px'],
            ["style", "height", '38.016666412354px']
         ],
         "${_Rectangle4}": [
            ["color", "background-color", 'rgba(240,238,199,1.00)'],
            ["style", "border-top-left-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "opacity", '0.5'],
            ["style", "left", '-465.05px'],
            ["style", "width", '408.3166809082px'],
            ["style", "top", '-185.67px'],
            ["style", "border-bottom-left-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "height", '397.66666666667px'],
            ["style", "display", 'none'],
            ["style", "border-top-right-radius", [20,20], {valueTemplate:'@@0@@px @@1@@px'} ]
         ],
         "${_Bridalvail_Txt}": [
            ["style", "top", '-113.55px'],
            ["style", "font-size", '22px'],
            ["style", "height", '325.93023681641px'],
            ["color", "color", 'rgba(57,48,9,1)'],
            ["style", "display", 'none'],
            ["style", "left", '-434px'],
            ["style", "width", '348.75px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         labels: {
            "Off": 0,
            "On": 500,
            "Text": 1000
         },
         timeline: [
            { id: "eid156", tween: [ "style", "${_Rectangle4}", "left", '-465.05px', { fromValue: '-465.05px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid44", tween: [ "style", "${_Rectangle4}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid46", tween: [ "style", "${_Rectangle4}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0 },
            { id: "eid154", tween: [ "style", "${_Bridalvail_Txt}", "left", '-434px', { fromValue: '-434px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid83", tween: [ "color", "${_Rectangle4}", "background-color", 'rgba(240,238,199,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(240,238,199,1.00)'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid127", tween: [ "style", "${_Rectangle4}", "border-bottom-left-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid131", tween: [ "style", "${_Bridalvail_Txt}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid157", tween: [ "style", "${_Bridalvail_Txt}", "top", '-113.55px', { fromValue: '-113.55px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid128", tween: [ "style", "${_Rectangle4}", "border-top-left-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid155", tween: [ "style", "${_Bridalvail_HD}", "left", '-436px', { fromValue: '-436px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid166", tween: [ "style", "${_Rectangle4}", "width", '408.3166809082px', { fromValue: '408.3166809082px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid129", tween: [ "style", "${_Rectangle4}", "border-top-right-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid165", tween: [ "style", "${_Rectangle4}", "height", '397.66666666667px', { fromValue: '397.66666666667px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid158", tween: [ "style", "${_Bridalvail_HD}", "top", '-173px', { fromValue: '-173px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid159", tween: [ "style", "${_Rectangle4}", "top", '-185.67px', { fromValue: '-185.67px'}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid130", tween: [ "style", "${_Rectangle4}", "border-bottom-right-radius", [20,20], { valueTemplate: '@@0@@px @@1@@px', fromValue: [20,20]}], position: 1000, duration: 0, easing: "easeInOutCubic" },
            { id: "eid42", tween: [ "style", "${_Bridalvail_Fall}", "opacity", '1', { fromValue: '0.000000'}], position: 0, duration: 500 },
            { id: "eid132", tween: [ "style", "${_Bridalvail_HD}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0, easing: "easeInOutCubic" }         ]
      }
   }
},
"Clouds": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      type: 'image',
      id: 'clouds',
      opacity: 1,
      rect: ['-185px','0px','1166px','395px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/clouds.jpg','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_clouds}": [
            ["style", "top", '0px'],
            ["style", "opacity", '1'],
            ["style", "left", '-184.53px']
         ],
         "${symbolSelector}": [
            ["style", "height", '395px'],
            ["style", "width", '1166px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 7000,
         autoPlay: true,
         labels: {
            "Start": 0,
            "End": 7000
         },
         timeline: [
            { id: "eid64", tween: [ "style", "${_clouds}", "left", '-155.5px', { fromValue: '-184.53px'}], position: 0, duration: 3500, easing: "easeInOutCubic" },
            { id: "eid65", tween: [ "style", "${_clouds}", "left", '-185px', { fromValue: '-155.5px'}], position: 3500, duration: 3500 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-655621283");
