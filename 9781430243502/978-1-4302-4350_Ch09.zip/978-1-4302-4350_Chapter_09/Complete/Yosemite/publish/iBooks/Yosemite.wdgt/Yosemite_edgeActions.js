
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"document","compositionReady",function(sym,e){sym.setVariable("current","");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_Yosemite}","click",function(sym,e){var current=sym.getVariable("Current");if(current!=""){sym.getSymbol(current).play("off");}});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'El_Capitan'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",500,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_El_Capitan4}","mouseover",function(sym,e){sym.play('On');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_El_Capitan4}","click",function(sym,e){sym.play('Text');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_El_Capitan4}","mouseout",function(sym,e){sym.play('Off');});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindSymbolAction(compId,symbolName,"creationComplete",function(sym,e){sym.setVariable("current","El_Capitan");});
//Edge binding end
})("El_Capitan");
//Edge symbol end:'El_Capitan'

//=========================================================

//Edge symbol: 'Sentinel'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",500,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_Sentinel_Rock}","click",function(sym,e){sym.play('Text');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_Sentinel_Rock}","mouseover",function(sym,e){sym.play('On');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_Sentinel_Rock}","mouseout",function(sym,e){sym.play('Off');});
//Edge binding end
Symbol.bindSymbolAction(compId,symbolName,"creationComplete",function(sym,e){sym.setVariable("current","Sentinel_Rock");});
//Edge binding end
})("Sentinel");
//Edge symbol end:'Sentinel'

//=========================================================

//Edge symbol: 'Cathedral'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",500,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_Cathedral_Rocks}","click",function(sym,e){sym.play('Text');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_Cathedral_Rocks}","mouseover",function(sym,e){sym.play('On');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_Cathedral_Rocks}","mouseout",function(sym,e){sym.play('Off');});
//Edge binding end
Symbol.bindSymbolAction(compId,symbolName,"creationComplete",function(sym,e){sym.setVariable("current","Cathedral_Rocks");});
//Edge binding end
})("Cathedral");
//Edge symbol end:'Cathedral'

//=========================================================

//Edge symbol: 'Bridalvail'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",500,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_Bridalvail_Fall}","click",function(sym,e){sym.play('Text');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_Bridalvail_Fall}","mouseover",function(sym,e){sym.play('On');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_Bridalvail_Fall}","mouseout",function(sym,e){sym.play('Off');});
//Edge binding end
Symbol.bindSymbolAction(compId,symbolName,"creationComplete",function(sym,e){sym.setVariable("current","Bridalvail_Fall");});
//Edge binding end
})("Bridalvail");
//Edge symbol end:'Bridalvail'

//=========================================================

//Edge symbol: 'Clouds'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",7000,function(sym,e){sym.play('Start');});
//Edge binding end
})("Clouds");
//Edge symbol end:'Clouds'
})(jQuery,AdobeEdge,"EDGE-655621283");