/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Gift',
            type:'image',
            rect:['86px','7px','378px','385px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Gift.png",'0px','0px']
         },
         {
            id:'GiftCopy',
            type:'image',
            rect:['86px','7px','378px','385px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Gift.png",'0px','0px']
         },
         {
            id:'rainbowburst2',
            display:'none',
            type:'image',
            rect:['0px','0px','550px','400px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"rainbowburst.jpg",'0px','0px']
         },
         {
            id:'cake',
            display:'none',
            type:'image',
            rect:['104px','69px','341px','291px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"cake.png",'0px','0px']
         },
         {
            id:'ribbon',
            display:'none',
            type:'image',
            rect:['230px','272px','90px','120px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"ribbon.png",'0px','0px']
         },
         {
            id:'slice',
            display:'none',
            type:'image',
            rect:['281px','69px','132px','208px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"slice.png",'0px','0px']
         },
         {
            id:'slice2',
            display:'none',
            type:'image',
            rect:['374','69','132px','208px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"slice.png",'0px','0px']
         },
         {
            id:'cherry',
            type:'image',
            rect:['264px','78px','21px','20px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"cherry.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_slice}": [
            ["style", "top", '69px'],
            ["transform", "scaleY", '1'],
            ["style", "display", 'none'],
            ["style", "opacity", '0'],
            ["style", "left", '280px'],
            ["transform", "scaleX", '1']
         ],
         "${_rainbowburst2}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px'],
            ["style", "display", 'none']
         ],
         "${_GiftCopy}": [
            ["style", "display", 'block'],
            ["style", "top", '7px'],
            ["style", "left", '86px'],
            ["transform", "rotateZ", '0deg']
         ],
         "${_Gift}": [
            ["style", "display", 'block'],
            ["style", "top", '7px'],
            ["style", "left", '86px'],
            ["transform", "rotateZ", '0deg']
         ],
         "${_ribbon}": [
            ["style", "top", '272px'],
            ["transform", "scaleY", '1'],
            ["style", "display", 'none'],
            ["style", "opacity", '0'],
            ["style", "left", '230px'],
            ["transform", "scaleX", '1']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "width", '100%'],
            ["style", "height", '100%'],
            ["style", "overflow", 'hidden']
         ],
         "${_cherry}": [
            ["style", "top", '78.18px'],
            ["transform", "scaleY", '1'],
            ["transform", "scaleX", '1'],
            ["style", "opacity", '0'],
            ["style", "left", '264px']
         ],
         "${_slice2}": [
            ["style", "display", 'none']
         ],
         "${_cake}": [
            ["style", "top", '68.89px'],
            ["transform", "scaleY", '1'],
            ["style", "display", 'none'],
            ["style", "opacity", '0'],
            ["style", "left", '104px'],
            ["transform", "scaleX", '1']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2356,
         autoPlay: true,
         labels: {
            "Start": 0,
            "Tap1": 376,
            "Stop2": 699,
            "Tap2": 1323,
            "Stop3": 1323,
            "Tap3": 1577,
            "Cake": 2089,
            "Slice": 2250,
            "Sliced": 2356
         },
         timeline: [
            { id: "eid126", tween: [ "style", "${_slice2}", "display", 'block', { fromValue: 'none'}], position: 2356, duration: 0 },
            { id: "eid81", tween: [ "style", "${_cherry}", "opacity", '1', { fromValue: '0.000000'}], position: 1900, duration: 189 },
            { id: "eid16", tween: [ "style", "${_GiftCopy}", "display", 'block', { fromValue: 'block'}], position: 54, duration: 0 },
            { id: "eid17", tween: [ "style", "${_GiftCopy}", "display", 'none', { fromValue: 'block'}], position: 376, duration: 0 },
            { id: "eid53", tween: [ "style", "${_ribbon}", "opacity", '1', { fromValue: '0'}], position: 1900, duration: 189 },
            { id: "eid50", tween: [ "style", "${_ribbon}", "display", 'block', { fromValue: 'none'}], position: 1900, duration: 0 },
            { id: "eid63", tween: [ "style", "${_cake}", "opacity", '1', { fromValue: '0'}], position: 1900, duration: 189 },
            { id: "eid70", tween: [ "style", "${_slice}", "display", 'block', { fromValue: 'none'}], position: 1900, duration: 0 },
            { id: "eid124", tween: [ "style", "${_slice}", "display", 'block', { fromValue: 'block'}], position: 2250, duration: 0 },
            { id: "eid125", tween: [ "style", "${_slice}", "display", 'none', { fromValue: 'block'}], position: 2356, duration: 0 },
            { id: "eid31", tween: [ "style", "${_rainbowburst2}", "opacity", '1', { fromValue: '0'}], position: 1900, duration: 148 },
            { id: "eid62", tween: [ "style", "${_cake}", "display", 'block', { fromValue: 'none'}], position: 1900, duration: 0 },
            { id: "eid48", tween: [ "style", "${_Gift}", "display", 'none', { fromValue: 'block'}], position: 2089, duration: 0 },
            { id: "eid21", tween: [ "style", "${_rainbowburst2}", "display", 'none', { fromValue: 'none'}], position: 54, duration: 0 },
            { id: "eid22", tween: [ "style", "${_rainbowburst2}", "display", 'block', { fromValue: 'none'}], position: 1900, duration: 0 },
            { id: "eid46", tween: [ "style", "${_rainbowburst2}", "display", 'none', { fromValue: 'block'}], position: 2089, duration: 0 },
            { id: "eid112", tween: [ "style", "${_slice}", "left", '280.15px', { fromValue: '280px'}], position: 1900, duration: 189 },
            { id: "eid109", tween: [ "style", "${_slice}", "left", '373.82px', { fromValue: '280.15px'}], position: 2089, duration: 161 },
            { id: "eid73", tween: [ "style", "${_slice}", "opacity", '1', { fromValue: '0'}], position: 1900, duration: 189 },
            { id: "eid14", tween: [ "transform", "${_Gift}", "rotateZ", '-4deg', { fromValue: '0deg'}], position: 376, duration: 0 },
            { id: "eid3", tween: [ "transform", "${_Gift}", "rotateZ", '2deg', { fromValue: '-4deg'}], position: 376, duration: 125 },
            { id: "eid4", tween: [ "transform", "${_Gift}", "rotateZ", '-4deg', { fromValue: '2deg'}], position: 501, duration: 125 },
            { id: "eid5", tween: [ "transform", "${_Gift}", "rotateZ", '0deg', { fromValue: '-4deg'}], position: 626, duration: 73 },
            { id: "eid6", tween: [ "transform", "${_Gift}", "rotateZ", '2deg', { fromValue: '-4deg'}], position: 1000, duration: 125 },
            { id: "eid7", tween: [ "transform", "${_Gift}", "rotateZ", '-4deg', { fromValue: '2deg'}], position: 1125, duration: 125 },
            { id: "eid8", tween: [ "transform", "${_Gift}", "rotateZ", '0deg', { fromValue: '-4deg'}], position: 1250, duration: 73 },
            { id: "eid18", tween: [ "transform", "${_Gift}", "rotateZ", '2deg', { fromValue: '-4deg'}], position: 1577, duration: 125 },
            { id: "eid19", tween: [ "transform", "${_Gift}", "rotateZ", '-4deg', { fromValue: '2deg'}], position: 1702, duration: 125 },
            { id: "eid20", tween: [ "transform", "${_Gift}", "rotateZ", '0deg', { fromValue: '-4deg'}], position: 1827, duration: 73 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-474293183");
