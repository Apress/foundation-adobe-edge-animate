/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'background',
            display:'none',
            type:'image',
            rect:['0','0','100%','100%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"background.jpg",'0px','0px']
         },
         {
            id:'Text',
            display:'none',
            type:'image',
            rect:['auto','auto','21.1%','14.4%','3.2%','5.3%'],
            fill:["rgba(0,0,0,0)",im+"Text.png",'0px','0px']
         },
         {
            id:'KidZapfino',
            type:'image',
            rect:['0','31px','478px','769px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"KidZapfino.png",'0px','0px']
         },
         {
            id:'Logo',
            display:'none',
            type:'image',
            rect:['154px','435px','561px','229px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Logo.png",'0px','0px']
         },
         {
            id:'Zbig',
            display:'none',
            type:'image',
            rect:['auto','17px','527px','424px','18px','auto'],
            fill:["rgba(0,0,0,0)",im+"Zbig.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Text}": [
            ["style", "top", 'auto'],
            ["style", "bottom", '5.27%'],
            ["style", "display", 'none'],
            ["style", "opacity", '0'],
            ["style", "left", 'auto'],
            ["style", "right", '3.24%']
         ],
         "${_Zbig}": [
            ["style", "top", '16.88px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '360deg'],
            ["style", "display", 'none'],
            ["style", "right", '17.87px'],
            ["style", "left", 'auto'],
            ["transform", "scaleX", '0']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '100%'],
            ["style", "width", '100%']
         ],
         "${_KidZapfino}": [
            ["style", "top", '31px'],
            ["style", "opacity", '0']
         ],
         "${_background}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0']
         ],
         "${_Logo}": [
            ["style", "top", '434.51px'],
            ["transform", "scaleX", '1'],
            ["transform", "scaleY", '1'],
            ["transform", "rotateZ", '0deg'],
            ["style", "display", 'none'],
            ["style", "opacity", '0'],
            ["style", "left", '154.34px'],
            ["style", "bottom", 'auto']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 4000,
         autoPlay: true,
         labels: {
            "KidZapfino": 0,
            "Background": 1750,
            "Zbig": 2750,
            "Starring": 3500
         },
         timeline: [
            { id: "eid10", tween: [ "style", "${_KidZapfino}", "opacity", '1', { fromValue: '0.000000'}], position: 0, duration: 1000 },
            { id: "eid30", tween: [ "transform", "${_Zbig}", "scaleY", '1', { fromValue: '0'}], position: 2750, duration: 250 },
            { id: "eid4", tween: [ "style", "${_background}", "opacity", '1', { fromValue: '0.000000'}], position: 1750, duration: 1000 },
            { id: "eid29", tween: [ "transform", "${_Zbig}", "scaleX", '1', { fromValue: '0'}], position: 2750, duration: 250 },
            { id: "eid11", tween: [ "style", "${_Logo}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid12", tween: [ "style", "${_Logo}", "display", 'block', { fromValue: 'none'}], position: 3000, duration: 0 },
            { id: "eid5", tween: [ "style", "${_background}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid6", tween: [ "style", "${_background}", "display", 'block', { fromValue: 'none'}], position: 1750, duration: 0 },
            { id: "eid23", tween: [ "style", "${_Zbig}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid24", tween: [ "style", "${_Zbig}", "display", 'block', { fromValue: 'none'}], position: 2750, duration: 0 },
            { id: "eid38", tween: [ "style", "${_Text}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid39", tween: [ "style", "${_Text}", "display", 'block', { fromValue: 'none'}], position: 3500, duration: 0 },
            { id: "eid43", tween: [ "style", "${_Text}", "opacity", '1', { fromValue: '0'}], position: 3500, duration: 500 },
            { id: "eid16", tween: [ "style", "${_Logo}", "opacity", '1', { fromValue: '0'}], position: 3000, duration: 500 },
            { id: "eid31", tween: [ "transform", "${_Zbig}", "rotateZ", '0deg', { fromValue: '360deg'}], position: 2750, duration: 250 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-574549533");
