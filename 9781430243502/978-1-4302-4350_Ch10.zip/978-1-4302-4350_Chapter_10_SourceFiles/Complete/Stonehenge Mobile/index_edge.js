/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'hengeBG',
            type:'image',
            rect:['0px','0px','320px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"hengeBG.png",'0px','0px']
         },
         {
            id:'sunglare',
            type:'image',
            rect:['0','0','320px','246px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"sunglare.png",'0px','0px']
         },
         {
            id:'sun',
            type:'image',
            rect:['59px','32px','120px','120px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"sun.png",'0px','0px']
         },
         {
            id:'sunflare2',
            type:'image',
            rect:['0px','82px','320px','19px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"sunflare.png",'0px','0px']
         },
         {
            id:'logo',
            type:'image',
            rect:['18px','77px','283px','30px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"logo.png",'0px','0px']
         },
         {
            id:'topBar',
            type:'image',
            rect:['0','0','320px','45px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"topBar.png",'0px','0px']
         },
         {
            id:'botmBar',
            type:'image',
            rect:['0','442','320px','41px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"botmBar.png",'0px','0px']
         },
         {
            id:'logosm',
            type:'image',
            rect:['69px','13px','182px','19px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"logosm.png",'0px','0px']
         },
         {
            id:'bird',
            display:'none',
            type:'rect',
            rect:['87','209','auto','auto','auto','auto']
         },
         {
            id:'bird2',
            display:'none',
            type:'rect',
            rect:['39','240','auto','auto','auto','auto']
         },
         {
            id:'bird3',
            display:'none',
            type:'rect',
            rect:['142','143','auto','auto','auto','auto']
         },
         {
            id:'bird4',
            display:'none',
            type:'rect',
            rect:['233','233','auto','auto','auto','auto']
         },
         {
            id:'homeBtn',
            type:'image',
            rect:['8','443px','31px','33px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"homeBtn.png",'0px','0px']
         },
         {
            id:'picBtn',
            type:'image',
            rect:['142px','446px','36px','27px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"picBtn.png",'0px','0px']
         },
         {
            id:'filmBtn',
            type:'image',
            rect:['279px','444px','32px','37px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"filmBtn.png",'0px','0px']
         },
         {
            id:'bird2TxtBox',
            display:'none',
            type:'rect',
            rect:['18px','71px','283px','324px','auto','auto'],
            borderRadius:["18px 18px","18px 18px","18px 18px","18px 18px"],
            opacity:0.50717163085938,
            fill:["rgba(210,207,180,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"],
            c:[
            {
               id:'Bird2Txt',
               display:'none',
               type:'text',
               rect:['22px','40px','254px','284px','auto','auto'],
               text:"Nunc tempus felis vitae urna. Vivamus porttitor, neque at volutpat rutrum, purus nisi eleifend libero, a tempus libero lectus feugiat felis. Morbi diam mauris, viverra in, gravida eu, mattis in, ante. Morbi eget arcu. Morbi porta, libero id ullamcorper nonummy, nibh ligula pulvinar metus, eget consectetuer augue nisi quis lacus. Ut ac mi quis lacus mollis aliquam. Curabitur iaculis tempus eros. Curabitur vel mi sit amet magna malesuada ultrices. Ut nisi erat, fermentum vel, congue id, euismod in, elit. ",
               align:"left",
               font:['Arial, Helvetica, sans-serif',16,"rgba(0,0,0,1)","normal","none","normal"]
            }]
         },
         {
            id:'bird2TxtHD',
            display:'none',
            type:'text',
            rect:['24px','80px','auto','auto','auto','auto'],
            text:"History of Stonehenge",
            align:"left",
            font:['Georgia, Times New Roman, Times, serif',22,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'birdTxt3Box',
            display:'none',
            type:'rect',
            rect:['18px','71px','283px','324px','auto','auto'],
            borderRadius:["18px 18px","18px 18px","18px 18px","18px 18px"],
            opacity:0.50717163085938,
            fill:["rgba(210,207,180,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"],
            c:[
            {
               id:'Bird3Txt',
               display:'none',
               type:'text',
               rect:['22px','40px','254px','284px','auto','auto'],
               text:"Mauris vel lacus vitae felis vestibulum volutpat. Etiam est nunc, venenatis in, tristique eu, imperdiet ac, nisl. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In iaculis facilisis massa. Etiam eu urna. Sed porta. Suspendisse quam leo, molestie sed, luctus quis, feugiat in, pede.Fusce tellus. Sed metus augue, convallis et, vehicula ut, pulvinar eu, ante. Integer orci tellus, tristique vitae, consequat nec, porta vel.",
               align:"left",
               font:['Arial, Helvetica, sans-serif',16,"rgba(0,0,0,1)","normal","none","normal"]
            }]
         },
         {
            id:'bird3TxtHD',
            display:'none',
            type:'text',
            rect:['24px','80px','auto','auto','auto','auto'],
            text:"Theory of The Stones",
            align:"left",
            font:['Georgia, Times New Roman, Times, serif',22,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'birdTxt4Box',
            display:'none',
            type:'rect',
            rect:['18px','71px','283px','324px','auto','auto'],
            borderRadius:["18px 18px","18px 18px","18px 18px","18px 18px"],
            opacity:0.50717163085938,
            fill:["rgba(210,207,180,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"],
            c:[
            {
               id:'Bird4Txt',
               display:'none',
               type:'text',
               rect:['22px','40px','254px','284px','auto','auto'],
               text:"Phasellus felis dolor, scelerisque a, tempus eget, lobortis id, libero. Donec scelerisque leo ac risus. Praesent sit amet est. In dictum, dolor eu dictum porttitor, enim felis viverra mi, eget luctus massa purus quis odio. Etiam nulla massa, pharetra facilisis, volutpat in, imperdiet sit amet, sem. Aliquam nec erat at purus cursus interdum. Vestibulum ligula augue, bibendum accumsan, vestibulum ut, commodo a, mi. Morbi ornare gravida elit. Integer congue, augue.",
               align:"left",
               font:['Arial, Helvetica, sans-serif',16,"rgba(0,0,0,1)","normal","none","normal"]
            }]
         },
         {
            id:'bird4TxtHD',
            display:'none',
            type:'text',
            rect:['24px','80px','auto','auto','auto','auto'],
            text:"Why were they built?",
            align:"left",
            font:['Georgia, Times New Roman, Times, serif',22,"rgba(0,0,0,1)","normal","none","normal"]
         },
         {
            id:'backBtn',
            display:'none',
            type:'image',
            rect:['228px','378px','81px','22px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"backBtn.png",'0px','0px']
         },
         {
            id:'photo1',
            display:'none',
            type:'image',
            rect:['10px','47px','300px','300px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"photo1.jpg",'0px','0px']
         },
         {
            id:'photo2',
            display:'none',
            type:'image',
            rect:['10','47','300px','300px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"photo2.jpg",'0px','0px']
         },
         {
            id:'photo3',
            display:'none',
            type:'image',
            rect:['10','47','300px','300px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"photo3.jpg",'0px','0px']
         },
         {
            id:'photo1prv',
            display:'none',
            type:'image',
            rect:['66px','336px','50px','50px','auto','auto'],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"photo1prv.jpg",'0px','0px']
         },
         {
            id:'photo2prv',
            display:'none',
            type:'image',
            rect:['136px','336px','50px','50px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"photo2prv.jpg",'0px','0px']
         },
         {
            id:'photo3prv',
            display:'none',
            type:'image',
            rect:['204px','335px','50px','50px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"photo3prv.jpg",'0px','0px']
         },
         {
            id:'photSelectBx',
            display:'none',
            type:'rect',
            rect:['66px','336px','50px','50px','auto','auto'],
            opacity:0.5,
            fill:["rgba(0,0,0,1.00)"],
            stroke:[0,"rgb(0, 0, 0)","none"]
         },
         {
            id:'Vid',
            display:'none',
            type:'rect',
            rect:['8','128','auto','auto','auto','auto']
         }],
         symbolInstances: [
         {
            id:'bird',
            symbolName:'bird'
         },
         {
            id:'Vid',
            symbolName:'Vid'
         },
         {
            id:'bird2',
            symbolName:'bird'
         },
         {
            id:'bird3',
            symbolName:'bird'
         },
         {
            id:'bird4',
            symbolName:'bird'
         }
         ]
      },
   states: {
      "Base State": {
         "${_homeBtn}": [
            ["style", "top", '443px'],
            ["style", "opacity", '0']
         ],
         "${_Bird4Txt}": [
            ["style", "top", '40px'],
            ["style", "width", '239.20001220703px'],
            ["style", "height", '284px'],
            ["style", "display", 'none'],
            ["style", "left", '21.8px'],
            ["style", "font-size", '16px']
         ],
         "${_bird3TxtHD}": [
            ["style", "top", '80px'],
            ["style", "display", 'none'],
            ["style", "font-family", 'Georgia, \'Times New Roman\', Times, serif'],
            ["style", "left", '24px'],
            ["style", "font-size", '22px']
         ],
         "${_photo2prv}": [
            ["style", "top", '335.75px'],
            ["style", "left", '136px'],
            ["style", "display", 'none']
         ],
         "${_sun}": [
            ["style", "top", '31.73px'],
            ["style", "opacity", '0'],
            ["style", "left", '58.73px']
         ],
         "${_filmBtn}": [
            ["style", "top", '441px'],
            ["style", "opacity", '0'],
            ["style", "left", '279.32px']
         ],
         "${_bird2TxtBox}": [
            ["color", "background-color", 'rgba(210,207,180,1)'],
            ["style", "border-top-left-radius", [18,18], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "height", '323.62344360352px'],
            ["style", "border-bottom-right-radius", [18,18], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "display", 'none'],
            ["style", "opacity", '0.507171630859375'],
            ["style", "border-top-right-radius", [18,18], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-left-radius", [18,18], {valueTemplate:'@@0@@px @@1@@px'} ]
         ],
         "${_bird2}": [
            ["style", "display", 'none'],
            ["style", "opacity", '0'],
            ["style", "left", '24px'],
            ["style", "top", '240px']
         ],
         "${_sunflare2}": [
            ["style", "top", '82px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px']
         ],
         "${_logo}": [
            ["style", "top", '77px'],
            ["style", "opacity", '0'],
            ["style", "left", '18px']
         ],
         "${_picBtn}": [
            ["style", "top", '446px'],
            ["style", "opacity", '0'],
            ["style", "left", '142px']
         ],
         "${_photo2}": [
            ["style", "display", 'none']
         ],
         "${_hengeBG}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px']
         ],
         "${_bird4TxtHD}": [
            ["style", "top", '80px'],
            ["style", "display", 'none'],
            ["style", "font-family", 'Georgia, \'Times New Roman\', Times, serif'],
            ["style", "left", '24px'],
            ["style", "font-size", '22px']
         ],
         "${_birdTxt3Box}": [
            ["color", "background-color", 'rgba(210,207,180,1)'],
            ["style", "border-top-left-radius", [18,18], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-left-radius", [18,18], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-bottom-right-radius", [18,18], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "height", '323.62344360352px'],
            ["style", "opacity", '0.507171630859375'],
            ["style", "border-top-right-radius", [18,18], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "display", 'none']
         ],
         "${_bird3TxtHDCopy}": [
            ["style", "top", '80px'],
            ["style", "display", 'block'],
            ["style", "font-family", 'Georgia, \'Times New Roman\', Times, serif'],
            ["style", "left", '24px'],
            ["style", "font-size", '22px']
         ],
         "${_botmBar}": [
            ["style", "opacity", '0']
         ],
         "${_bird}": [
            ["style", "display", 'none'],
            ["style", "left", '-76px'],
            ["style", "top", '190px']
         ],
         "${_birdTxt4Box}": [
            ["color", "background-color", 'rgba(210,207,180,1)'],
            ["style", "border-bottom-left-radius", [18,18], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "display", 'none'],
            ["style", "border-bottom-right-radius", [18,18], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "height", '323.62344360352px'],
            ["style", "opacity", '0.507171630859375'],
            ["style", "border-top-right-radius", [18,18], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-top-left-radius", [18,18], {valueTemplate:'@@0@@px @@1@@px'} ]
         ],
         "${_sunglare}": [
            ["style", "opacity", '0']
         ],
         "${_Bird3TxtCopy}": [
            ["style", "top", '40px'],
            ["style", "width", '239.20001220703px'],
            ["style", "height", '284px'],
            ["style", "display", 'block'],
            ["style", "left", '21.8px'],
            ["style", "font-size", '16px']
         ],
         "${_Vid}": [
            ["style", "display", 'none']
         ],
         "${_topBar}": [
            ["style", "opacity", '0']
         ],
         "${_photo1prv}": [
            ["style", "top", '335.75px'],
            ["style", "left", '66px'],
            ["style", "display", 'none']
         ],
         "${_bird2TxtHD}": [
            ["style", "top", '80px'],
            ["style", "display", 'none'],
            ["style", "font-family", 'Georgia, \'Times New Roman\', Times, serif'],
            ["style", "left", '24px'],
            ["style", "font-size", '22px']
         ],
         "${_bird3}": [
            ["style", "top", '130.47px'],
            ["style", "opacity", '0'],
            ["style", "left", '119px'],
            ["style", "display", 'none']
         ],
         "${_photo1}": [
            ["style", "top", '47.2px'],
            ["style", "left", '10px'],
            ["style", "display", 'none']
         ],
         "${_Bird3TxtCopy3}": [
            ["style", "top", '40px'],
            ["style", "width", '239.20001220703px'],
            ["style", "height", '284px'],
            ["style", "display", 'block'],
            ["style", "left", '21.8px'],
            ["style", "font-size", '16px']
         ],
         "${_photo3prv}": [
            ["style", "top", '335.45px'],
            ["style", "left", '204px'],
            ["style", "display", 'none']
         ],
         "${_photSelectBx}": [
            ["style", "top", '336px'],
            ["style", "display", 'none'],
            ["style", "opacity", '0.5'],
            ["style", "left", '66px'],
            ["color", "background-color", 'rgba(0,0,0,1.00)']
         ],
         "${_backBtn}": [
            ["style", "top", '377.8px'],
            ["style", "left", '228px'],
            ["style", "display", 'none']
         ],
         "${_Bird2Txt}": [
            ["style", "top", '40px'],
            ["style", "width", '253.68333435059px'],
            ["style", "height", '284px'],
            ["style", "display", 'none'],
            ["style", "left", '21.8px'],
            ["style", "font-size", '16px']
         ],
         "${_Bird3Txt}": [
            ["style", "top", '40px'],
            ["style", "font-size", '16px'],
            ["style", "height", '284px'],
            ["style", "display", 'none'],
            ["style", "left", '21.8px'],
            ["style", "width", '239.20001220703px']
         ],
         "${_logosm}": [
            ["style", "top", '13px'],
            ["style", "opacity", '0'],
            ["style", "left", '69px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '480px'],
            ["style", "width", '320px']
         ],
         "${_bird3TxtHDCopy3}": [
            ["style", "top", '80px'],
            ["style", "display", 'block'],
            ["style", "font-family", 'Georgia, \'Times New Roman\', Times, serif'],
            ["style", "left", '24px'],
            ["style", "font-size", '22px']
         ],
         "${_bird4}": [
            ["style", "top", '205.71px'],
            ["style", "opacity", '0'],
            ["style", "left", '203px'],
            ["style", "display", 'none']
         ],
         "${_photo3}": [
            ["style", "display", 'none']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 11750,
         autoPlay: true,
         labels: {
            "Home": 8000,
            "Select": 9250,
            "Bird2Txt": 9500,
            "Bird3Txt": 10000,
            "Bird4Txt": 10500,
            "Photo1": 11000,
            "Photo2": 11250,
            "Photo3": 11500,
            "Video": 11750
         },
         timeline: [
            { id: "eid154", tween: [ "style", "${_Bird3Txt}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid155", tween: [ "style", "${_Bird3Txt}", "display", 'none', { fromValue: 'none'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid162", tween: [ "style", "${_Bird3Txt}", "display", 'block', { fromValue: 'none'}], position: 10000, duration: 0, easing: "swing" },
            { id: "eid178", tween: [ "style", "${_Bird3Txt}", "display", 'none', { fromValue: 'block'}], position: 10500, duration: 0, easing: "swing" },
            { id: "eid49", tween: [ "style", "${_homeBtn}", "opacity", '1', { fromValue: '0.000000'}], position: 8000, duration: 750, easing: "swing" },
            { id: "eid109", tween: [ "style", "${_homeBtn}", "opacity", '0.82', { fromValue: '1'}], position: 8750, duration: 750 },
            { id: "eid30", tween: [ "style", "${_bird}", "top", '190px', { fromValue: '190px'}], position: 6000, duration: 0 },
            { id: "eid142", tween: [ "style", "${_bird2TxtHD}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid148", tween: [ "style", "${_bird2TxtHD}", "display", 'block', { fromValue: 'none'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid157", tween: [ "style", "${_bird2TxtHD}", "display", 'none', { fromValue: 'block'}], position: 10000, duration: 0, easing: "swing" },
            { id: "eid39", tween: [ "style", "${_topBar}", "opacity", '1', { fromValue: '0.000000'}], position: 8000, duration: 1000, easing: "swing" },
            { id: "eid196", tween: [ "style", "${_photSelectBx}", "left", '136px', { fromValue: '66px'}], position: 11000, duration: 250, easing: "swing" },
            { id: "eid198", tween: [ "style", "${_photSelectBx}", "left", '204px', { fromValue: '136px'}], position: 11250, duration: 250, easing: "swing" },
            { id: "eid159", tween: [ "style", "${_Bird3Txt}", "width", '239.20001220703px', { fromValue: '239.20001220703px'}], position: 10000, duration: 0, easing: "swing" },
            { id: "eid79", tween: [ "style", "${_bird2}", "opacity", '1', { fromValue: '0'}], position: 9000, duration: 250, easing: "swing" },
            { id: "eid186", tween: [ "style", "${_photSelectBx}", "display", 'block', { fromValue: 'none'}], position: 11000, duration: 0, easing: "swing" },
            { id: "eid202", tween: [ "style", "${_photSelectBx}", "display", 'none', { fromValue: 'block'}], position: 11750, duration: 0, easing: "swing" },
            { id: "eid172", tween: [ "style", "${_Bird4Txt}", "width", '239.20001220703px', { fromValue: '239.20001220703px'}], position: 10000, duration: 0, easing: "swing" },
            { id: "eid52", tween: [ "style", "${_picBtn}", "opacity", '1', { fromValue: '0.000000'}], position: 8000, duration: 1000, easing: "swing" },
            { id: "eid184", tween: [ "style", "${_photo2prv}", "display", 'block', { fromValue: 'none'}], position: 11000, duration: 0, easing: "swing" },
            { id: "eid204", tween: [ "style", "${_photo2prv}", "display", 'none', { fromValue: 'block'}], position: 11750, duration: 0, easing: "swing" },
            { id: "eid34", tween: [ "style", "${_bird}", "left", '320px', { fromValue: '-76px'}], position: 6000, duration: 2000, easing: "swing" },
            { id: "eid150", tween: [ "style", "${_bird3TxtHD}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid151", tween: [ "style", "${_bird3TxtHD}", "display", 'none', { fromValue: 'none'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid160", tween: [ "style", "${_bird3TxtHD}", "display", 'block', { fromValue: 'none'}], position: 10000, duration: 0, easing: "swing" },
            { id: "eid176", tween: [ "style", "${_bird3TxtHD}", "display", 'none', { fromValue: 'block'}], position: 10500, duration: 0, easing: "swing" },
            { id: "eid163", tween: [ "style", "${_bird4TxtHD}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid164", tween: [ "style", "${_bird4TxtHD}", "display", 'none', { fromValue: 'none'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid165", tween: [ "style", "${_bird4TxtHD}", "display", 'none', { fromValue: 'none'}], position: 10000, duration: 0, easing: "swing" },
            { id: "eid173", tween: [ "style", "${_bird4TxtHD}", "display", 'block', { fromValue: 'none'}], position: 10500, duration: 0, easing: "swing" },
            { id: "eid179", tween: [ "style", "${_bird4TxtHD}", "display", 'none', { fromValue: 'block'}], position: 11000, duration: 0, easing: "swing" },
            { id: "eid183", tween: [ "style", "${_photo1prv}", "display", 'block', { fromValue: 'none'}], position: 11000, duration: 0, easing: "swing" },
            { id: "eid205", tween: [ "style", "${_photo1prv}", "display", 'none', { fromValue: 'block'}], position: 11750, duration: 0, easing: "swing" },
            { id: "eid190", tween: [ "style", "${_photo2}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid188", tween: [ "style", "${_photo2}", "display", 'none', { fromValue: 'none'}], position: 11000, duration: 0, easing: "swing" },
            { id: "eid189", tween: [ "style", "${_photo2}", "display", 'block', { fromValue: 'none'}], position: 11250, duration: 0, easing: "swing" },
            { id: "eid199", tween: [ "style", "${_photo2}", "display", 'none', { fromValue: 'block'}], position: 11500, duration: 0, easing: "swing" },
            { id: "eid197", tween: [ "style", "${_photSelectBx}", "opacity", '0.5', { fromValue: '0.5'}], position: 11250, duration: 0, easing: "swing" },
            { id: "eid42", tween: [ "style", "${_botmBar}", "opacity", '1', { fromValue: '0.000000'}], position: 8000, duration: 1000, easing: "swing" },
            { id: "eid46", tween: [ "style", "${_logosm}", "opacity", '1', { fromValue: '0'}], position: 8000, duration: 1000, easing: "swing" },
            { id: "eid74", tween: [ "style", "${_bird2}", "display", 'block', { fromValue: 'none'}], position: 9000, duration: 0, easing: "swing" },
            { id: "eid139", tween: [ "style", "${_bird2}", "display", 'none', { fromValue: 'block'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid182", tween: [ "style", "${_photo1}", "display", 'block', { fromValue: 'none'}], position: 11000, duration: 0, easing: "swing" },
            { id: "eid187", tween: [ "style", "${_photo1}", "display", 'none', { fromValue: 'block'}], position: 11250, duration: 0, easing: "swing" },
            { id: "eid144", tween: [ "style", "${_Bird2Txt}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid146", tween: [ "style", "${_Bird2Txt}", "display", 'block', { fromValue: 'none'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid158", tween: [ "style", "${_Bird2Txt}", "display", 'none', { fromValue: 'block'}], position: 10000, duration: 0, easing: "swing" },
            { id: "eid169", tween: [ "style", "${_Bird4Txt}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid170", tween: [ "style", "${_Bird4Txt}", "display", 'none', { fromValue: 'none'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid171", tween: [ "style", "${_Bird4Txt}", "display", 'none', { fromValue: 'none'}], position: 10000, duration: 0, easing: "swing" },
            { id: "eid175", tween: [ "style", "${_Bird4Txt}", "display", 'block', { fromValue: 'none'}], position: 10500, duration: 0, easing: "swing" },
            { id: "eid143", tween: [ "style", "${_backBtn}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid149", tween: [ "style", "${_backBtn}", "display", 'block', { fromValue: 'none'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid181", tween: [ "style", "${_backBtn}", "display", 'none', { fromValue: 'block'}], position: 11000, duration: 0, easing: "swing" },
            { id: "eid71", tween: [ "style", "${_bird3}", "top", '130.47px', { fromValue: '130.47px'}], position: 9000, duration: 0, easing: "swing" },
            { id: "eid12", tween: [ "style", "${_logo}", "opacity", '1', { fromValue: '0.000000'}], position: 3000, duration: 2000 },
            { id: "eid36", tween: [ "style", "${_logo}", "opacity", '0', { fromValue: '1'}], position: 6000, duration: 2000, easing: "swing" },
            { id: "eid75", tween: [ "style", "${_bird3}", "display", 'block', { fromValue: 'none'}], position: 9000, duration: 0, easing: "swing" },
            { id: "eid140", tween: [ "style", "${_bird3}", "display", 'none', { fromValue: 'block'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid200", tween: [ "style", "${_photo3}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid201", tween: [ "style", "${_photo3}", "display", 'block', { fromValue: 'none'}], position: 11500, duration: 0, easing: "swing" },
            { id: "eid206", tween: [ "style", "${_photo3}", "display", 'none', { fromValue: 'block'}], position: 11750, duration: 0, easing: "swing" },
            { id: "eid63", tween: [ "style", "${_filmBtn}", "top", '441px', { fromValue: '441px'}], position: 8000, duration: 0, easing: "swing" },
            { id: "eid152", tween: [ "style", "${_birdTxt3Box}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid153", tween: [ "style", "${_birdTxt3Box}", "display", 'none', { fromValue: 'none'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid161", tween: [ "style", "${_birdTxt3Box}", "display", 'block', { fromValue: 'none'}], position: 10000, duration: 0, easing: "swing" },
            { id: "eid177", tween: [ "style", "${_birdTxt3Box}", "display", 'none', { fromValue: 'block'}], position: 10500, duration: 0, easing: "swing" },
            { id: "eid66", tween: [ "style", "${_bird3}", "left", '119px', { fromValue: '119px'}], position: 9000, duration: 0, easing: "swing" },
            { id: "eid76", tween: [ "style", "${_bird4}", "display", 'block', { fromValue: 'none'}], position: 9000, duration: 0, easing: "swing" },
            { id: "eid141", tween: [ "style", "${_bird4}", "display", 'none', { fromValue: 'block'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid65", tween: [ "style", "${_bird2}", "left", '24px', { fromValue: '24px'}], position: 9000, duration: 0, easing: "swing" },
            { id: "eid82", tween: [ "style", "${_bird3}", "opacity", '1', { fromValue: '0'}], position: 9000, duration: 250, easing: "swing" },
            { id: "eid57", tween: [ "style", "${_filmBtn}", "opacity", '1', { fromValue: '0.000000'}], position: 8000, duration: 1000, easing: "swing" },
            { id: "eid208", tween: [ "style", "${_Vid}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid209", tween: [ "style", "${_Vid}", "display", 'block', { fromValue: 'none'}], position: 11750, duration: 0, easing: "swing" },
            { id: "eid6", tween: [ "style", "${_sun}", "opacity", '1', { fromValue: '0.000000'}], position: 1000, duration: 2000 },
            { id: "eid3", tween: [ "style", "${_sunglare}", "opacity", '1', { fromValue: '0.000000'}], position: 1000, duration: 2000 },
            { id: "eid166", tween: [ "style", "${_birdTxt4Box}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid167", tween: [ "style", "${_birdTxt4Box}", "display", 'none', { fromValue: 'none'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid168", tween: [ "style", "${_birdTxt4Box}", "display", 'none', { fromValue: 'none'}], position: 10000, duration: 0, easing: "swing" },
            { id: "eid174", tween: [ "style", "${_birdTxt4Box}", "display", 'block', { fromValue: 'none'}], position: 10500, duration: 0, easing: "swing" },
            { id: "eid180", tween: [ "style", "${_birdTxt4Box}", "display", 'none', { fromValue: 'block'}], position: 11000, duration: 0, easing: "swing" },
            { id: "eid15", tween: [ "style", "${_hengeBG}", "opacity", '1', { fromValue: '0.000000'}], position: 0, duration: 1533 },
            { id: "eid9", tween: [ "style", "${_sunflare2}", "opacity", '1', { fromValue: '0.000000'}], position: 2500, duration: 500 },
            { id: "eid145", tween: [ "style", "${_bird2TxtBox}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "swing" },
            { id: "eid147", tween: [ "style", "${_bird2TxtBox}", "display", 'block', { fromValue: 'none'}], position: 9500, duration: 0, easing: "swing" },
            { id: "eid156", tween: [ "style", "${_bird2TxtBox}", "display", 'none', { fromValue: 'block'}], position: 10000, duration: 0, easing: "swing" },
            { id: "eid85", tween: [ "style", "${_bird4}", "opacity", '1', { fromValue: '0'}], position: 9000, duration: 250, easing: "swing" },
            { id: "eid28", tween: [ "style", "${_bird}", "display", 'block', { fromValue: 'none'}], position: 6000, duration: 0 },
            { id: "eid33", tween: [ "style", "${_bird}", "display", 'none', { fromValue: 'block'}], position: 8000, duration: 0 },
            { id: "eid73", tween: [ "style", "${_bird4}", "top", '205.71px', { fromValue: '205.71px'}], position: 9000, duration: 0, easing: "swing" },
            { id: "eid72", tween: [ "style", "${_bird4}", "left", '203px', { fromValue: '203px'}], position: 9000, duration: 0, easing: "swing" },
            { id: "eid185", tween: [ "style", "${_photo3prv}", "display", 'block', { fromValue: 'none'}], position: 11000, duration: 0, easing: "swing" },
            { id: "eid203", tween: [ "style", "${_photo3prv}", "display", 'none', { fromValue: 'block'}], position: 11750, duration: 0, easing: "swing" }         ]
      }
   }
},
"bird": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'bird1',
      type: 'image',
      rect: ['0px','0px','76px','56px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/bird1.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['0','0','81px','60px','auto','auto'],
      id: 'bird2',
      fill: ['rgba(0,0,0,0)','images/bird2.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['0','-57px','89px','76px','auto','auto'],
      id: 'bird3',
      fill: ['rgba(0,0,0,0)','images/bird3.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_bird3}": [
            ["style", "top", '-48px'],
            ["style", "display", 'none']
         ],
         "${_bird1}": [
            ["style", "top", '0.47px'],
            ["style", "left", '-0.02px'],
            ["style", "display", 'block']
         ],
         "${_bird2}": [
            ["style", "display", 'none'],
            ["style", "top", '7.34px']
         ],
         "${symbolSelector}": [
            ["style", "height", '56px'],
            ["style", "width", '76px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 750,
         autoPlay: true,
         labels: {
            "Start": 0
         },
         timeline: [
            { id: "eid27", tween: [ "style", "${_bird1}", "display", 'none', { fromValue: 'block'}], position: 250, duration: 0 },
            { id: "eid16", tween: [ "style", "${_bird1}", "display", 'none', { fromValue: 'none'}], position: 500, duration: 0 },
            { id: "eid18", tween: [ "style", "${_bird3}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid20", tween: [ "style", "${_bird3}", "display", 'block', { fromValue: 'block'}], position: 500, duration: 0 },
            { id: "eid25", tween: [ "style", "${_bird3}", "display", 'none', { fromValue: 'block'}], position: 750, duration: 0 },
            { id: "eid19", tween: [ "style", "${_bird2}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid17", tween: [ "style", "${_bird2}", "display", 'block', { fromValue: 'none'}], position: 250, duration: 0 },
            { id: "eid22", tween: [ "style", "${_bird2}", "display", 'none', { fromValue: 'block'}], position: 500, duration: 0 },
            { id: "eid24", tween: [ "style", "${_bird2}", "display", 'block', { fromValue: 'none'}], position: 750, duration: 0 },
            { id: "eid26", tween: [ "style", "${_bird2}", "top", '7.34px', { fromValue: '7.34px'}], position: 750, duration: 0 },
            { id: "eid23", tween: [ "style", "${_bird3}", "top", '-48px', { fromValue: '-48px'}], position: 500, duration: 0 }         ]
      }
   }
},
"Vid": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      type: 'rect',
      id: 'container',
      stroke: [0,'rgba(0,0,0,0.00)','none'],
      rect: ['0px','0px','300px','169px','auto','auto'],
      fill: ['rgba(0,0,0,0.00)']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '169px'],
            ["style", "width", '300px']
         ],
         "${_container}": [
            ["style", "top", '0.01px'],
            ["color", "background-color", 'rgba(0,0,0,0.00)'],
            ["style", "height", '169px'],
            ["color", "border-color", 'rgba(0,0,0,0.00)'],
            ["style", "left", '0px'],
            ["style", "width", '300px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-404703449");
