/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 9250, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_homeBtn}", "touchstart", function(sym, e) {
         sym.play('Home');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_homeBtn}", "click", function(sym, e) {
         sym.play('Home');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bird2}", "click", function(sym, e) {
         sym.play('Bird2Txt');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bird3}", "click", function(sym, e) {
         sym.play('Bird3Txt');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_bird4}", "click", function(sym, e) {
         sym.play('Bird4Txt');
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 9500, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_backBtn}", "click", function(sym, e) {
         sym.play('Home');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_backBtn}", "touchstart", function(sym, e) {
         sym.play('Home');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 10000, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 11000, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_picBtn}", "click", function(sym, e) {
         sym.play('Photo1');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_picBtn}", "touchstart", function(sym, e) {
         sym.play('Photo1');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_photo2prv}", "click", function(sym, e) {
         sym.play('Photo2');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_photo2prv}", "touchstart", function(sym, e) {
         sym.play('Photo2');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_photo3prv}", "click", function(sym, e) {
         sym.play('Photo3');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_photo3prv}", "touchstart", function(sym, e) {
         sym.play('Photo3');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_photo1prv}", "click", function(sym, e) {
         sym.play('Photo1');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_photo1prv}", "touchstart", function(sym, e) {
         sym.play('Photo1');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_photo1}", "click", function(sym, e) {
         sym.play('Photo2');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_photo1}", "touchstart", function(sym, e) {
         sym.play('Photo2');
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 11250, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 11500, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 10500, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 11750, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_filmBtn}", "click", function(sym, e) {
         sym.play('Video');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_filmBtn}", "touchstart", function(sym, e) {
         sym.play('Video');
         

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'bird'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 750, function(sym, e) {
         sym.play('Start');

      });
      //Edge binding end

   })("bird");
   //Edge symbol end:'bird'

   //=========================================================
   
   //Edge symbol: 'Vid'
   (function(symbolName) {   
   
      Symbol.bindSymbolAction(compId, symbolName, "creationComplete", function(sym, e) {
         var container =sym.$("container");
         var vid ='<iframe width="300" height="169" src="http://www.youtube.com/embed/-6oxmxPKoSE?rel=0" frameborder="0" allowfullscreen></iframe>';
         container.html(vid);

      });
      //Edge binding end

   })("Vid");
   //Edge symbol end:'Vid'

})(jQuery, AdobeEdge, "EDGE-404703449");