/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Background',
            type:'image',
            rect:['0','0','300','227','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Background.png"]
         },
         {
            id:'ClickDetails',
            type:'image',
            rect:['163','207','129','12','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"ClickDetails.png"],
            transform:[]
         },
         {
            id:'Discount',
            type:'image',
            rect:['205','10','94','53','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Discount.png"],
            transform:[]
         },
         {
            id:'Logo',
            type:'image',
            rect:['7','6','166','61','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Logo.png"],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_stage}": [
            ["style", "height", '227px'],
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "width", '300px']
         ],
         "${_Discount}": [
            ["style", "left", '205.99px'],
            ["style", "top", '10px']
         ],
         "${_ClickDetails}": [
            ["style", "left", '163.38px'],
            ["style", "top", '207.18px']
         ],
         "${_Logo}": [
            ["style", "left", '7px'],
            ["style", "top", '6px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-16215073");
