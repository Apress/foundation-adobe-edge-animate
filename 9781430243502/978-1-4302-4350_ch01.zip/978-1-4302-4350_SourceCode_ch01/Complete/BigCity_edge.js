/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.161",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Background',
            type:'image',
            rect:['0','0','300','227','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Background.png"]
         },
         {
            id:'ClickDetails',
            type:'image',
            rect:['163px','207px','129','12','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"ClickDetails.png"],
            transform:[]
         },
         {
            id:'Discount',
            type:'image',
            rect:['205','10','94','53','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Discount.png"],
            transform:[]
         },
         {
            id:'Logo',
            type:'image',
            rect:['7','6','166','61','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"Logo.png"],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_ClickDetails}": [
            ["style", "top", '207.18px'],
            ["style", "left", '-136px']
         ],
         "${_Discount}": [
            ["style", "top", '10px'],
            ["style", "opacity", '0'],
            ["style", "left", '205.99px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(0,0,0,1.00)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '227px'],
            ["style", "width", '300px']
         ],
         "${_Logo}": [
            ["style", "left", '7px'],
            ["style", "top", '6px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 500,
         autoPlay: true,
         timeline: [
            { id: "eid16", tween: [ "style", "${_ClickDetails}", "left", '163.38px', { fromValue: '-136px'}], position: 0, duration: 500, easing: "easeOutBounce" },
            { id: "eid3", tween: [ "style", "${_Discount}", "opacity", '1', { fromValue: '0.000000'}], position: 0, duration: 500 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-16215073");
