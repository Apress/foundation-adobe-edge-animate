/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'background',
            type:'image',
            rect:['0','0','2146','80','undefined','undefined'],
            fill:["rgba(0,0,0,0)",im+"background.png"]
         },
         {
            id:'Racer',
            type:'rect',
            rect:['-298px','-83px','auto','auto','auto','auto'],
            transform:[[],[],[],['0.25','0.25']]
         }],
         symbolInstances: [
         {
            id:'Racer',
            symbolName:'Racer'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '768px'],
            ["style", "height", '80px'],
            ["style", "overflow", 'hidden']
         ],
         "${_Racer}": [
            ["style", "top", '-82.87px'],
            ["style", "left", '-297.75px'],
            ["transform", "scaleY", '0.25'],
            ["transform", "scaleX", '0.25']
         ],
         "${_background}": [
            ["style", "left", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         timeline: [
            { id: "eid12", tween: [ "style", "${_Racer}", "top", '-82.87px', { fromValue: '-82.87px'}], position: 2000, duration: 0 },
            { id: "eid2", tween: [ "style", "${_background}", "left", '-1378px', { fromValue: '0px'}], position: 0, duration: 2000 },
            { id: "eid11", tween: [ "style", "${_Racer}", "left", '482.87px', { fromValue: '-297.75px'}], position: 0, duration: 2000 }         ]
      }
   }
},
"Racer": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'carbody',
      type: 'image',
      rect: ['0px','0px','794px','245px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/carbody.png','0px','0px']
   },
   {
      id: 'Wheel',
      type: 'rect',
      rect: ['81','160','auto','auto','auto','auto']
   },
   {
      id: 'Wheel2',
      type: 'rect',
      rect: ['578px','168','auto','auto','auto','auto']
   }],
   symbolInstances: [
   {
      id: 'Wheel2',
      symbolName: 'Wheel'
   },
   {
      id: 'Wheel',
      symbolName: 'Wheel'
   }   ]
   },
   states: {
      "Base State": {
         "${_Wheel2}": [
            ["style", "left", '578.21px'],
            ["style", "top", '160px']
         ],
         "${_carbody}": [
            ["style", "left", '0px'],
            ["style", "top", '-0.01px']
         ],
         "${symbolSelector}": [
            ["style", "height", '245px'],
            ["style", "width", '794px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"Wheel": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'carwheel',
      type: 'image',
      rect: ['0px','0px','128px','128px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/carwheel.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '128px'],
            ["style", "width", '128px']
         ],
         "${_carwheel}": [
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["transform", "rotateZ", '0deg']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1039,
         autoPlay: true,
         timeline: [
            { id: "eid4", tween: [ "transform", "${_carwheel}", "rotateZ", '1080deg', { fromValue: '0deg'}], position: 0, duration: 1039 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-168113207");
