/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Subway_01',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2001.png",'0px','0px']
         },
         {
            id:'Subway_02',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2002.png",'0px','0px']
         },
         {
            id:'Subway_03',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2003.png",'0px','0px']
         },
         {
            id:'Subway_04',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2004.png",'0px','0px']
         },
         {
            id:'Subway_05',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2005.png",'0px','0px']
         },
         {
            id:'Subway_06',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2006.png",'0px','0px']
         },
         {
            id:'Subway_07',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2007.png",'0px','0px']
         },
         {
            id:'Subway_08',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2008.png",'0px','0px']
         },
         {
            id:'Subway_09',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2009.png",'0px','0px']
         },
         {
            id:'Subway_10',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2010.png",'0px','0px']
         },
         {
            id:'Subway_11',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2011.png",'0px','0px']
         },
         {
            id:'Subway_12',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2012.png",'0px','0px']
         },
         {
            id:'Subway_13',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2013.png",'0px','0px']
         },
         {
            id:'Subway_14',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2014.png",'0px','0px']
         },
         {
            id:'Subway_15',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2015.png",'0px','0px']
         },
         {
            id:'Subway_16',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2016.png",'0px','0px']
         },
         {
            id:'Subway_17',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2017.png",'0px','0px']
         },
         {
            id:'Subway_18',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2018.png",'0px','0px']
         },
         {
            id:'Subway_19',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2019.png",'0px','0px']
         },
         {
            id:'Subway_20',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2020.png",'0px','0px']
         },
         {
            id:'Subway_21',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2021.png",'0px','0px']
         },
         {
            id:'Subway_22',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2022.png",'0px','0px']
         },
         {
            id:'Subway_23',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2023.png",'0px','0px']
         },
         {
            id:'Subway_24',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2024.png",'0px','0px']
         },
         {
            id:'Subway_25',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2025.png",'0px','0px']
         },
         {
            id:'Subway_26',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2026.png",'0px','0px']
         },
         {
            id:'Subway_27',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2027.png",'0px','0px']
         },
         {
            id:'Subway_28',
            display:'none',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2028.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Subway_11}": [
            ["style", "display", 'none']
         ],
         "${_Subway_23}": [
            ["style", "display", 'none']
         ],
         "${_Subway_07}": [
            ["style", "display", 'none']
         ],
         "${_Subway_16}": [
            ["style", "display", 'none']
         ],
         "${_Subway_02}": [
            ["style", "display", 'none']
         ],
         "${_Subway_20}": [
            ["style", "display", 'none']
         ],
         "${_Subway_01}": [
            ["style", "display", 'block']
         ],
         "${_Subway_03}": [
            ["style", "display", 'none']
         ],
         "${_Subway_19}": [
            ["style", "display", 'none']
         ],
         "${_Subway_22}": [
            ["style", "display", 'none']
         ],
         "${_Subway_18}": [
            ["style", "display", 'none']
         ],
         "${_Subway_05}": [
            ["style", "display", 'none']
         ],
         "${_Subway_06}": [
            ["style", "display", 'none']
         ],
         "${_Subway_14}": [
            ["style", "display", 'none']
         ],
         "${_Subway_13}": [
            ["style", "display", 'none']
         ],
         "${_Subway_17}": [
            ["style", "display", 'none']
         ],
         "${_Subway_09}": [
            ["style", "display", 'none']
         ],
         "${_Subway_28}": [
            ["style", "display", 'none']
         ],
         "${_Subway_21}": [
            ["style", "display", 'none']
         ],
         "${_Subway_12}": [
            ["style", "display", 'none']
         ],
         "${_Subway_15}": [
            ["style", "display", 'none']
         ],
         "${_Subway_08}": [
            ["style", "display", 'none']
         ],
         "${_Subway_04}": [
            ["style", "display", 'none']
         ],
         "${_Subway_10}": [
            ["style", "display", 'none']
         ],
         "${_Subway_26}": [
            ["style", "display", 'none']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '320px'],
            ["style", "height", '240px'],
            ["style", "overflow", 'hidden']
         ],
         "${_Subway_27}": [
            ["style", "display", 'none']
         ],
         "${_Subway_24}": [
            ["style", "display", 'none']
         ],
         "${_Subway_25}": [
            ["style", "display", 'none']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 4500,
         autoPlay: true,
         timeline: [
            { id: "eid5", tween: [ "style", "${_Subway_25}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid76", tween: [ "style", "${_Subway_25}", "display", 'block', { fromValue: 'none'}], position: 4000, duration: 0 },
            { id: "eid77", tween: [ "style", "${_Subway_25}", "display", 'none', { fromValue: 'block'}], position: 4167, duration: 0 },
            { id: "eid25", tween: [ "style", "${_Subway_05}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid35", tween: [ "style", "${_Subway_05}", "display", 'block', { fromValue: 'none'}], position: 667, duration: 0 },
            { id: "eid37", tween: [ "style", "${_Subway_05}", "display", 'none', { fromValue: 'block'}], position: 833, duration: 0 },
            { id: "eid13", tween: [ "style", "${_Subway_17}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid60", tween: [ "style", "${_Subway_17}", "display", 'block', { fromValue: 'none'}], position: 2667, duration: 0 },
            { id: "eid61", tween: [ "style", "${_Subway_17}", "display", 'none', { fromValue: 'block'}], position: 2833, duration: 0 },
            { id: "eid9", tween: [ "style", "${_Subway_21}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid68", tween: [ "style", "${_Subway_21}", "display", 'block', { fromValue: 'none'}], position: 3333, duration: 0 },
            { id: "eid69", tween: [ "style", "${_Subway_21}", "display", 'none', { fromValue: 'block'}], position: 3500, duration: 0 },
            { id: "eid30", tween: [ "style", "${_Subway_01}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
            { id: "eid29", tween: [ "style", "${_Subway_01}", "display", 'none', { fromValue: 'block'}], position: 167, duration: 0 },
            { id: "eid1", tween: [ "style", "${_Subway_02}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid28", tween: [ "style", "${_Subway_02}", "display", 'block', { fromValue: 'none'}], position: 167, duration: 0 },
            { id: "eid31", tween: [ "style", "${_Subway_02}", "display", 'none', { fromValue: 'block'}], position: 333, duration: 0 },
            { id: "eid23", tween: [ "style", "${_Subway_07}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid40", tween: [ "style", "${_Subway_07}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0 },
            { id: "eid41", tween: [ "style", "${_Subway_07}", "display", 'none', { fromValue: 'block'}], position: 1167, duration: 0 },
            { id: "eid14", tween: [ "style", "${_Subway_16}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid58", tween: [ "style", "${_Subway_16}", "display", 'block', { fromValue: 'none'}], position: 2500, duration: 0 },
            { id: "eid59", tween: [ "style", "${_Subway_16}", "display", 'none', { fromValue: 'block'}], position: 2667, duration: 0 },
            { id: "eid4", tween: [ "style", "${_Subway_26}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid78", tween: [ "style", "${_Subway_26}", "display", 'block', { fromValue: 'none'}], position: 4167, duration: 0 },
            { id: "eid79", tween: [ "style", "${_Subway_26}", "display", 'none', { fromValue: 'block'}], position: 4333, duration: 0 },
            { id: "eid8", tween: [ "style", "${_Subway_22}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid70", tween: [ "style", "${_Subway_22}", "display", 'block', { fromValue: 'none'}], position: 3500, duration: 0 },
            { id: "eid71", tween: [ "style", "${_Subway_22}", "display", 'none', { fromValue: 'block'}], position: 3667, duration: 0 },
            { id: "eid24", tween: [ "style", "${_Subway_06}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid38", tween: [ "style", "${_Subway_06}", "display", 'block', { fromValue: 'none'}], position: 833, duration: 0 },
            { id: "eid39", tween: [ "style", "${_Subway_06}", "display", 'none', { fromValue: 'block'}], position: 1000, duration: 0 },
            { id: "eid15", tween: [ "style", "${_Subway_15}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid56", tween: [ "style", "${_Subway_15}", "display", 'block', { fromValue: 'none'}], position: 2333, duration: 0 },
            { id: "eid57", tween: [ "style", "${_Subway_15}", "display", 'none', { fromValue: 'block'}], position: 2500, duration: 0 },
            { id: "eid10", tween: [ "style", "${_Subway_20}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid66", tween: [ "style", "${_Subway_20}", "display", 'block', { fromValue: 'none'}], position: 3167, duration: 0 },
            { id: "eid67", tween: [ "style", "${_Subway_20}", "display", 'none', { fromValue: 'block'}], position: 3333, duration: 0 },
            { id: "eid22", tween: [ "style", "${_Subway_08}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid42", tween: [ "style", "${_Subway_08}", "display", 'block', { fromValue: 'none'}], position: 1167, duration: 0 },
            { id: "eid43", tween: [ "style", "${_Subway_08}", "display", 'none', { fromValue: 'block'}], position: 1333, duration: 0 },
            { id: "eid6", tween: [ "style", "${_Subway_24}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid74", tween: [ "style", "${_Subway_24}", "display", 'block', { fromValue: 'none'}], position: 3833, duration: 0 },
            { id: "eid75", tween: [ "style", "${_Subway_24}", "display", 'none', { fromValue: 'block'}], position: 4000, duration: 0 },
            { id: "eid3", tween: [ "style", "${_Subway_27}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid80", tween: [ "style", "${_Subway_27}", "display", 'block', { fromValue: 'none'}], position: 4333, duration: 0 },
            { id: "eid81", tween: [ "style", "${_Subway_27}", "display", 'none', { fromValue: 'block'}], position: 4500, duration: 0 },
            { id: "eid11", tween: [ "style", "${_Subway_19}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid64", tween: [ "style", "${_Subway_19}", "display", 'block', { fromValue: 'none'}], position: 3000, duration: 0 },
            { id: "eid65", tween: [ "style", "${_Subway_19}", "display", 'none', { fromValue: 'block'}], position: 3167, duration: 0 },
            { id: "eid12", tween: [ "style", "${_Subway_18}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid62", tween: [ "style", "${_Subway_18}", "display", 'block', { fromValue: 'none'}], position: 2833, duration: 0 },
            { id: "eid63", tween: [ "style", "${_Subway_18}", "display", 'none', { fromValue: 'block'}], position: 3000, duration: 0 },
            { id: "eid7", tween: [ "style", "${_Subway_23}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid72", tween: [ "style", "${_Subway_23}", "display", 'block', { fromValue: 'none'}], position: 3667, duration: 0 },
            { id: "eid73", tween: [ "style", "${_Subway_23}", "display", 'none', { fromValue: 'block'}], position: 3833, duration: 0 },
            { id: "eid2", tween: [ "style", "${_Subway_28}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid82", tween: [ "style", "${_Subway_28}", "display", 'block', { fromValue: 'none'}], position: 4500, duration: 0 },
            { id: "eid18", tween: [ "style", "${_Subway_12}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid50", tween: [ "style", "${_Subway_12}", "display", 'block', { fromValue: 'none'}], position: 1833, duration: 0 },
            { id: "eid51", tween: [ "style", "${_Subway_12}", "display", 'none', { fromValue: 'block'}], position: 2000, duration: 0 },
            { id: "eid20", tween: [ "style", "${_Subway_10}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid46", tween: [ "style", "${_Subway_10}", "display", 'block', { fromValue: 'none'}], position: 1500, duration: 0 },
            { id: "eid47", tween: [ "style", "${_Subway_10}", "display", 'none', { fromValue: 'block'}], position: 1667, duration: 0 },
            { id: "eid19", tween: [ "style", "${_Subway_11}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid48", tween: [ "style", "${_Subway_11}", "display", 'block', { fromValue: 'none'}], position: 1667, duration: 0 },
            { id: "eid49", tween: [ "style", "${_Subway_11}", "display", 'none', { fromValue: 'block'}], position: 1833, duration: 0 },
            { id: "eid17", tween: [ "style", "${_Subway_13}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid52", tween: [ "style", "${_Subway_13}", "display", 'block', { fromValue: 'none'}], position: 2000, duration: 0 },
            { id: "eid53", tween: [ "style", "${_Subway_13}", "display", 'none', { fromValue: 'block'}], position: 2167, duration: 0 },
            { id: "eid26", tween: [ "style", "${_Subway_04}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid34", tween: [ "style", "${_Subway_04}", "display", 'block', { fromValue: 'none'}], position: 500, duration: 0 },
            { id: "eid36", tween: [ "style", "${_Subway_04}", "display", 'none', { fromValue: 'block'}], position: 667, duration: 0 },
            { id: "eid16", tween: [ "style", "${_Subway_14}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid54", tween: [ "style", "${_Subway_14}", "display", 'block', { fromValue: 'none'}], position: 2167, duration: 0 },
            { id: "eid55", tween: [ "style", "${_Subway_14}", "display", 'none', { fromValue: 'block'}], position: 2333, duration: 0 },
            { id: "eid21", tween: [ "style", "${_Subway_09}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid44", tween: [ "style", "${_Subway_09}", "display", 'block', { fromValue: 'none'}], position: 1333, duration: 0 },
            { id: "eid45", tween: [ "style", "${_Subway_09}", "display", 'none', { fromValue: 'block'}], position: 1500, duration: 0 },
            { id: "eid27", tween: [ "style", "${_Subway_03}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid32", tween: [ "style", "${_Subway_03}", "display", 'block', { fromValue: 'none'}], position: 333, duration: 0 },
            { id: "eid33", tween: [ "style", "${_Subway_03}", "display", 'none', { fromValue: 'block'}], position: 500, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-573361207");
