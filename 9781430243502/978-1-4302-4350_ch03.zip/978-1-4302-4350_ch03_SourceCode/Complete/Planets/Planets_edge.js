/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'EarthRect',
            type:'rect',
            rect:['319px','81px','59px','59px','auto','auto'],
            fill:["rgba(192,192,192,0)"],
            stroke:[0,"rgba(0, 0, 0, 0)","none"],
            c:[
            {
               id:'MoonRect',
               type:'rect',
               rect:['10px','-66px','43px','34px','auto','auto'],
               fill:["rgba(192,192,192,0)"],
               stroke:[0,"rgba(0, 0, 0, 0)","none"],
               c:[
               {
                  id:'Moon',
                  type:'image',
                  rect:['-16px','-18px','74','66','undefined','undefined'],
                  fill:["rgba(0,0,0,0)",im+"Moon.svg"],
                  transform:[[],[],[],['0.577','0.577']]
               }]
            },
            {
               id:'Earth',
               type:'image',
               rect:['-42px','-36px','146','131','undefined','undefined'],
               fill:["rgba(0,0,0,0)",im+"Earth.svg"],
               transform:[[],[],[],['0.509','0.509']]
            }]
         },
         {
            id:'Rectangle',
            type:'rect',
            rect:['277px','188px','136px','124px','auto','auto'],
            fill:["rgba(192,192,192,0.00)"],
            stroke:[0,"rgba(0,0,0,0.00)","none"],
            c:[
            {
               id:'Jupiter',
               type:'image',
               rect:['-41px','-50px','226','222','undefined','undefined'],
               fill:["rgba(0,0,0,0)",im+"Jupiter.svg"],
               transform:[[],[],[],['0.5','0.5']]
            }]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Earth}": [
            ["transform", "scaleX", '0.509'],
            ["style", "top", '-35.72px'],
            ["style", "left", '-41.87px'],
            ["transform", "scaleY", '0.509']
         ],
         "${_EarthRect}": [
            ["style", "-webkit-transform-origin", [50.89,279.5], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [50.89,279.5],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [50.89,279.5],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [50.89,279.5],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [50.89,279.5],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "rotateZ", '0deg'],
            ["style", "height", '59.199996948242px'],
            ["style", "top", '81.02px'],
            ["style", "left", '319.02px'],
            ["style", "width", '58.9833984375px']
         ],
         "${_MoonRect}": [
            ["style", "-webkit-transform-origin", [41.46,286.85], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [41.46,286.85],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [41.46,286.85],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [41.46,286.85],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [41.46,286.85],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "rotateZ", '0deg'],
            ["style", "height", '33.666687011719px'],
            ["style", "top", '-66.02px'],
            ["style", "left", '10px'],
            ["style", "width", '43.150001525879px']
         ],
         "${_Moon}": [
            ["transform", "scaleX", '0.57723'],
            ["style", "top", '-18.25px'],
            ["style", "left", '-15.67px'],
            ["transform", "scaleY", '0.57723']
         ],
         "${_Rectangle}": [
            ["style", "top", '188.33px'],
            ["color", "background-color", 'rgba(192,192,192,0.00)'],
            ["transform", "rotateZ", '0deg'],
            ["style", "height", '124.33749389648px'],
            ["color", "border-color", 'rgba(0,0,0,0.00)'],
            ["style", "left", '277.3px'],
            ["style", "width", '136.23124694824px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(0,0,0,1)'],
            ["style", "width", '700px'],
            ["style", "height", '500px'],
            ["style", "overflow", 'hidden']
         ],
         "${_Jupiter}": [
            ["transform", "scaleX", '0.5'],
            ["style", "top", '-49.83px'],
            ["style", "left", '-40.82px'],
            ["transform", "scaleY", '0.5']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 3000,
         autoPlay: true,
         timeline: [
            { id: "eid4", tween: [ "transform", "${_EarthRect}", "rotateZ", '-360deg', { fromValue: '0deg'}], position: 0, duration: 3000 },
            { id: "eid10", tween: [ "transform", "${_MoonRect}", "rotateZ", '720deg', { fromValue: '0deg'}], position: 0, duration: 3000 },
            { id: "eid2", tween: [ "transform", "${_Rectangle}", "rotateZ", '360deg', { fromValue: '0deg'}], position: 0, duration: 3000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-62592410");
