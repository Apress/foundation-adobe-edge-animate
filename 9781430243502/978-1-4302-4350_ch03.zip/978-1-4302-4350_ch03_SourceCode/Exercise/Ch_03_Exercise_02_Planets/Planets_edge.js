/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Jupiter',
            type:'image',
            rect:['236','138','226','222','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Jupiter.svg"],
            transform:[[],[],[],['0.5','0.5']]
         },
         {
            id:'Earth',
            type:'image',
            rect:['277','45','146','131','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Earth.svg"],
            transform:[[],[],[],['0.509','0.509']]
         },
         {
            id:'Moon',
            type:'image',
            rect:['313','-3','74','66','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Moon.svg"],
            transform:[[],[],[],['0.577','0.577']]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Moon}": [
            ["transform", "scaleX", '0.57723'],
            ["style", "left", '313.36px'],
            ["transform", "scaleY", '0.57723'],
            ["style", "top", '-3.26px']
         ],
         "${_Earth}": [
            ["transform", "scaleX", '0.509'],
            ["style", "left", '277.16px'],
            ["transform", "scaleY", '0.509'],
            ["style", "top", '45.3px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(0,0,0,1)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '500px'],
            ["style", "width", '700px']
         ],
         "${_Jupiter}": [
            ["transform", "scaleX", '0.5'],
            ["style", "left", '236.5px'],
            ["transform", "scaleY", '0.5'],
            ["style", "top", '138.5px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-62592410");
