/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Subway_01',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2001.png",'0px','0px']
         },
         {
            id:'Subway_02',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2002.png",'0px','0px']
         },
         {
            id:'Subway_03',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2003.png",'0px','0px']
         },
         {
            id:'Subway_04',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2004.png",'0px','0px']
         },
         {
            id:'Subway_05',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2005.png",'0px','0px']
         },
         {
            id:'Subway_06',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2006.png",'0px','0px']
         },
         {
            id:'Subway_07',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2007.png",'0px','0px']
         },
         {
            id:'Subway_08',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2008.png",'0px','0px']
         },
         {
            id:'Subway_09',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2009.png",'0px','0px']
         },
         {
            id:'Subway_10',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2010.png",'0px','0px']
         },
         {
            id:'Subway_11',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2011.png",'0px','0px']
         },
         {
            id:'Subway_12',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2012.png",'0px','0px']
         },
         {
            id:'Subway_13',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2013.png",'0px','0px']
         },
         {
            id:'Subway_14',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2014.png",'0px','0px']
         },
         {
            id:'Subway_15',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2015.png",'0px','0px']
         },
         {
            id:'Subway_16',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2016.png",'0px','0px']
         },
         {
            id:'Subway_17',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2017.png",'0px','0px']
         },
         {
            id:'Subway_18',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2018.png",'0px','0px']
         },
         {
            id:'Subway_19',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2019.png",'0px','0px']
         },
         {
            id:'Subway_20',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2020.png",'0px','0px']
         },
         {
            id:'Subway_21',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2021.png",'0px','0px']
         },
         {
            id:'Subway_22',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2022.png",'0px','0px']
         },
         {
            id:'Subway_23',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2023.png",'0px','0px']
         },
         {
            id:'Subway_24',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2024.png",'0px','0px']
         },
         {
            id:'Subway_25',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2025.png",'0px','0px']
         },
         {
            id:'Subway_26',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2026.png",'0px','0px']
         },
         {
            id:'Subway_27',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2027.png",'0px','0px']
         },
         {
            id:'Subway_28',
            type:'image',
            rect:['0','0','320px','240px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Subway%2028.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '320px'],
            ["style", "height", '240px'],
            ["style", "overflow", 'hidden']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-573361207");
