/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Background',
            type:'image',
            rect:['0','0px','1000px','542px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Background.jpg",'0px','0px']
         },
         {
            id:'Balloon',
            type:'image',
            rect:['439px','282px','185px','248px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Balloon.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '542px'],
            ["style", "width", '1000px']
         ],
         "${_Background}": [
            ["style", "top", '0px']
         ],
         "${_Balloon}": [
            ["style", "top", '281.67px'],
            ["transform", "scaleX", '1px'],
            ["transform", "scaleY", '1px'],
            ["style", "left", '438.55px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 5000,
         autoPlay: true,
         timeline: [
            { id: "eid6", tween: [ "style", "${_Balloon}", "top", '69px', { fromValue: '281.67px'}], position: 0, duration: 644, easing: "easeOutQuad" },
            { id: "eid17", tween: [ "style", "${_Balloon}", "top", '-135px', { fromValue: '69px'}], position: 644, duration: 4356, easing: "easeOutQuad" },
            { id: "eid7", tween: [ "transform", "${_Balloon}", "scaleX", '0.01', { fromValue: '1'}], position: 0, duration: 5000, easing: "easeOutQuad" },
            { id: "eid8", tween: [ "transform", "${_Balloon}", "scaleY", '0.01', { fromValue: '1'}], position: 0, duration: 5000, easing: "easeOutQuad" },
            { id: "eid5", tween: [ "style", "${_Balloon}", "left", '482px', { fromValue: '438.55px'}], position: 0, duration: 644, easing: "easeOutQuad" },
            { id: "eid9", tween: [ "style", "${_Balloon}", "left", '924px', { fromValue: '482px'}], position: 644, duration: 4356, easing: "easeOutQuad" }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-46501402");
