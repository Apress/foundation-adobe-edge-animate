/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Background',
            type:'image',
            rect:['0','0','300px','600px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Background.svg",'0px','0px']
         },
         {
            id:'Group',
            type:'group',
            rect:['0','0','300','600','auto','auto'],
            c:[
            {
               id:'Boat',
               type:'image',
               rect:['0px','0px','300px','600px','auto','auto'],
               fill:["rgba(0,0,0,0)",im+"Boat.svg",'0px','0px']
            },
            {
               id:'Anchor',
               type:'image',
               rect:['0','0','300px','600px','auto','auto'],
               fill:["rgba(0,0,0,0)",im+"Anchor.svg",'0px','0px']
            }]
         },
         {
            id:'Waves12',
            type:'image',
            rect:['0px','0px','300px','600px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Waves12.svg",'0px','0px']
         },
         {
            id:'Waves22',
            type:'image',
            rect:['0','0','300px','600px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Waves22.svg",'0px','0px']
         },
         {
            id:'Waves33',
            type:'image',
            rect:['0','0','300px','600px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Waves33.svg",'0px','0px']
         },
         {
            id:'Logo',
            type:'image',
            rect:['0','0','300px','600px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Logo.svg",'0px','0px']
         },
         {
            id:'Text',
            type:'image',
            rect:['0','0','300px','600px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Text.svg",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Group}": [
            ["style", "top", '0px']
         ],
         "${_Boat}": [
            ["style", "top", '0px'],
            ["style", "left", '0px']
         ],
         "${_Waves22}": [
            ["style", "left", '0px'],
            ["style", "top", '0px']
         ],
         "${_Waves33}": [
            ["transform", "scaleX", '1px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '300px'],
            ["style", "height", '600px'],
            ["style", "overflow", 'hidden']
         ],
         "${_Waves12}": [
            ["style", "left", '0px'],
            ["style", "top", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 6000,
         autoPlay: true,
         timeline: [
            { id: "eid3", tween: [ "style", "${_Waves12}", "top", '20px', { fromValue: '0px'}], position: 0, duration: 1000 },
            { id: "eid4", tween: [ "style", "${_Waves12}", "top", '0px', { fromValue: '20px'}], position: 1000, duration: 1000 },
            { id: "eid25", tween: [ "style", "${_Waves12}", "top", '20px', { fromValue: '0px'}], position: 3000, duration: 1000 },
            { id: "eid26", tween: [ "style", "${_Waves12}", "top", '0px', { fromValue: '20px'}], position: 4000, duration: 1000 },
            { id: "eid32", tween: [ "style", "${_Group}", "top", '10px', { fromValue: '0px'}], position: 0, duration: 1500 },
            { id: "eid33", tween: [ "style", "${_Group}", "top", '0px', { fromValue: '10px'}], position: 1500, duration: 1500 },
            { id: "eid34", tween: [ "style", "${_Group}", "top", '10px', { fromValue: '0px'}], position: 3000, duration: 1500 },
            { id: "eid35", tween: [ "style", "${_Group}", "top", '0px', { fromValue: '10px'}], position: 4500, duration: 1500 },
            { id: "eid1", tween: [ "style", "${_Waves12}", "left", '0px', { fromValue: '0px'}], position: 0, duration: 0 },
            { id: "eid27", tween: [ "style", "${_Waves12}", "left", '0px', { fromValue: '0px'}], position: 3000, duration: 0 },
            { id: "eid10", tween: [ "transform", "${_Waves33}", "scaleX", '1.2', { fromValue: '1'}], position: 1000, duration: 1000 },
            { id: "eid11", tween: [ "transform", "${_Waves33}", "scaleX", '1', { fromValue: '1.2'}], position: 2000, duration: 1000 },
            { id: "eid20", tween: [ "transform", "${_Waves33}", "scaleX", '1.2', { fromValue: '1'}], position: 4000, duration: 1000 },
            { id: "eid21", tween: [ "transform", "${_Waves33}", "scaleX", '1', { fromValue: '1.2'}], position: 5000, duration: 1000 },
            { id: "eid5", tween: [ "style", "${_Waves22}", "left", '0px', { fromValue: '0px'}], position: 500, duration: 0 },
            { id: "eid22", tween: [ "style", "${_Waves22}", "left", '0px', { fromValue: '0px'}], position: 3500, duration: 0 },
            { id: "eid7", tween: [ "style", "${_Waves22}", "top", '-15px', { fromValue: '0px'}], position: 500, duration: 1000 },
            { id: "eid8", tween: [ "style", "${_Waves22}", "top", '0px', { fromValue: '-15px'}], position: 1500, duration: 1000 },
            { id: "eid23", tween: [ "style", "${_Waves22}", "top", '-15px', { fromValue: '0px'}], position: 3500, duration: 1000 },
            { id: "eid24", tween: [ "style", "${_Waves22}", "top", '0px', { fromValue: '-15px'}], position: 4500, duration: 1000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-52039843");
