/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'LA_Adobe_Max',
            type:'image',
            rect:['0','0','800','500','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"LA_Adobe_Max.jpg"],
            transform:[]
         },
         {
            id:'GIF',
            type:'image',
            rect:['319','26','147','232','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"LogoRaster.gif"],
            transform:[]
         },
         {
            id:'JPG',
            type:'image',
            rect:['318','25','147','232','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"LogoRaster.jpg"],
            transform:[]
         },
         {
            id:'PNG',
            type:'image',
            rect:['291','10','201','277','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"LogoRaster.png"],
            transform:[]
         },
         {
            id:'SVG',
            type:'image',
            rect:['289','4','200','275','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"LogoVector.svg"],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_PNG}": [
            ["transform", "scaleX", '1'],
            ["style", "top", '9.63px'],
            ["transform", "scaleY", '1'],
            ["style", "left", '291.99px']
         ],
         "${_SVG}": [
            ["transform", "scaleX", '1'],
            ["style", "top", '4px'],
            ["transform", "scaleY", '1'],
            ["style", "left", '289.39px']
         ],
         "${_JPG}": [
            ["transform", "scaleX", '1'],
            ["style", "left", '318px'],
            ["transform", "scaleY", '1'],
            ["style", "top", '25px']
         ],
         "${_stage}": [
            ["style", "height", '500px'],
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '800px']
         ],
         "${_GIF}": [
            ["transform", "scaleX", '1'],
            ["style", "top", '26.96px'],
            ["transform", "scaleY", '1'],
            ["style", "left", '319.72px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         timeline: [
            { id: "eid8", tween: [ "transform", "${_SVG}", "scaleY", '1.99', { fromValue: '1'}], position: 0, duration: 1000 },
            { id: "eid12", tween: [ "transform", "${_PNG}", "scaleY", '2', { fromValue: '1'}], position: 0, duration: 1000 },
            { id: "eid23", tween: [ "transform", "${_GIF}", "scaleX", '2', { fromValue: '1'}], position: 0, duration: 1000 },
            { id: "eid7", tween: [ "transform", "${_SVG}", "scaleX", '1.99', { fromValue: '1'}], position: 0, duration: 1000 },
            { id: "eid17", tween: [ "transform", "${_JPG}", "scaleX", '2', { fromValue: '1'}], position: 0, duration: 1000 },
            { id: "eid24", tween: [ "transform", "${_GIF}", "scaleY", '2', { fromValue: '1'}], position: 0, duration: 1000 },
            { id: "eid18", tween: [ "transform", "${_JPG}", "scaleY", '2', { fromValue: '1'}], position: 0, duration: 1000 },
            { id: "eid11", tween: [ "transform", "${_PNG}", "scaleX", '2', { fromValue: '1'}], position: 0, duration: 1000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-215263804");
