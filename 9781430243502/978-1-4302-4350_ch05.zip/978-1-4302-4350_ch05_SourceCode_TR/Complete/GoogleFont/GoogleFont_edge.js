/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};
   fonts['Ubuntu, Arial, sans-serif']='<link href=\'http://fonts.googleapis.com/css?family=Ubuntu\' rel=\'stylesheet\' type=\'text/css\'>';


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.6",
   build: "0.11.0.141",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   content: {
         dom: [
         {
            id:'Horizon',
            type:'image',
            rect:['0','0','1200','300'],
            fill:["rgba(0,0,0,0)",im+"Horizon.jpg"],
            transform:[['0','1']]
         },
         {
            id:'Text',
            type:'text',
            rect:['157','175','161px','0'],
            text:"Autumn",
            font:['Ubuntu, Arial, sans-serif',40,"rgba(255,255,255,1.00)","normal","none",""],
            transform:[['-127px','-25px']]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Horizon}": [
            ["transform", "translateY", '1px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(0,0,0,1)'],
            ["style", "overflow", 'visible'],
            ["style", "height", '300px'],
            ["style", "width", '1200px']
         ],
         "${_Text}": [
            ["style", "width", '161.89453125px'],
            ["transform", "translateX", '-127px'],
            ["style", "white-space", 'normal'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-family", 'Ubuntu, Arial, sans-serif'],
            ["transform", "translateY", '-25px'],
            ["style", "font-size", '40px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-670030010");
