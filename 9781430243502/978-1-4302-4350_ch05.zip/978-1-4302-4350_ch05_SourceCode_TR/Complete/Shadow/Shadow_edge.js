/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Rust',
            type:'image',
            rect:['0','0','800','640','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Rust.jpg"]
         },
         {
            id:'Rust_txt',
            type:'text',
            rect:['197','174','0','0','auto','auto'],
            text:"Rust",
            align:"auto",
            font:['Georgia, \'Times New Roman\', Times, serif',228,"rgba(71,38,33,1)","bold","none","normal"],
            textShadow:["rgba(0,0,0,1.00)",13,16,13],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["style", "height", '640px'],
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '800px']
         ],
         "${_Rust_txt}": [
            ["style", "top", '-43.78px'],
            ["subproperty", "textShadow.offsetH", '-33px'],
            ["subproperty", "textShadow.offsetV", '-20px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,1.00)'],
            ["style", "left", '0px'],
            ["subproperty", "textShadow.blur", '13px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         timeline: [
            { id: "eid43", tween: [ "subproperty", "${_Rust_txt}", "textShadow.blur", '30px', { fromValue: '13px'}], position: 0, duration: 2000 },
            { id: "eid51", tween: [ "style", "${_Rust_txt}", "left", '242.11px', { fromValue: '0px'}], position: 0, duration: 2000 },
            { id: "eid53", tween: [ "subproperty", "${_Rust_txt}", "textShadow.offsetH", '34px', { fromValue: '-33px'}], position: 0, duration: 2000 },
            { id: "eid50", tween: [ "style", "${_Rust_txt}", "top", '373.16px', { fromValue: '-43.78px'}], position: 0, duration: 2000 },
            { id: "eid52", tween: [ "subproperty", "${_Rust_txt}", "textShadow.offsetV", '32px', { fromValue: '-20px'}], position: 0, duration: 2000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-372730943");
