/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Rust',
            type:'image',
            rect:['0','0','800','640','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Rust.jpg"]
         },
         {
            id:'Rust_txt',
            type:'text',
            rect:['197','174','0','0','auto','auto'],
            text:"Rust",
            align:"auto",
            font:['Georgia, \'Times New Roman\', Times, serif',228,"rgba(71,38,33,1)","bold","none","normal"],
            textShadow:["rgba(0,0,0,0.00)",0,17,13],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["style", "height", '640px'],
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '800px']
         ],
         "${_Rust_txt}": [
            ["style", "top", '174px'],
            ["subproperty", "textShadow.offsetH", '-20px'],
            ["subproperty", "textShadow.offsetV", '-33px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["subproperty", "textShadow.color", 'rgba(0,0,0,0.00)'],
            ["style", "left", '197px'],
            ["subproperty", "textShadow.blur", '13px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-372730943");
