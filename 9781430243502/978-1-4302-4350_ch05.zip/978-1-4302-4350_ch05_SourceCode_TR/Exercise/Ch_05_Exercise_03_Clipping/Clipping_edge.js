/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Background',
            type:'image',
            rect:['0','0','728','90','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Background.jpg"]
         },
         {
            id:'Hat',
            type:'image',
            rect:['111','-4','105','90','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Hat.svg"],
            transform:[[],['-90deg']]
         },
         {
            id:'Text',
            type:'text',
            rect:['190','12','0','0','auto','auto'],
            text:"Meet Edge Animate",
            align:"auto",
            font:['Tahoma, Geneva, sans-serif',48,"rgba(0,0,0,1)","bold","none","normal"],
            transform:[]
         },
         {
            id:'Arm',
            type:'image',
            rect:['181','0','562','90','auto','auto'],
            tabindex:'0',
            fill:["rgba(0,0,0,0)",im+"Arm.svg"],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '728px'],
            ["style", "height", '90px'],
            ["style", "overflow", 'hidden']
         ],
         "${_Arm}": [
            ["style", "top", '0px'],
            ["style", "left", '182px'],
            ["style", "tabindex", '0']
         ],
         "${_Text}": [
            ["style", "top", '12px'],
            ["style", "left", '190px'],
            ["style", "font-family", 'Tahoma, Geneva, sans-serif'],
            ["style", "font-size", '48px']
         ],
         "${_Hat}": [
            ["style", "top", '-4px'],
            ["style", "left", '111px'],
            ["transform", "rotateZ", '-90deg']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         timeline: [
            { id: "eid2", tween: [ "style", "${_Arm}", "left", '610px', { fromValue: '182px'}], position: 0, duration: 2000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-379460190");
