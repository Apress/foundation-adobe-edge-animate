/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.958",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Horizon',
            type:'image',
            rect:['0','1','1200','300','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Horizon.jpg"],
            transform:[]
         },
         {
            id:'Text',
            type:'text',
            rect:['30','150','183px','0','auto','auto'],
            text:"Autumn",
            font:['Arial Black, Gadget, sans-serif',40,"rgba(255,255,255,1.00)","normal","none",""],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Text}": [
            ["style", "top", '150px'],
            ["style", "white-space", 'normal'],
            ["style", "font-size", '40px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-family", 'Arial Black, Gadget, sans-serif'],
            ["style", "left", '30px'],
            ["style", "width", '183.4140625px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(0,0,0,1)'],
            ["style", "width", '1200px'],
            ["style", "height", '300px'],
            ["style", "overflow", 'visible']
         ],
         "${_Horizon}": [
            ["style", "top", '1px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-670030010");
