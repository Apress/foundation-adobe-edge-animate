/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: true,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Horizon',
            type:'image',
            rect:['0','1','1200','300','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Horizon.jpg"],
            transform:[]
         },
         {
            id:'Text',
            type:'text',
            rect:['56px','134px','183px','0','auto','auto'],
            text:"Autumn",
            font:['Arial Black, Gadget, sans-serif',40,"rgba(255,255,255,1.00)","normal","none",""],
            transform:[]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Horizon}": [
            ["style", "top", '1px']
         ],
         "${_stage}": [
            ["color", "background-color", 'rgba(0,0,0,1)'],
            ["style", "overflow", 'visible'],
            ["style", "height", '300px'],
            ["style", "width", '1200px']
         ],
         "${_Text}": [
            ["style", "top", '134.18px'],
            ["style", "width", '183.4140625px'],
            ["style", "font-size", '40px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-family", 'Arial Black, Gadget, sans-serif'],
            ["style", "left", '55.74px'],
            ["style", "white-space", 'normal']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-670030010");
